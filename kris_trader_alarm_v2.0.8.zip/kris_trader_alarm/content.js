(function () {
  'use strict';

  if (window.__ubPollTimer) { clearInterval(window.__ubPollTimer); window.__ubPollTimer = null; }

  window.addEventListener('error', function (e) {
    if (e.message && e.message.includes('Extension context invalidated')) e.preventDefault();
  });

  const STORAGE_KEY = 'upbit_alarms_v2';
  const SETTINGS_KEY = 'upbit_alarm_settings_v1';
  const POLL_INTERVAL = 1500;

  let alarms = [];
  let currentSettings = { sound: 'fanfare', volume: 70, reactivate: 'custom', reactivateMinutes: 1 };

  function isCtxValid() {
    try { return !!chrome.runtime.id; } catch { return false; }
  }
  function isActive(a) { return !a.fired && !a.disabled; }

  function loadSettings() {
    chrome.storage.local.get(SETTINGS_KEY, data => {
      currentSettings = { sound: 'ding', reactivate: 'custom', reactivateMinutes: 1, ...(data[SETTINGS_KEY] || {}) };
    });
  }

  function loadAlarms() {
    chrome.storage.local.get(STORAGE_KEY, data => {
      alarms = data[STORAGE_KEY] || [];
      migrateV1();
      if (alarms.some(isActive)) startPolling();
    });
  }

  function migrateV1() {
    if (alarms.length) return;
    try {
      const old = localStorage.getItem('upbit_alarms_v1');
      if (!old) return;
      const parsed = JSON.parse(old);
      if (!parsed.length) return;
      alarms = parsed.map(a => ({
        ...a,
        sym: a.code.replace('KRW-', ''),
        kor: '',
        disabled: a.fired || false,
        fired: false
      }));
      chrome.storage.local.set({ [STORAGE_KEY]: alarms });
      localStorage.removeItem('upbit_alarms_v1');
    } catch {}
  }

  function disableAlarm(id) {
    chrome.storage.local.get(STORAGE_KEY, data => {
      const arr = data[STORAGE_KEY] || [];
      const a = arr.find(x => x.id === id);
      if (a) { a.disabled = true; a.fired = false; }
      chrome.storage.local.set({ [STORAGE_KEY]: arr });
    });
  }

  function enableAlarm(id) {
    chrome.storage.local.get(STORAGE_KEY, data => {
      const arr = data[STORAGE_KEY] || [];
      const a = arr.find(x => x.id === id);
      if (a) { a.disabled = false; }
      chrome.storage.local.set({ [STORAGE_KEY]: arr });
    });
  }

  function getReactivateMs() {
    switch (currentSettings.reactivate) {
      case '30min': return 30 * 60 * 1000;
      case '1hour': return 60 * 60 * 1000;
      case 'custom': return Math.max(1, currentSettings.reactivateMinutes || 60) * 60 * 1000;
      default: return 0;
    }
  }

  function playAlarmSound() {
    if (currentSettings.sound === 'none') return;
    fetch(chrome.runtime.getURL(`sounds/${currentSettings.sound}.wav`)).then(r=>r.blob()).then(blob=>{const u=URL.createObjectURL(blob);const a=new Audio(u);a.volume=(currentSettings.volume??70)/100;a.play().catch(()=>{});a.addEventListener('ended',()=>URL.revokeObjectURL(u));}).catch(()=>{});
  }

  function fetchPrices() {
    if (!isCtxValid()) {
      if (window.__ubPollTimer) { clearInterval(window.__ubPollTimer); window.__ubPollTimer = null; }
      return;
    }
    const codes = [...new Set(alarms.filter(isActive).map(a => a.code))];
    if (!codes.length) {
      if (window.__ubPollTimer) { clearInterval(window.__ubPollTimer); window.__ubPollTimer = null; }
      return;
    }
    try {
      chrome.runtime.sendMessage({ action: 'fetchPrices', codes }, res => {
        try {
          if (chrome.runtime.lastError || !res || !res.ok) return;
          Object.keys(res.prices).forEach(code => checkAlarms(code, res.prices[code]));
        } catch {}
      });
    } catch {
      if (window.__ubPollTimer) { clearInterval(window.__ubPollTimer); window.__ubPollTimer = null; }
    }
  }

  function startPolling() {
    if (window.__ubPollTimer) clearInterval(window.__ubPollTimer);
    fetchPrices();
    window.__ubPollTimer = setInterval(fetchPrices, POLL_INTERVAL);
  }

  function checkAlarms(code, price) {
    alarms.forEach(alarm => {
      if (!isActive(alarm) || alarm.code !== code) return;
      const triggered =
        (alarm.dir === 'above' && price >= alarm.price) ||
        (alarm.dir === 'below' && price <= alarm.price);
      if (triggered) {
        alarm.disabled = true;
        alarm.fired = false;
        disableAlarm(alarm.id);
        fireAlarm(alarm, price);
      }
    });
  }

  function showToast(msg, memo, url) {
    const toast = document.createElement('div');
    toast.style.cssText = `
      position:fixed;top:24px;left:50%;transform:translateX(-50%) translateY(-80px);
      z-index:999999;background:#1a1d27;color:#d1d4dc;border:1px solid #26a69a;
      border-radius:10px;padding:14px 20px;font-size:14px;font-weight:600;
      box-shadow:0 4px 24px rgba(0,0,0,.6);transition:transform .35s cubic-bezier(.2,1,.4,1);
      white-space:pre-line;text-align:center;min-width:240px;cursor:pointer;
      font-family:'Noto Sans KR',sans-serif;
    `;
    const msgEl = document.createElement('div');
    msgEl.textContent = msg;
    toast.appendChild(msgEl);
    if (memo) {
      const memoEl = document.createElement('div');
      memoEl.textContent = memo;
      memoEl.style.cssText = 'margin-top:6px;font-size:12px;color:#FF2424;';
      toast.appendChild(memoEl);
    }
    document.body.appendChild(toast);
    requestAnimationFrame(() => { toast.style.transform = 'translateX(-50%) translateY(0)'; });
    const dismiss = () => {
      toast.style.transform = 'translateX(-50%) translateY(-80px)';
      setTimeout(() => toast.remove(), 400);
    };
    toast.addEventListener('click', () => {
      if (url) window.location.href = url;
      dismiss();
    });
    setTimeout(dismiss, 7000);
  }

  function fireAlarm(alarm, currentPrice) {
    const dirText = alarm.dir === 'above' ? '이상' : '이하';
    const body = `${alarm.label} ${Number(alarm.price).toLocaleString()}원 ${dirText} 도달!\n현재가: ${Number(currentPrice).toLocaleString()}원`;
    const url = `https://upbit.com/exchange?code=CRIX.UPBIT.${alarm.code}`;
    showToast(`🔔 ${body}`, alarm.memo || '', url);
    if (Notification.permission === 'granted') {
      new Notification('🔔 업비트 가격 알람', { body });
    }
    playAlarmSound();

    const delay = getReactivateMs();
    setTimeout(() => enableAlarm(alarm.id), delay);
  }

  chrome.storage.onChanged.addListener(changes => {
    if (changes[STORAGE_KEY]) {
      alarms = changes[STORAGE_KEY].newValue || [];
      if (alarms.some(isActive)) startPolling();
      else if (window.__ubPollTimer) { clearInterval(window.__ubPollTimer); window.__ubPollTimer = null; }
    }
    if (changes[SETTINGS_KEY]) {
      currentSettings = { sound: 'ding', reactivate: 'custom', reactivateMinutes: 1, ...(changes[SETTINGS_KEY].newValue || {}) };
    }
  });

  if (Notification.permission === 'default') Notification.requestPermission();
  loadSettings();
  loadAlarms();
})();
