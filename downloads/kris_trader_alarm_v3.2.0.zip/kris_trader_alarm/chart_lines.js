(function () {
  'use strict';

  let _chart = null;
  let latestAlarms = [];
  let pendingAlarms = null;
  let _setupDone = false;
  let panelTheme = 'dark';
  let _shapeMap = new Map(); // alarmId → entityId
  let _pendingIds = new Set(); // createShape 진행 중인 alarmId

  function getTheme() {
    return panelTheme === 'dark'
      ? { bg: '#1e2235', bg2: '#13162a', border: '#2f3349', text: '#d1d4dc', lbl: '#9096b0', accent: '#6366f1', accentH: '#4f52cc', x: '#6a6f8a', div: '#2f3349', icon: '☀️', nextLabel: '라이트' }
      : { bg: '#ffffff', bg2: '#f0f3fa', border: '#d0d4e8', text: '#1a1d2e', lbl: '#666a80', accent: '#5558d4', accentH: '#4346b0', x: '#8888a0', div: '#d0d4e8', icon: '🌙', nextLabel: '다크' };
  }

  const DEFAULT_SETTINGS = {
    showBell: false, showArrow: false, showMemo: true, showPrice: false,
    aboveColor: '#ef5350', belowColor: '#26a69a',
    lineStyle: 2, lineWidth: 1,
    fontSize: 11, fontBold: false,
    horzAlign: 'right', vertAlign: 'bottom',
  };
  let lineSettings = { ...DEFAULT_SETTINGS };

  function findChart() {
    try {
      const iframe = document.querySelector('#tv_chart_container iframe');
      if (!iframe) return null;
      const api = iframe.contentWindow?.tradingViewApi;
      if (!api) return null;
      return api.activeChart();
    } catch (e) { return null; }
  }

  setInterval(() => {
    if (!_chart) {
      _chart = findChart();
      if (_chart && !_setupDone) {
        _setupDone = true;
        console.log('[KTA] chart 발견, 이벤트 연결');
        setupEvents();
        const toRender = pendingAlarms ?? latestAlarms;
        pendingAlarms = null;
        if (toRender.length) renderLines(toRender);
      }
    }
    syncFab();
  }, 300);

  function setupEvents() {
    const chart = _chart;
    try {
      chart.onSymbolChanged().subscribe(null, () => {
        clearTVLines();
        window.dispatchEvent(new CustomEvent('kta-symbol-changed'));
      });
    } catch (e) {}
  }

  function buildLabel(alarm) {
    const isAbove = alarm.dir === 'above';
    const parts = [];
    if (lineSettings.showBell) parts.push('🔔');
    if (lineSettings.showArrow) parts.push(isAbove ? '↑' : '↓');
    if (lineSettings.showPrice) parts.push(Number(alarm.price).toLocaleString());
    if (lineSettings.showMemo && alarm.memo) parts.push(alarm.memo);
    return parts.join(' ');
  }

  function clearTVLines() {
    for (const [, entry] of _shapeMap) {
      try { _chart?.removeEntity(entry.eid); } catch (e) {}
    }
    _shapeMap.clear();
    _pendingIds.clear();
  }

  function createShapeFor(a) {
    const alarmId = a.id;
    const price = parseFloat(a.price);
    const isAbove = a.dir === 'above';
    const color = isAbove ? lineSettings.aboveColor : lineSettings.belowColor;
    const label = buildLabel(a);
    const styleMap = { 0: 0, 1: 1, 2: 2 };
    _pendingIds.add(alarmId);
    Promise.resolve(_chart.createShape(
      { price, time: Date.now() / 1000 | 0 },
      {
        shape: 'horizontal_line',
        lock: true,
        disableSelection: true,
        disableSave: true,
        overrides: {
          linecolor: color,
          linewidth: lineSettings.lineWidth,
          linestyle: styleMap[lineSettings.lineStyle] ?? 2,
          showLabel: !!label,
          textcolor: color,
          fontSize: lineSettings.fontSize,
          bold: lineSettings.fontBold,
          text: label,
          horzLabelsAlign: lineSettings.horzAlign,
        }
      }
    )).then(eid => {
      _pendingIds.delete(alarmId);
      if (eid != null) _shapeMap.set(alarmId, { eid, price, label });
    }).catch(() => { _pendingIds.delete(alarmId); });
  }

  function drawTVLines() {
    if (!_chart) return;
    const active = latestAlarms.filter(a => !a.fired && !a.disabled);
    const activeIds = new Set(active.map(a => a.id));

    // 제거된 알람 shape 삭제
    for (const [id, entry] of _shapeMap) {
      if (!activeIds.has(id)) {
        try { _chart.removeEntity(entry.eid); } catch (e) {}
        _shapeMap.delete(id);
      }
    }

    for (const a of active) {
      if (_pendingIds.has(a.id)) continue;
      const price = parseFloat(a.price);
      const label = buildLabel(a);
      const existing = _shapeMap.get(a.id);
      if (existing) {
        // 가격 또는 라벨 변경 시 shape 교체
        if (existing.price === price && existing.label === label) continue;
        try { _chart.removeEntity(existing.eid); } catch (e) {}
        _shapeMap.delete(a.id);
      }
      try { createShapeFor(a); } catch (e) { console.log('[KTA] createShape err:', e.message); }
    }
  }

  function redrawAllTVLines() {
    clearTVLines();
    drawTVLines();
  }

  function renderLines(alarms) {
    latestAlarms = alarms;
    if (!_chart) { pendingAlarms = alarms; return; }
    drawTVLines();
  }

  // ── FAB ──────────────────────────────────────────────────────────────
  function findUpbitLogo() {
    const header = document.querySelector('header');
    if (!header) return null;
    const a = header.querySelector('a');
    if (a) return a;
    return header.firstElementChild || null;
  }

  function getLogoAnchorPos() {
    const el = findUpbitLogo();
    if (!el) return null;
    const r = el.getBoundingClientRect();
    if (!r.width || r.top > 80) return null;
    return {
      l: Math.max(2, Math.round(r.left) - 42),
      t: Math.max(2, Math.round(r.top + (r.height - 32) / 2)),
    };
  }

  function syncFab() {
    const onChart = !!document.getElementById('tv_chart_container');
    const widget = document.getElementById('kta-widget');
    if (!onChart) {
      if (widget) { widget._cleanup?.(); widget.remove(); }
      return;
    }
    if (widget) {
      const pos = getLogoAnchorPos();
      if (pos) { widget.style.left = pos.l + 'px'; widget.style.top = pos.t + 'px'; }
      return;
    }
    const pos = getLogoAnchorPos() || { l: 4, t: 8 };
    const w = document.createElement('div');
    w.id = 'kta-widget';
    w.style.cssText = `position:fixed;left:${pos.l}px;top:${pos.t}px;z-index:2147483647;`;
    w._cleanup = () => {};
    const btn = document.createElement('button');
    btn.id = 'kta-line-fab';
    btn.title = '클릭으로 알람선 설정 열기';
    btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white" width="24" height="24" style="display:block;pointer-events:none;"><path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/></svg>`;
    btn.style.cssText = `display:flex;align-items:center;justify-content:center;width:36px;height:32px;background:#003597;border:none;padding:0;border-radius:6px 6px 0 0;cursor:pointer;user-select:none;`;
    w.appendChild(btn);
    document.body.appendChild(w);
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const panel = document.getElementById('kta-line-settings');
      if (panel) panel.remove();
      else showSettingsPanel();
    });
  }

  // ── 설정 패널 ─────────────────────────────────────────────────────────
  function showSettingsPanel() {
    document.getElementById('kta-line-settings')?.remove();
    const widget = document.getElementById('kta-widget');
    if (!widget) return;
    const s = lineSettings;
    const t = getTheme();

    const panel = document.createElement('div');
    panel.id = 'kta-line-settings';
    panel.innerHTML = `
<style>
#kta-line-settings{position:absolute;top:100%;left:0;margin-top:-1px;width:272px;background:${t.bg};border:1px solid ${t.border};border-radius:0 6px 6px 6px;padding:14px;color:${t.text};font:13px/1.6 'Pretendard',system-ui,sans-serif;box-shadow:0 4px 24px rgba(0,0,0,.5);max-height:calc(100vh - 60px);overflow-y:auto;}
#kta-line-settings .ls-hd{font-weight:700;font-size:18px;display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:10px;}
#kta-line-settings .ls-hd-left{display:flex;align-items:center;gap:8px;}
#kta-line-settings .ls-theme{background:${t.bg2};border:1px solid ${t.border};color:${t.text};font:13px 'Pretendard',system-ui,sans-serif;padding:2px 8px;border-radius:5px;cursor:pointer;line-height:1.6;}
#kta-line-settings .ls-theme:hover{border-color:${t.accent};}
#kta-line-settings .ls-sec{margin-bottom:9px;}
#kta-line-settings .ls-lbl{color:${t.text};font-size:15px;font-weight:700;margin-bottom:4px;}
#kta-line-settings .ls-row{display:flex;gap:10px;flex-wrap:wrap;}
#kta-line-settings label{cursor:pointer;display:flex;align-items:center;gap:4px;font-size:13px;}
#kta-line-settings input[type=range]{width:100%;accent-color:${t.accent};vertical-align:middle;}
#kta-line-settings input[type=color]{width:100%;height:28px;border:none;border-radius:4px;cursor:pointer;padding:1px;}
#kta-line-settings .ls-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;}
#kta-line-settings .ls-btn{width:100%;padding:9px;background:${t.accent};border:none;border-radius:6px;color:#fff;font-weight:700;cursor:pointer;font-size:15px;font-family:'Pretendard',system-ui,sans-serif;margin-top:10px;}
#kta-line-settings .ls-btn:hover{background:${t.accentH};}
#kta-line-settings .ls-x{cursor:pointer;color:${t.x};font-size:20px;line-height:1;}
#kta-line-settings .ls-div{border:none;border-top:1px solid ${t.div};margin:10px 0;}
</style>
<div class="ls-hd">
  <div class="ls-hd-left">알람선 설정<button class="ls-theme">${t.icon} ${t.nextLabel}모드</button></div>
  <span class="ls-x">✕</span>
</div>
<div class="ls-sec">
  <div class="ls-lbl">표시 항목</div>
  <div class="ls-row">
    <label><input type="checkbox" id="ls-bell" ${s.showBell?'checked':''}> 종 🔔</label>
    <label><input type="checkbox" id="ls-arrow" ${s.showArrow?'checked':''}> 방향 ↑↓</label>
    <label><input type="checkbox" id="ls-price" ${s.showPrice?'checked':''}> 가격</label>
    <label><input type="checkbox" id="ls-memo" ${s.showMemo?'checked':''}> 비고</label>
  </div>
</div>
<div class="ls-sec">
  <div class="ls-lbl">선 스타일</div>
  <div class="ls-row">
    <label><input type="radio" name="ls-st" value="0" ${s.lineStyle===0?'checked':''}> 실선</label>
    <label><input type="radio" name="ls-st" value="1" ${s.lineStyle===1?'checked':''}> 점선</label>
    <label><input type="radio" name="ls-st" value="2" ${s.lineStyle===2?'checked':''}> 파선</label>
  </div>
</div>
<div class="ls-sec">
  <div class="ls-lbl">선 굵기: <span id="ls-wv">${s.lineWidth}</span>px</div>
  <input type="range" id="ls-w" min="1" max="4" value="${s.lineWidth}">
</div>
<div class="ls-sec">
  <div class="ls-lbl">폰트 크기: <span id="ls-fsv">${s.fontSize}</span>px</div>
  <input type="range" id="ls-fs" min="9" max="18" value="${s.fontSize}">
</div>
<div class="ls-sec">
  <div class="ls-lbl">텍스트 가로 위치</div>
  <div class="ls-row">
    <label><input type="radio" name="ls-ha" value="left" ${s.horzAlign==='left'?'checked':''}> 왼쪽</label>
    <label><input type="radio" name="ls-ha" value="center" ${s.horzAlign==='center'?'checked':''}> 가운데</label>
    <label><input type="radio" name="ls-ha" value="right" ${s.horzAlign==='right'?'checked':''}> 오른쪽</label>
  </div>
</div>
<div class="ls-sec"><label><input type="checkbox" id="ls-bold" ${s.fontBold?'checked':''}> 폰트 굵게</label></div>
<div class="ls-grid ls-sec">
  <div><div class="ls-lbl">이상 색상</div><input type="color" id="ls-ac" value="${s.aboveColor}"></div>
  <div><div class="ls-lbl">이하 색상</div><input type="color" id="ls-bc" value="${s.belowColor}"></div>
</div>
<button class="ls-btn">적용 (알람선 다시 그리기)</button>`;

    widget.appendChild(panel);
    panel.querySelector('.ls-x').onclick = () => panel.remove();
    panel.querySelector('.ls-theme').onclick = () => {
      panelTheme = panelTheme === 'dark' ? 'light' : 'dark';
      saveChartSettings(); showSettingsPanel();
    };
    document.getElementById('ls-w').oninput = function () { document.getElementById('ls-wv').textContent = this.value; };
    document.getElementById('ls-fs').oninput = function () { document.getElementById('ls-fsv').textContent = this.value; };

    panel.querySelector('.ls-btn').onclick = () => {
      lineSettings = {
        showBell: document.getElementById('ls-bell').checked,
        showArrow: document.getElementById('ls-arrow').checked,
        showMemo: document.getElementById('ls-memo').checked,
        showPrice: document.getElementById('ls-price').checked,
        lineStyle: parseInt(panel.querySelector('input[name="ls-st"]:checked')?.value ?? '2'),
        lineWidth: parseInt(document.getElementById('ls-w').value),
        fontSize: parseInt(document.getElementById('ls-fs').value),
        fontBold: document.getElementById('ls-bold').checked,
        horzAlign: panel.querySelector('input[name="ls-ha"]:checked')?.value ?? 'right',
        vertAlign: 'bottom',
        aboveColor: document.getElementById('ls-ac').value,
        belowColor: document.getElementById('ls-bc').value,
      };
      saveChartSettings();
      redrawAllTVLines();
      panel.remove();
    };
  }

  window.addEventListener('kta-alarms', e => {
    const alarms = e.detail || [];
    latestAlarms = alarms;
    syncFab();
    if (!_chart) { pendingAlarms = alarms; return; }
    drawTVLines();
  });

  function saveChartSettings() {
    window.dispatchEvent(new CustomEvent('kta-save-line-settings', { detail: { ...lineSettings, panelTheme } }));
  }

  window.addEventListener('kta-line-settings', e => {
    const d = e.detail || {};
    Object.assign(lineSettings, d);
    if (d.panelTheme) panelTheme = d.panelTheme;
  });

  window.addEventListener('kta-update-memo', e => {
    const { id, memo } = e.detail || {};
    const idx = latestAlarms.findIndex(a => a.id === id);
    if (idx >= 0) latestAlarms[idx].memo = memo;
    const entry = _shapeMap.get(id);
    if (entry) {
      try { _chart?.removeEntity(entry.eid); } catch(e) {}
      _shapeMap.delete(id);
    }
    drawTVLines();
  });
})();
