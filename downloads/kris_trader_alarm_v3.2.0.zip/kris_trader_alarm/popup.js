'use strict';

const UPBIT_STORAGE_KEY = 'upbit_alarms_v2';
const BITHUMB_STORAGE_KEY = 'bithumb_alarms_v1';
const SETTINGS_KEY = 'upbit_alarm_settings_v1';
const HISTORY_KEY = 'kta_alarm_history_v1';

const DEFAULT_SETTINGS = {
  sound: 'fanfare',
  volume: 70,
  reactivate: 'custom',
  reactivateMinutes: 1,
  linkTarget: 'current',
  theme: 'light',
  quickAddBtn: true,
  ntfyEnabled: false,
  ntfyTopic: '',
  ntfyCooldown: 30
};

let currentExchange = 'upbit';
let upbitAlarms = [];
let bithumbAlarms = [];
let upbitMarkets = [];
let bithumbMarkets = [];
let upbitPrices = {};
let bithumbPrices = {};
let settings = { ...DEFAULT_SETTINGS };
let manageMode = false;
let acIdx = -1;
let collapsedGroups = { upbit: new Set(), bithumb: new Set() };
let editingId = null;
let currentPageSym = null;

function isActive(a) { return !a.fired && !a.disabled; }
function getAlarms() { return currentExchange === 'upbit' ? upbitAlarms : bithumbAlarms; }
function setAlarms(arr) { if (currentExchange === 'upbit') upbitAlarms = arr; else bithumbAlarms = arr; }
function getMarkets() { return currentExchange === 'upbit' ? upbitMarkets : bithumbMarkets; }
function getPrices() { return currentExchange === 'upbit' ? upbitPrices : bithumbPrices; }
function getStorageKey() { return currentExchange === 'upbit' ? UPBIT_STORAGE_KEY : BITHUMB_STORAGE_KEY; }
function getCollapsed() { return collapsedGroups[currentExchange]; }
function getGroupKey(a) { return currentExchange === 'upbit' ? a.code : a.sym; }
function getCoinUrl(a) {
  return currentExchange === 'upbit'
    ? `https://upbit.com/exchange?code=CRIX.UPBIT.${a.code}`
    : `https://www.bithumb.com/react/trade/order/${a.sym}-KRW`;
}

// ── Theme ─────────────────────────────────────────────────────────────
function applyTheme(t) {
  document.body.classList.toggle('light', t === 'light');
  const btn = document.getElementById('btn-theme');
  if (btn) btn.textContent = t === 'light' ? '🌙' : '☀';
}

// ── Storage ──────────────────────────────────────────────────────────
function loadAllAlarms() {
  return new Promise(resolve => {
    chrome.storage.local.get([UPBIT_STORAGE_KEY, BITHUMB_STORAGE_KEY], data => {
      upbitAlarms = data[UPBIT_STORAGE_KEY] || [];
      bithumbAlarms = data[BITHUMB_STORAGE_KEY] || [];
      resolve();
    });
  });
}

function saveAlarms() {
  chrome.storage.local.set({ [getStorageKey()]: getAlarms() });
}

function loadSettings() {
  return new Promise(resolve => {
    chrome.storage.local.get(SETTINGS_KEY, data => {
      settings = { ...DEFAULT_SETTINGS, ...(data[SETTINGS_KEY] || {}) };
      resolve();
    });
  });
}

function saveSettings(s) {
  chrome.storage.local.set({ [SETTINGS_KEY]: s });
}

// ── API ──────────────────────────────────────────────────────────────
async function fetchUpbitPrices() {
  const codes = [...new Set(upbitAlarms.map(a => a.code))];
  if (!codes.length) return;
  try {
    const r = await fetch(`https://api.upbit.com/v1/ticker?markets=${codes.join(',')}`);
    const data = await r.json();
    data.forEach(d => { upbitPrices[d.market] = d.trade_price; });
  } catch {}
}

async function fetchUpbitMarkets() {
  try {
    const r = await fetch('https://api.upbit.com/v1/market/all?isDetails=false');
    const data = await r.json();
    upbitMarkets = data
      .filter(m => m.market.startsWith('KRW-'))
      .map(m => ({ code: m.market, sym: m.market.replace('KRW-', ''), kor: m.korean_name, eng: m.english_name }));
  } catch {}
}

async function loadBithumbData() {
  try {
    const [tickerRes, marketRes] = await Promise.all([
      fetch('https://api.bithumb.com/public/ticker/ALL_KRW'),
      fetch('https://api.bithumb.com/v1/market/all').catch(() => null)
    ]);
    const data = await tickerRes.json();
    if (data.status !== '0000') return;
    const korMap = {};
    upbitMarkets.forEach(m => { korMap[m.sym] = m.kor; });
    if (marketRes && marketRes.ok) {
      const mData = await marketRes.json();
      mData.filter(m => m.market.startsWith('KRW-')).forEach(m => {
        const sym = m.market.replace('KRW-', '');
        if (!korMap[sym]) korMap[sym] = m.korean_name;
      });
    }
    bithumbMarkets = [];
    Object.entries(data.data).forEach(([sym, info]) => {
      if (sym === 'date') return;
      bithumbMarkets.push({ sym, kor: korMap[sym] || '' });
      bithumbPrices[sym] = parseFloat(info.closing_price);
    });
    bithumbMarkets.sort((a, b) => a.sym.localeCompare(b.sym));
  } catch {}
}

async function fetchPrices() {
  if (!upbitMarkets.length) await fetchUpbitMarkets();
  await Promise.all([fetchUpbitPrices(), loadBithumbData()]);
}

async function prefetchCoinPrice(sym) {
  if (currentExchange === 'upbit') {
    const key = `KRW-${sym}`;
    if (upbitPrices[key]) return;
    try {
      const r = await fetch(`https://api.upbit.com/v1/ticker?markets=${key}`);
      const d = await r.json();
      if (d[0]) upbitPrices[key] = d[0].trade_price;
    } catch {}
  } else {
    if (bithumbPrices[sym]) return;
    try {
      const r = await fetch(`https://api.bithumb.com/public/ticker/${sym}_KRW`);
      const d = await r.json();
      if (d.status === '0000') bithumbPrices[sym] = parseFloat(d.data.closing_price);
    } catch {}
  }
}

// ── Sound ─────────────────────────────────────────────────────────────
function previewSound(soundName) {
  if (soundName === 'none') return;
  fetch(chrome.runtime.getURL(`sounds/${soundName}.wav`)).then(r=>r.blob()).then(blob=>{const u=URL.createObjectURL(blob);const a=new Audio(u);a.volume=(settings.volume??70)/100;a.play().catch(()=>{});a.addEventListener('ended',()=>URL.revokeObjectURL(u));}).catch(()=>{});
}

// ── Render ───────────────────────────────────────────────────────────
function render() {
  const alarms = getAlarms();
  const prices = getPrices();
  const collapsed = getCollapsed();
  const listEl = document.getElementById('alarm-list');
  const emptyEl = document.getElementById('empty-state');
  const footerEl = document.getElementById('manage-footer');

  document.querySelectorAll('.exch-tab').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.exch === currentExchange);
  });

  if (!alarms.length) {
    listEl.innerHTML = '';
    emptyEl.style.display = 'block';
    footerEl.style.display = 'none';
    return;
  }
  emptyEl.style.display = 'none';
  footerEl.style.display = manageMode ? 'flex' : 'none';

  const groupMap = new Map();
  alarms.forEach(a => {
    const key = getGroupKey(a);
    if (!groupMap.has(key)) groupMap.set(key, []);
    groupMap.get(key).push(a);
  });

  const groupEntries = [...groupMap.entries()];
  if (currentPageSym) {
    groupEntries.sort(([keyA], [keyB]) => {
      const aMatch = (currentExchange === 'upbit' ? keyA.replace('KRW-', '') : keyA).toUpperCase() === currentPageSym;
      const bMatch = (currentExchange === 'upbit' ? keyB.replace('KRW-', '') : keyB).toUpperCase() === currentPageSym;
      return aMatch === bMatch ? 0 : aMatch ? -1 : 1;
    });
  }

  listEl.innerHTML = groupEntries.map(([key, grpAlarms]) => {
    const sym = currentExchange === 'upbit' ? key.replace('KRW-', '') : key;
    const isCurrentPage = currentPageSym && sym.toUpperCase() === currentPageSym;
    const kor = grpAlarms[0].kor || '';
    const curPrice = prices[key];
    const isCollapsed = collapsed.has(key);

    const itemsHtml = grpAlarms.map(a => {
      const dirText = a.dir === 'above' ? '↑ 이상' : '↓ 이하';
      const active = isActive(a);

      if (manageMode) {
        return `<div class="alarm-item">
          <input type="checkbox" class="chk-box alarm-chk" data-id="${a.id}"/>
          <span class="alarm-dir">${dirText}</span>
          <span class="alarm-price">${Number(a.price).toLocaleString()}원</span>
        </div>`;
      }

      if (editingId === a.id) {
        return `<div class="alarm-item editing">
          <div class="alarm-main">
            <select class="edit-dir" data-id="${a.id}">
              <option value="above" ${a.dir === 'above' ? 'selected' : ''}>↑ 이상</option>
              <option value="below" ${a.dir === 'below' ? 'selected' : ''}>↓ 이하</option>
            </select>
            <input type="number" class="edit-price" data-id="${a.id}" value="${a.price}"/>
            <div class="alarm-actions">
              <button class="btn-edit-save" data-id="${a.id}">저장</button>
              <button class="btn-edit-cancel">취소</button>
            </div>
          </div>
          <input type="text" class="edit-memo" placeholder="비고 (선택)" value="${a.memo || ''}"/>
        </div>`;
      }

      return `<div class="alarm-item">
        <span class="alarm-dir editable" data-id="${a.id}">${dirText}</span>
        <span class="alarm-price editable" data-id="${a.id}">${Number(a.price).toLocaleString()}원</span>
        <span class="alarm-memo-text">${a.memo || ''}</span>
        <div class="alarm-actions">
          <label class="toggle" title="${active ? '비활성화' : '다시 활성화'}">
            <input type="checkbox" class="toggle-chk" data-id="${a.id}" ${active ? 'checked' : ''}/>
            <span class="toggle-slider"></span>
          </label>
          <button class="btn-del" data-id="${a.id}">×</button>
        </div>
      </div>`;
    }).join('');

    const groupChk = manageMode
      ? `<input type="checkbox" class="chk-box group-chk" data-key="${key}"/>`
      : '';

    return `<div class="group${isCurrentPage ? ' group-current' : ''}" data-key="${key}">
      <div class="group-hdr">
        ${groupChk}
        ${isCurrentPage ? '<span class="badge-current">📍</span>' : ''}
        <span class="group-sym coin-link" data-key="${key}">${sym}</span>
        ${kor ? `<span class="group-kor">${kor}</span>` : ''}
        <span class="group-cur">${curPrice ? '현재: ' + Number(curPrice).toLocaleString() + '원' : ''}</span>
        <span class="group-chevron">${isCollapsed ? '›' : '⌄'}</span>
      </div>
      <div class="group-body${isCollapsed ? ' collapsed' : ''}">${itemsHtml}</div>
    </div>`;
  }).join('');

  listEl.querySelectorAll('.coin-link').forEach(el => {
    el.addEventListener('click', e => {
      e.stopPropagation();
      const key = el.dataset.key;
      const alarm = getAlarms().find(a => getGroupKey(a) === key);
      const url = alarm ? getCoinUrl(alarm) : '';
      if (!url) return;
      if (settings.linkTarget === 'current') {
        chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
          if (tabs[0]) chrome.tabs.update(tabs[0].id, { url });
        });
      } else {
        chrome.tabs.create({ url });
      }
    });
  });

  listEl.querySelectorAll('.group-hdr').forEach(hdr => {
    hdr.addEventListener('click', e => {
      if (e.target.closest('.chk-box') || e.target.closest('.coin-link')) return;
      const key = hdr.closest('.group').dataset.key;
      const c = getCollapsed();
      if (c.has(key)) c.delete(key); else c.add(key);
      render();
    });
  });

  if (!manageMode) {
    listEl.querySelectorAll('.toggle-chk').forEach(chk => {
      chk.addEventListener('change', e => {
        e.stopPropagation();
        const alarm = getAlarms().find(a => a.id === +chk.dataset.id);
        if (!alarm) return;
        if (chk.checked) { alarm.fired = false; alarm.disabled = false; }
        else { alarm.disabled = true; }
        saveAlarms();
        render();
      });
    });
    listEl.querySelectorAll('.btn-del').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        setAlarms(getAlarms().filter(a => a.id !== +btn.dataset.id));
        saveAlarms();
        render();
      });
    });
    listEl.querySelectorAll('.editable').forEach(el => {
      el.addEventListener('click', e => {
        e.stopPropagation();
        editingId = +el.dataset.id;
        render();
        const inp = listEl.querySelector('.edit-price');
        if (inp) { inp.focus(); inp.select(); }
      });
    });
    listEl.querySelectorAll('.btn-edit-save').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        const id = +btn.dataset.id;
        const alarm = getAlarms().find(a => a.id === id);
        if (alarm) {
          const dirEl = listEl.querySelector(`.edit-dir[data-id="${id}"]`);
          const priceEl = listEl.querySelector(`.edit-price[data-id="${id}"]`);
          const memoEl = listEl.querySelector('.edit-memo');
          const newPrice = parseFloat(priceEl?.value);
          if (!isNaN(newPrice) && newPrice > 0) {
            alarm.dir = dirEl?.value || alarm.dir;
            alarm.price = newPrice;
            alarm.fired = false;
          }
          alarm.memo = memoEl?.value.trim() || '';
        }
        editingId = null;
        saveAlarms();
        render();
      });
    });
    listEl.querySelectorAll('.btn-edit-cancel').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        editingId = null;
        render();
      });
    });
    listEl.querySelectorAll('.edit-price').forEach(priceEl => {
      priceEl.addEventListener('input', () => {
        const targetPrice = parseFloat(priceEl.value);
        if (!targetPrice || targetPrice <= 0) return;
        const id = +priceEl.dataset.id;
        const alarm = getAlarms().find(a => a.id === id);
        if (!alarm) return;
        const key = currentExchange === 'upbit' ? `KRW-${alarm.sym}` : alarm.sym;
        const curPrice = getPrices()[key];
        if (!curPrice) return;
        const dirEl = listEl.querySelector(`.edit-dir[data-id="${id}"]`);
        if (dirEl) dirEl.value = targetPrice >= curPrice ? 'above' : 'below';
      });
    });
  } else {
    listEl.querySelectorAll('.group-chk').forEach(gChk => {
      gChk.addEventListener('change', e => {
        e.stopPropagation();
        listEl.querySelectorAll('.alarm-chk').forEach(c => {
          const alarm = getAlarms().find(a => a.id === +c.dataset.id);
          if (alarm && getGroupKey(alarm) === gChk.dataset.key) c.checked = gChk.checked;
        });
        syncSelectAll();
      });
    });
    listEl.querySelectorAll('.alarm-chk').forEach(c => c.addEventListener('change', syncSelectAll));
  }
}

function syncSelectAll() {
  const all = document.querySelectorAll('.alarm-chk');
  const checked = document.querySelectorAll('.alarm-chk:checked');
  const chkAll = document.getElementById('chk-all');
  if (chkAll) chkAll.checked = all.length > 0 && all.length === checked.length;
}

// ── Chosung ───────────────────────────────────────────────────────────
const CHOSUNG = ['ㄱ','ㄲ','ㄴ','ㄷ','ㄸ','ㄹ','ㅁ','ㅂ','ㅃ','ㅅ','ㅆ','ㅇ','ㅈ','ㅉ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ'];
function getChosung(ch) {
  const c = ch.charCodeAt(0) - 0xAC00;
  return (c >= 0 && c <= 11171) ? CHOSUNG[Math.floor(c / 588)] : ch;
}
function toChosung(str) { return [...str].map(getChosung).join(''); }
function isAllChosung(str) { return /^[ㄱ-ㅎ]+$/.test(str); }
function isKoreanInput(str) { return /^[ㄱ-ㅎㅏ-ㅣ가-힣]+$/.test(str); }

// ── 영타→한타 변환 (두벌식) ──────────────────────────────────────────
const ENG_TO_KOR = {
  q:'ㅂ',w:'ㅈ',e:'ㄷ',r:'ㄱ',t:'ㅅ',y:'ㅛ',u:'ㅕ',i:'ㅑ',o:'ㅐ',p:'ㅔ',
  a:'ㅁ',s:'ㄴ',d:'ㅇ',f:'ㄹ',g:'ㅎ',h:'ㅗ',j:'ㅓ',k:'ㅏ',l:'ㅣ',
  z:'ㅋ',x:'ㅌ',c:'ㅊ',v:'ㅍ',b:'ㅠ',n:'ㅜ',m:'ㅡ'
};

// 두벌식 자모 → 완성형 한글 조합
const CHO  = ['ㄱ','ㄲ','ㄴ','ㄷ','ㄸ','ㄹ','ㅁ','ㅂ','ㅃ','ㅅ','ㅆ','ㅇ','ㅈ','ㅉ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ'];
const JUNG = ['ㅏ','ㅐ','ㅑ','ㅒ','ㅓ','ㅔ','ㅕ','ㅖ','ㅗ','ㅘ','ㅙ','ㅚ','ㅛ','ㅜ','ㅝ','ㅞ','ㅟ','ㅠ','ㅡ','ㅢ','ㅣ'];
const JONG = ['','ㄱ','ㄲ','ㄳ','ㄴ','ㄵ','ㄶ','ㄷ','ㄹ','ㄺ','ㄻ','ㄼ','ㄽ','ㄾ','ㄿ','ㅀ','ㅁ','ㅂ','ㅄ','ㅅ','ㅆ','ㅇ','ㅈ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ'];
const JONG_TO_CHO = {'ㄱ':0,'ㄲ':1,'ㄴ':2,'ㄷ':3,'ㄹ':5,'ㅁ':6,'ㅂ':7,'ㅅ':9,'ㅆ':10,'ㅇ':11,'ㅈ':12,'ㅊ':14,'ㅋ':15,'ㅌ':16,'ㅍ':17,'ㅎ':18};

function composeJamo(jamo) {
  let result = '';
  let cho = -1, jung = -1, jong = -1;
  const flush = () => {
    if (cho < 0) return;
    if (jung < 0) { result += CHO[cho]; cho = -1; return; }
    result += String.fromCharCode(0xAC00 + (cho * 21 + jung) * 28 + jong + 1);
    cho = -1; jung = -1; jong = -1;
  };
  for (const ch of jamo) {
    const ci = CHO.indexOf(ch), vi = JUNG.indexOf(ch), ji = JONG.indexOf(ch);
    if (vi >= 0) { // 모음
      if (cho >= 0 && jung < 0) { jung = vi; }
      else if (cho >= 0 && jung >= 0 && jong >= 0) {
        // 종성을 초성으로 분리
        const prevJong = jong; jong = -1;
        flush();
        cho = JONG_TO_CHO[JONG[prevJong + 1]] ?? -1;
        jung = vi;
      } else { flush(); result += ch; }
    } else if (ci >= 0) { // 자음 (초성 후보)
      if (cho >= 0 && jung >= 0 && jong < 0) {
        // 종성 시도
        const ji2 = JONG.indexOf(ch, 1);
        if (ji2 > 0) { jong = ji2 - 1; } else flush();
        if (jong < 0) { cho = ci; }
      } else { flush(); cho = ci; }
    } else { flush(); result += ch; }
  }
  flush();
  return result;
}

function engToKorStr(str) {
  const jamo = str.toLowerCase().split('').map(c => ENG_TO_KOR[c] || c).join('');
  return composeJamo(jamo);
}

// ── Autocomplete ─────────────────────────────────────────────────────
function showAC(query) {
  const ac = document.getElementById('ac-list');
  const markets = getMarkets();
  if (!query || !markets.length) { ac.style.display = 'none'; acIdx = -1; return; }
  const q = query.toUpperCase();
  const csQuery = isAllChosung(query) ? query : null;
  const isKo = isKoreanInput(query);
  const isEng = !isKo && /^[a-zA-Z]+$/.test(query);
  const converted = isEng ? engToKorStr(query) : null;       // 완성형 한글

  const filtered = markets.filter(m => {
    if (isKo) return (m.kor && m.kor.includes(query)) || (csQuery && m.kor && toChosung(m.kor).includes(csQuery));
    if (m.sym.includes(q)) return true;
    if (converted && m.kor && m.kor.includes(converted)) return true;
    return false;
  });
  filtered.sort((a, b) => a.sym.localeCompare(b.sym));
  const matched = filtered.slice(0, 20);
  if (!matched.length) { ac.style.display = 'none'; acIdx = -1; return; }
  acIdx = -1;
  ac.innerHTML = matched.map(m =>
    `<div class="ac-item" data-sym="${m.sym}">
      <span class="ac-sym">${m.sym}</span>${m.kor ? `<span class="ac-kor">${m.kor}</span>` : ''}
    </div>`
  ).join('');
  ac.querySelectorAll('.ac-item').forEach(el => {
    el.addEventListener('mousedown', e => { e.preventDefault(); selectAC(el.dataset.sym); });
  });
  ac.style.display = 'block';
}

function hideAC() {
  const ac = document.getElementById('ac-list');
  if (ac) ac.style.display = 'none';
  acIdx = -1;
}

function selectAC(sym) {
  document.getElementById('coin-input').value = sym;
  hideAC();
  document.getElementById('price-input').focus();
  prefetchCoinPrice(sym);
}

function moveAC(dir) {
  const ac = document.getElementById('ac-list');
  if (!ac || ac.style.display === 'none') return;
  const items = ac.querySelectorAll('.ac-item');
  if (!items.length) return;
  if (acIdx >= 0) items[acIdx].classList.remove('active');
  acIdx = Math.max(0, Math.min(acIdx + dir, items.length - 1));
  items[acIdx].classList.add('active');
  items[acIdx].scrollIntoView({ block: 'nearest' });
}

// ── Views ─────────────────────────────────────────────────────────────
function showView(id) {
  ['view-main','view-add','view-settings','view-history'].forEach(v => {
    document.getElementById(v).style.display = v === id ? 'flex' : 'none';
  });
}

// ── Settings UI ───────────────────────────────────────────────────────
// ── History ───────────────────────────────────────────────────────────
function loadHistory() {
  chrome.storage.local.get(HISTORY_KEY, data => {
    const history = data[HISTORY_KEY] || [];
    // Mark all as read
    if (history.some(h => h.unread)) {
      history.forEach(h => { h.unread = false; });
      chrome.storage.local.set({ [HISTORY_KEY]: history });
    }
    renderHistory(history);
  });
}

function renderHistory(history) {
  const listEl = document.getElementById('history-list');
  const emptyEl = document.getElementById('history-empty');
  if (!history.length) {
    listEl.innerHTML = '';
    emptyEl.style.display = 'block';
    return;
  }
  emptyEl.style.display = 'none';
  const now = Date.now();
  listEl.innerHTML = history.map((h, i) => {
    const dirText = h.dir === 'above' ? '이상 도달' : '이하 도달';
    const diff = now - h.firedAt;
    let timeStr;
    if (diff < 60000) timeStr = '방금';
    else if (diff < 3600000) timeStr = `${Math.floor(diff / 60000)}분 전`;
    else if (diff < 86400000) timeStr = new Date(h.firedAt).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' });
    else timeStr = new Date(h.firedAt).toLocaleDateString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    return `<div class="history-item${h.unread ? ' unread' : ''}" data-idx="${i}" style="cursor:pointer;">
      <div class="history-top">
        <span class="history-exchange ${h.exchange}">${h.exchange === 'upbit' ? '업비트' : '빗썸'}</span>
        <span class="history-label">${h.label}</span>
        <span class="history-time">${timeStr}</span>
      </div>
      <div class="history-detail">${Number(h.price).toLocaleString()}원 ${dirText} · 현재가 ${Number(h.currentPrice).toLocaleString()}원</div>
      ${h.memo ? `<div class="history-memo">${h.memo}</div>` : ''}
    </div>`;
  }).join('');
  listEl.querySelectorAll('.history-item[data-idx]').forEach(el => {
    el.addEventListener('click', () => {
      const h = history[parseInt(el.dataset.idx)];
      const url = h.exchange === 'bithumb'
        ? `https://www.bithumb.com/react/trade/order/${h.sym}-KRW`
        : `https://upbit.com/exchange?code=CRIX.UPBIT.KRW-${h.sym}`;
      if (settings.linkTarget === 'current') {
        chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
          if (tabs[0]) chrome.tabs.update(tabs[0].id, { url });
        });
      } else {
        chrome.tabs.create({ url });
      }
    });
  });
}

function loadSettingsUI() {
  document.getElementById('sound-select').value = settings.sound;
  const vol = settings.volume ?? 70;
  document.getElementById('vol-slider').value = vol;
  document.getElementById('vol-pct').textContent = vol + '%';
  const val = settings.reactivate;
  document.querySelectorAll('input[name=reactivate]').forEach(r => { r.checked = r.value === val; });
  document.getElementById('custom-minutes').value = settings.reactivateMinutes || 60;
  document.querySelectorAll('input[name=linkTarget]').forEach(r => {
    r.checked = r.value === (settings.linkTarget || 'current');
  });
  const qab = document.getElementById('chk-quick-add');
  if (qab) qab.checked = settings.quickAddBtn !== false;
  const ntfyChk = document.getElementById('chk-ntfy');
  if (ntfyChk) {
    ntfyChk.checked = settings.ntfyEnabled || false;
    document.getElementById('ntfy-config').style.display = ntfyChk.checked ? 'flex' : 'none';
    document.getElementById('ntfy-topic').value = settings.ntfyTopic || '';
    document.querySelectorAll('input[name=ntfyCooldown]').forEach(r => {
      r.checked = r.value === String(settings.ntfyCooldown ?? 30);
    });
  }
}

// ── Exchange switch ───────────────────────────────────────────────────
function switchExchange(exch) {
  if (currentExchange === exch) return;
  currentExchange = exch;
  manageMode = false;
  editingId = null;
  document.getElementById('btn-manage').textContent = '관리';
  document.getElementById('btn-new').style.display = '';
  document.getElementById('btn-theme').style.display = '';
  document.getElementById('btn-history').style.display = '';
  document.getElementById('btn-settings').style.display = '';
  render();
}

// ── Init ─────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await Promise.all([loadAllAlarms(), loadSettings()]);
  applyTheme(settings.theme || 'dark');

  chrome.storage.local.get('pendingUpdate', data => {
    if (data.pendingUpdate) {
      const banner = document.getElementById('update-banner');
      banner.style.display = 'block';
      banner.addEventListener('click', () => {
        chrome.tabs.create({ url: data.pendingUpdate.page });
      });
    }
  });

  document.querySelector('.popup-logo').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://regina25846-code.github.io/kris-trader-alarm/manual.html' });
  });

  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const url = tabs[0]?.url || '';
    if (url.includes('bithumb.com')) currentExchange = 'bithumb';
    else currentExchange = 'upbit';
    const upbitMatch   = url.match(/[?&]code=CRIX\.UPBIT\.KRW-([A-Z0-9]+)/i);
    const bithumbMatch = url.match(/\/trade\/order\/([A-Z0-9]+)-KRW/i);
    currentPageSym = (upbitMatch?.[1] || bithumbMatch?.[1] || '').toUpperCase() || null;
    render();
  });

  function applyQuickAdd(sym) {
    showView('view-add');
    setTimeout(() => {
      const input = document.getElementById('coin-input');
      input.value = sym;
      input.dispatchEvent(new Event('input'));
      setTimeout(() => {
        const first = document.querySelector('.ac-item');
        if (first) first.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
      }, 150);
    }, 100);
  }

  chrome.storage.local.get('quickAddSym', data => {
    if (data.quickAddSym) {
      chrome.storage.local.remove('quickAddSym');
      applyQuickAdd(data.quickAddSym);
    }
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.quickAddSym?.newValue) {
      chrome.storage.local.remove('quickAddSym');
      applyQuickAdd(changes.quickAddSym.newValue);
    }
  });

  fetchUpbitMarkets();
  fetchPrices().then(render);

  document.querySelectorAll('.exch-tab').forEach(btn => {
    btn.addEventListener('click', () => switchExchange(btn.dataset.exch));
  });

  document.getElementById('btn-theme').addEventListener('click', () => {
    settings.theme = settings.theme === 'light' ? 'dark' : 'light';
    applyTheme(settings.theme);
    saveSettings(settings);
  });

  document.getElementById('btn-manage').addEventListener('click', () => {
    manageMode = !manageMode;
    document.getElementById('btn-manage').textContent = manageMode ? '완료' : '관리';
    document.getElementById('btn-new').style.display = manageMode ? 'none' : '';
    document.getElementById('btn-theme').style.display = manageMode ? 'none' : '';
    document.getElementById('btn-history').style.display = manageMode ? 'none' : '';
    document.getElementById('btn-settings').style.display = manageMode ? 'none' : '';
    render();
  });

  document.getElementById('btn-new').addEventListener('click', () => {
    const exchName = currentExchange === 'upbit' ? '업비트' : '빗썸';
    document.getElementById('add-title').textContent = `알람 추가 — ${exchName}`;
    const ph = currentExchange === 'upbit' ? 'BTC, 비트코인...' : 'BTC, ETH...';
    document.getElementById('coin-input').placeholder = ph;
    showView('view-add');
    setTimeout(() => document.getElementById('coin-input').focus(), 50);
  });
  document.getElementById('btn-back').addEventListener('click', () => { showView('view-main'); render(); });

  document.getElementById('btn-settings').addEventListener('click', () => {
    loadSettingsUI();
    showView('view-settings');
  });
  document.getElementById('btn-settings-back').addEventListener('click', () => showView('view-main'));

  document.getElementById('btn-history').addEventListener('click', () => {
    loadHistory();
    showView('view-history');
  });
  document.getElementById('btn-history-back').addEventListener('click', () => showView('view-main'));
  document.getElementById('btn-clear-history').addEventListener('click', () => {
    chrome.storage.local.remove(HISTORY_KEY, () => renderHistory([]));
  });

  document.getElementById('btn-preview').addEventListener('click', () => {
    previewSound(document.getElementById('sound-select').value);
  });

  document.getElementById('vol-slider').addEventListener('input', function () {
    document.getElementById('vol-pct').textContent = this.value + '%';
    settings.volume = parseInt(this.value);
    saveSettings(settings);
  });

  document.getElementById('btn-save-settings').addEventListener('click', () => {
    const s = {
      sound: document.getElementById('sound-select').value,
      volume: parseInt(document.getElementById('vol-slider').value) ?? 70,
      reactivate: document.querySelector('input[name=reactivate]:checked')?.value || 'instant',
      reactivateMinutes: parseInt(document.getElementById('custom-minutes').value) || 60,
      linkTarget: document.querySelector('input[name=linkTarget]:checked')?.value || 'current',
      theme: settings.theme || 'light',
      quickAddBtn: document.getElementById('chk-quick-add')?.checked ?? true,
      ntfyEnabled: document.getElementById('chk-ntfy')?.checked || false,
      ntfyTopic: document.getElementById('ntfy-topic')?.value.trim() || '',
      ntfyCooldown: parseInt(document.querySelector('input[name=ntfyCooldown]:checked')?.value) || 30
    };
    settings = s;
    saveSettings(s);
    showView('view-main');
  });

  document.getElementById('chk-ntfy')?.addEventListener('change', function () {
    document.getElementById('ntfy-config').style.display = this.checked ? 'flex' : 'none';
  });

  document.getElementById('btn-ntfy-test')?.addEventListener('click', () => {
    const topic = document.getElementById('ntfy-topic').value.trim();
    if (!topic) { alert('토픽명을 먼저 입력하세요.'); return; }
    chrome.runtime.sendMessage({ action: 'ntfyTest', topic }, res => {
      if (res && res.ok) alert(`테스트 푸시 전송 완료! (${res.status})`);
      else alert(`전송 실패: ${res?.error || '알 수 없는 오류'}`);
    });
  });

  document.getElementById('btn-export').addEventListener('click', () => {
    const alarms = getAlarms();
    const blob = new Blob([JSON.stringify(alarms, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${currentExchange}_alarms_${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  });

  document.getElementById('btn-import').addEventListener('click', () => {
    document.getElementById('import-file').click();
  });
  document.getElementById('import-file').addEventListener('change', function () {
    const file = this.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = e => {
      try {
        const imported = JSON.parse(e.target.result);
        if (!Array.isArray(imported)) { alert('올바른 알람 JSON 파일이 아니에요'); return; }
        // Auto-detect exchange from file content: upbit uses 'KRW-xxx' codes
        const isUpbitFile = imported.some(a => typeof a.code === 'string' && a.code.startsWith('KRW-'));
        const targetAlarms = isUpbitFile ? upbitAlarms : bithumbAlarms;
        const targetKey = isUpbitFile ? UPBIT_STORAGE_KEY : BITHUMB_STORAGE_KEY;
        const merged = [...targetAlarms];
        imported.forEach(a => {
          const idx = merged.findIndex(x => x.id === a.id);
          if (idx >= 0) Object.assign(merged[idx], a);
          else merged.push(a);
        });
        if (isUpbitFile) upbitAlarms = merged; else bithumbAlarms = merged;
        chrome.storage.local.set({ [targetKey]: merged });
        const exchName = isUpbitFile ? '업비트' : '빗썸';
        showView('view-main');
        render();
        alert(`${exchName} 알람 ${imported.length}개 가져오기 완료`);
      } catch { alert('파일 파싱 오류'); }
    };
    reader.readAsText(file);
    this.value = '';
  });

  document.getElementById('chk-all').addEventListener('change', function () {
    document.querySelectorAll('.alarm-chk').forEach(c => c.checked = this.checked);
  });
  document.getElementById('btn-delete-sel').addEventListener('click', () => {
    const ids = new Set([...document.querySelectorAll('.alarm-chk:checked')].map(c => +c.dataset.id));
    if (!ids.size) return;
    setAlarms(getAlarms().filter(a => !ids.has(a.id)));
    saveAlarms();
    if (!getAlarms().length) {
      manageMode = false;
      document.getElementById('btn-manage').textContent = '관리';
      document.getElementById('btn-new').style.display = '';
      document.getElementById('btn-theme').style.display = '';
      document.getElementById('btn-history').style.display = '';
      document.getElementById('btn-settings').style.display = '';
    }
    render();
  });

  const coinInput = document.getElementById('coin-input');
  const priceInput = document.getElementById('price-input');
  const dirSelect = document.getElementById('dir-select');
  const memoInput = document.getElementById('memo-input');

  coinInput.addEventListener('input', () => showAC(coinInput.value.trim()));
  coinInput.addEventListener('blur', () => setTimeout(hideAC, 150));
  coinInput.addEventListener('keydown', e => {
    const ac = document.getElementById('ac-list');
    const open = ac && ac.style.display !== 'none';
    if (e.key === 'ArrowDown') { e.preventDefault(); if (open) moveAC(1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); if (open) moveAC(-1); }
    else if (e.key === 'Enter') {
      if (open && acIdx >= 0) { e.preventDefault(); const act = ac.querySelector('.ac-item.active'); if (act) selectAC(act.dataset.sym); }
      else document.getElementById('btn-confirm').click();
    } else if (e.key === 'Escape') hideAC();
  });
  priceInput.addEventListener('keydown', e => { if (e.key === 'Enter') document.getElementById('btn-confirm').click(); });
  priceInput.addEventListener('input', async () => {
    const targetPrice = parseFloat(priceInput.value);
    if (!targetPrice || targetPrice <= 0) return;
    const sym = coinInput.value.trim().toUpperCase().replace(/^KRW-/, '');
    if (!sym) return;
    const key = currentExchange === 'upbit' ? `KRW-${sym}` : sym;
    let curPrice = getPrices()[key];
    if (!curPrice) {
      await prefetchCoinPrice(sym);
      curPrice = getPrices()[key];
    }
    if (!curPrice) return;
    dirSelect.value = targetPrice >= curPrice ? 'above' : 'below';
  });

  document.getElementById('btn-confirm').addEventListener('click', () => {
    const coinRaw = coinInput.value.trim();
    const priceVal = parseFloat(priceInput.value);
    const dir = dirSelect.value;
    const memo = memoInput.value.trim();
    if (!coinRaw) { alert('코인을 입력해줘 (예: BTC)'); return; }
    if (!priceVal || priceVal <= 0) { alert('목표 가격을 입력해줘'); return; }
    const sym = coinRaw.toUpperCase().replace(/^KRW-/, '');
    if (currentExchange === 'upbit') {
      const market = upbitMarkets.find(m => m.sym === sym);
      const kor = market ? market.kor : '';
      const label = market ? `${sym}(${kor})` : sym;
      upbitAlarms.push({ id: Date.now(), code: 'KRW-' + sym, sym, kor, label, price: priceVal, dir, memo, fired: false, disabled: false });
    } else {
      bithumbAlarms.push({ id: Date.now(), code: sym, sym, kor: '', label: sym, price: priceVal, dir, memo, fired: false, disabled: false });
    }
    saveAlarms();
    coinInput.value = ''; priceInput.value = ''; dirSelect.value = 'above'; memoInput.value = '';
    hideAC();
    showView('view-main');
    render();
    if (Notification.permission === 'default') Notification.requestPermission();
  });

  chrome.storage.onChanged.addListener(changes => {
    let changed = false;
    if (changes[UPBIT_STORAGE_KEY]) { upbitAlarms = changes[UPBIT_STORAGE_KEY].newValue || []; changed = true; }
    if (changes[BITHUMB_STORAGE_KEY]) { bithumbAlarms = changes[BITHUMB_STORAGE_KEY].newValue || []; changed = true; }
    if (changed) fetchPrices().then(render);
  });
});
