(function () {
  'use strict';

  let _chart = null;
  let latestAlarms = [];
  let pendingAlarms = null;
  let _setupDone = false;
  let panelTheme = 'dark';
  let _shapeMap = new Map(); // alarmId → entityId
  let _pendingIds = new Set(); // createShape 진행 중인 alarmId

  // 알람선 UI 전용 팔레트 — 앱 accent(로즈)가 아니라 업비트 브랜드 남색(#003597) 계열.
  const ICO_SUN  = '<svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor" style="display:inline-block;vertical-align:-1px"><path d="M12 17a5 5 0 1 1 0-10 5 5 0 0 1 0 10Zm0-13.2a1 1 0 0 1-1-1V1.6a1 1 0 1 1 2 0v1.2a1 1 0 0 1-1 1Zm0 19.6a1 1 0 0 1-1-1v-1.2a1 1 0 1 1 2 0v1.2a1 1 0 0 1-1 1ZM22.4 13h-1.2a1 1 0 1 1 0-2h1.2a1 1 0 1 1 0 2Zm-19.6 0H1.6a1 1 0 1 1 0-2h1.2a1 1 0 1 1 0 2Zm16.02-7.42-.85.85a1 1 0 0 1-1.41-1.41l.85-.85a1 1 0 1 1 1.41 1.41ZM6.44 19.14l-.85.85a1 1 0 1 1-1.41-1.41l.85-.85a1 1 0 1 1 1.41 1.41Zm12 1.41-.85-.85a1 1 0 1 1 1.41-1.41l.85.85a1 1 0 0 1-1.41 1.41ZM5.03 6.44l-.85-.85A1 1 0 1 1 5.59 4.18l.85.85a1 1 0 0 1-1.41 1.41Z"/></svg>';
  const ICO_MOON = '<svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor" style="display:inline-block;vertical-align:-1px"><path d="M21.3 14.2A9.2 9.2 0 0 1 9.8 2.7a1 1 0 0 0-1.3-1.2A10.5 10.5 0 1 0 22.5 15.5a1 1 0 0 0-1.2-1.3Z"/></svg>';
  const ICO_BELL = '<svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor" style="display:block"><path d="M12 22a2.2 2.2 0 0 0 2.2-2.2H9.8A2.2 2.2 0 0 0 12 22Zm6.6-6.3V10.6c0-3.3-1.77-6.06-4.84-6.79v-.73a1.76 1.76 0 0 0-3.52 0v.73C7.18 4.54 5.4 7.29 5.4 10.6v5.1L3.6 17.5v.9h16.8v-.9l-1.8-1.8Z"/><path d="M2.6 8.2a1 1 0 0 1-.93-1.37A9.4 9.4 0 0 1 4.9 2.6a1 1 0 1 1 1.2 1.6 7.4 7.4 0 0 0-2.55 3.3 1 1 0 0 1-.95.7Zm18.8 0a1 1 0 0 1-.95-.7 7.4 7.4 0 0 0-2.55-3.3 1 1 0 1 1 1.2-1.6 9.4 9.4 0 0 1 3.23 4.23A1 1 0 0 1 21.4 8.2Z"/></svg>';
  const ICO_X    = '<svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor" style="display:block"><path d="M18.3 5.7a1.1 1.1 0 0 0-1.56 0L12 10.44 7.26 5.7A1.1 1.1 0 1 0 5.7 7.26L10.44 12 5.7 16.74a1.1 1.1 0 1 0 1.56 1.56L12 13.56l4.74 4.74a1.1 1.1 0 0 0 1.56-1.56L13.56 12l4.74-4.74a1.1 1.1 0 0 0 0-1.56Z"/></svg>';
  const ICO_REFRESH = '<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" style="display:inline-block;vertical-align:-2px"><path d="M17.65 6.35A7.95 7.95 0 0 0 12 4a8 8 0 1 0 7.73 10h-2.08A6 6 0 1 1 12 6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35Z"/></svg>';

  function getTheme() {
    return panelTheme === 'dark'
      ? {
          bg: '#1e2127', bg2: '#262a31', inset: '#101216',
          border: '#2e333b', borderStrong: '#3d434d',
          // [2026-08-07] 다크 모드 대비 개선 — t3(#7e8794)는 배경 #1e2127 대비 4.44:1이라
          // 알람선 설정 패널의 작은 라벨이 잘 안 보였다. #9aa3b2로 올려 6.34:1 확보.
          // 라이트 모드(아래 분기) 값은 그대로 둔다.
          text: '#e9ecf1', t2: '#aeb6c2', t3: '#9aa3b2', lbl: '#aeb6c2',
          hl: 'rgba(255,255,255,.055)', sink: 'rgba(0,0,0,.45)',
          grad: 'linear-gradient(180deg, rgba(255,255,255,.05), rgba(255,255,255,0))',
          a1: '#2451c9', a2: '#003597', aInk: '#8fb4ff', aSoft: 'rgba(36,81,201,.18)',
          accent: '#2451c9', accentH: '#003597',
          x: '#7e8794', div: '#2e333b',
          shadow: '0 26px 54px -18px rgba(0,0,0,.7)',
          icon: ICO_SUN, nextLabel: '라이트'
        }
      : {
          bg: '#ffffff', bg2: '#ffffff', inset: '#f2f5fa',
          border: '#dfe4ec', borderStrong: '#c8cfdb',
          text: '#161a21', t2: '#4a5361', t3: '#6c7688', lbl: '#4a5361',
          hl: 'rgba(255,255,255,.9)', sink: 'rgba(15,23,42,.06)',
          grad: 'linear-gradient(180deg, #ffffff, #f7f9fc)',
          a1: '#3b6fe0', a2: '#003597', aInk: '#1d4ed8', aSoft: 'rgba(0,53,151,.10)',
          accent: '#3b6fe0', accentH: '#003597',
          x: '#6c7688', div: '#dfe4ec',
          shadow: '0 26px 54px -18px rgba(16,24,40,.35)',
          icon: ICO_MOON, nextLabel: '다크'
        };
  }

  const DEFAULT_SETTINGS = {
    showBell: false, showArrow: false, showMemo: true, showPrice: false,
    aboveColor: '#ef5350', belowColor: '#26a69a',
    lineStyle: 2, lineWidth: 1,
    fontSize: 11, fontBold: false,
    horzAlign: 'right', vertAlign: 'bottom',
  };
  let lineSettings = { ...DEFAULT_SETTINGS };

  function findChart() {
    try {
      const iframe = document.querySelector('#tv_chart_container iframe');
      if (!iframe) return null;
      const api = iframe.contentWindow?.tradingViewApi;
      if (!api) return null;
      return api.activeChart();
    } catch (e) { return null; }
  }

  setInterval(() => {
    if (!_chart) {
      _chart = findChart();
      if (_chart && !_setupDone) {
        _setupDone = true;
        console.log('[KTA] chart 발견, 이벤트 연결');
        setupEvents();
        const toRender = pendingAlarms ?? latestAlarms;
        pendingAlarms = null;
        if (toRender.length) renderLines(toRender);
      }
    }
    syncFab();
  }, 300);

  function setupEvents() {
    const chart = _chart;
    try {
      chart.onSymbolChanged().subscribe(null, () => {
        clearTVLines();
        window.dispatchEvent(new CustomEvent('kta-symbol-changed'));
      });
    } catch (e) {}
  }

  function buildLabel(alarm) {
    const isAbove = alarm.dir === 'above';
    const parts = [];
    if (lineSettings.showBell) parts.push('🔔');
    if (lineSettings.showArrow) parts.push(isAbove ? '↑' : '↓');
    if (lineSettings.showPrice) parts.push(Number(alarm.price).toLocaleString());
    if (lineSettings.showMemo && alarm.memo) parts.push(alarm.memo);
    return parts.join(' ');
  }

  function clearTVLines() {
    for (const [, entry] of _shapeMap) {
      try { _chart?.removeEntity(entry.eid); } catch (e) {}
    }
    _shapeMap.clear();
    _pendingIds.clear();
  }

  function createShapeFor(a) {
    const alarmId = a.id;
    const price = parseFloat(a.price);
    const isAbove = a.dir === 'above';
    const color = isAbove ? lineSettings.aboveColor : lineSettings.belowColor;
    const label = buildLabel(a);
    const styleMap = { 0: 0, 1: 1, 2: 2 };
    _pendingIds.add(alarmId);
    Promise.resolve(_chart.createShape(
      { price, time: Date.now() / 1000 | 0 },
      {
        shape: 'horizontal_line',
        lock: true,
        disableSelection: true,
        disableSave: true,
        overrides: {
          linecolor: color,
          linewidth: lineSettings.lineWidth,
          linestyle: styleMap[lineSettings.lineStyle] ?? 2,
          showLabel: !!label,
          textcolor: color,
          fontSize: lineSettings.fontSize,
          bold: lineSettings.fontBold,
          text: label,
          horzLabelsAlign: lineSettings.horzAlign,
        }
      }
    )).then(eid => {
      _pendingIds.delete(alarmId);
      if (eid != null) _shapeMap.set(alarmId, { eid, price, label });
    }).catch(() => { _pendingIds.delete(alarmId); });
  }

  function drawTVLines() {
    if (!_chart) return;
    const active = latestAlarms.filter(a => !a.fired && !a.disabled);
    const activeIds = new Set(active.map(a => a.id));

    // 제거된 알람 shape 삭제
    for (const [id, entry] of _shapeMap) {
      if (!activeIds.has(id)) {
        try { _chart.removeEntity(entry.eid); } catch (e) {}
        _shapeMap.delete(id);
      }
    }

    for (const a of active) {
      if (_pendingIds.has(a.id)) continue;
      const price = parseFloat(a.price);
      const label = buildLabel(a);
      const existing = _shapeMap.get(a.id);
      if (existing) {
        // 가격 또는 라벨 변경 시 shape 교체
        if (existing.price === price && existing.label === label) continue;
        try { _chart.removeEntity(existing.eid); } catch (e) {}
        _shapeMap.delete(a.id);
      }
      try { createShapeFor(a); } catch (e) { console.log('[KTA] createShape err:', e.message); }
    }
  }

  function redrawAllTVLines() {
    clearTVLines();
    drawTVLines();
  }

  function renderLines(alarms) {
    latestAlarms = alarms;
    if (!_chart) { pendingAlarms = alarms; return; }
    drawTVLines();
  }

  // ── FAB ──────────────────────────────────────────────────────────────
  function findUpbitLogo() {
    const header = document.querySelector('header');
    if (!header) return null;
    const a = header.querySelector('a');
    if (a) return a;
    return header.firstElementChild || null;
  }

  function getLogoAnchorPos() {
    const el = findUpbitLogo();
    if (!el) return null;
    const r = el.getBoundingClientRect();
    if (!r.width || r.top > 80) return null;
    return {
      l: Math.max(2, Math.round(r.left) - 42),
      t: Math.max(2, Math.round(r.top + (r.height - 32) / 2)),
    };
  }

  function syncFab() {
    const onChart = !!document.getElementById('tv_chart_container');
    const widget = document.getElementById('kta-widget');
    if (!onChart) {
      if (widget) { widget._cleanup?.(); widget.remove(); }
      return;
    }
    if (widget) {
      const pos = getLogoAnchorPos();
      if (pos) { widget.style.left = pos.l + 'px'; widget.style.top = pos.t + 'px'; }
      return;
    }
    const pos = getLogoAnchorPos() || { l: 4, t: 8 };
    const w = document.createElement('div');
    w.id = 'kta-widget';
    w.style.cssText = `position:fixed;left:${pos.l}px;top:${pos.t}px;z-index:2147483647;`;
    w._cleanup = () => {};
    const btn = document.createElement('button');
    btn.id = 'kta-line-fab';
    btn.title = '클릭으로 알람선 설정 열기';
    btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white" width="19" height="19" style="display:block;pointer-events:none;"><path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/></svg>`;
    // 업비트 브랜드 남색(#003597) 유지 — 시안 .kta-fab 그대로
    btn.style.cssText = `display:flex;align-items:center;justify-content:center;width:38px;height:34px;background:linear-gradient(180deg,#2451c9,#003597);border:none;padding:0;border-radius:9px 9px 0 0;cursor:pointer;user-select:none;box-shadow:inset 0 1px 0 rgba(255,255,255,.3), 0 6px 16px -6px #003597;transition:.15s;`;
    w.appendChild(btn);
    document.body.appendChild(w);
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const panel = document.getElementById('kta-line-settings');
      if (panel) panel.remove();
      else showSettingsPanel();
    });
  }

  // ── 설정 패널 ─────────────────────────────────────────────────────────
  function showSettingsPanel() {
    document.getElementById('kta-line-settings')?.remove();
    const widget = document.getElementById('kta-widget');
    if (!widget) return;
    const s = lineSettings;
    const t = getTheme();

    const panel = document.createElement('div');
    panel.id = 'kta-line-settings';
    panel.innerHTML = `
<style>
#kta-line-settings{position:absolute;top:100%;left:0;margin-top:-1px;width:286px;background:${t.grad};background-color:${t.bg};border:1px solid ${t.borderStrong};border-radius:0 13px 13px 13px;padding:13px;color:${t.text};font:13px/1.5 'Pretendard',system-ui,sans-serif;box-shadow:${t.shadow}, inset 0 1px 0 ${t.hl};max-height:calc(100vh - 60px);overflow-y:auto;}
#kta-line-settings *{box-sizing:border-box;}
#kta-line-settings .ls-hd{display:flex;align-items:center;gap:8px;margin-bottom:11px;font-size:14px;font-weight:800;}
#kta-line-settings .ls-hd-left{display:flex;align-items:center;gap:8px;}
#kta-line-settings .ls-hd-ico{color:${t.aInk};}
#kta-line-settings .ls-hd-right{margin-left:auto;display:flex;align-items:center;gap:5px;}
#kta-line-settings .ls-theme{height:28px;padding:0 10px;border-radius:8px;display:inline-flex;align-items:center;gap:5px;font:700 12px 'Pretendard',system-ui,sans-serif;cursor:pointer;background:${t.grad};background-color:${t.bg2};border:1px solid ${t.border};color:${t.t2};box-shadow:inset 0 1px 0 ${t.hl};transition:.15s;white-space:nowrap;}
#kta-line-settings .ls-theme:hover{color:${t.text};border-color:${t.borderStrong};transform:translateY(-1px);}
#kta-line-settings .ls-sec{margin-bottom:11px;}
#kta-line-settings .ls-lbl{display:flex;align-items:center;gap:6px;color:${t.t2};font-size:11.5px;font-weight:800;margin-bottom:6px;}
#kta-line-settings .ls-lbl em{font-style:normal;color:${t.aInk};font-variant-numeric:tabular-nums;}
#kta-line-settings .ls-row{display:flex;gap:8px;flex-wrap:wrap;}
#kta-line-settings label{cursor:pointer;display:inline-flex;align-items:center;gap:6px;font-size:11.5px;font-weight:600;color:${t.t3};background:${t.inset};border:1px solid ${t.border};border-radius:8px;padding:5px 9px;box-shadow:inset 0 1px 3px ${t.sink};transition:.15s;}
#kta-line-settings label:hover{border-color:${t.borderStrong};color:${t.t2};}
#kta-line-settings label:has(input:checked){color:#fff;background:linear-gradient(180deg,${t.a1},${t.a2});border-color:transparent;box-shadow:inset 0 1px 0 rgba(255,255,255,.28);}
#kta-line-settings label input[type=checkbox],#kta-line-settings label input[type=radio]{position:absolute;opacity:0;width:0;height:0;margin:0;}
/* [2026-08-07] 선 스타일 미리보기 스와치.
   기존에는 border-top:2px dashed/dotted 를 썼는데, 폭 22px · 두께 2px 짜리 얇은 조각에서는
   크롬이 파선(dashed)을 거의 실선처럼 그려버려서 "파선인데 실선으로 보인다"는 문제가 있었다.
   border-style의 자동 대시 계산에 맡기지 말고 반복 그라디언트로 길이/간격을 직접 지정한다. */
#kta-line-settings .sp{width:22px;height:2px;border-radius:2px;background:currentColor;display:inline-block;}
#kta-line-settings .sp.dot{border-radius:0;background-image:repeating-linear-gradient(90deg,currentColor 0 2px,transparent 2px 5px);background-color:transparent;}
#kta-line-settings .sp.dash{border-radius:0;background-image:repeating-linear-gradient(90deg,currentColor 0 6px,transparent 6px 10px);background-color:transparent;}
#kta-line-settings input[type=range]{width:100%;accent-color:${t.a1};vertical-align:middle;height:6px;cursor:pointer;}
#kta-line-settings .ls-col{display:flex;align-items:center;gap:8px;background:${t.inset};border:1px solid ${t.border};border-radius:9px;padding:5px 7px;box-shadow:inset 0 1px 3px ${t.sink};}
#kta-line-settings input[type=color]{width:100%;height:24px;border:none;border-radius:6px;cursor:pointer;padding:0;background:none;}
#kta-line-settings .ls-grid{display:grid;grid-template-columns:1fr 1fr;gap:9px;}
#kta-line-settings .ls-btn{display:flex;align-items:center;justify-content:center;gap:7px;width:100%;padding:9px;background:linear-gradient(180deg,${t.a1},${t.a2});border:none;border-radius:9px;color:#fff;font-weight:800;cursor:pointer;font-size:12.5px;font-family:'Pretendard',system-ui,sans-serif;margin-top:10px;box-shadow:inset 0 1px 0 rgba(255,255,255,.28), 0 6px 16px -6px ${t.a2};transition:.16s;}
#kta-line-settings .ls-btn:hover{transform:translateY(-1px);filter:saturate(1.12);}
#kta-line-settings .ls-x{cursor:pointer;color:${t.x};width:24px;height:24px;border-radius:8px;display:flex;align-items:center;justify-content:center;background:${t.grad};background-color:${t.bg2};border:1px solid ${t.border};box-shadow:inset 0 1px 0 ${t.hl};transition:.15s;}
#kta-line-settings .ls-x:hover{color:${t.text};border-color:${t.borderStrong};}
#kta-line-settings .ls-div{border:none;border-top:1px solid ${t.div};margin:10px 0;}
</style>
<div class="ls-hd">
  <div class="ls-hd-left"><span class="ls-hd-ico">${ICO_BELL}</span>알람선 설정</div>
  <div class="ls-hd-right">
    <button class="ls-theme">${t.icon} ${t.nextLabel}</button>
    <span class="ls-x">${ICO_X}</span>
  </div>
</div>
<div class="ls-sec">
  <div class="ls-lbl">표시 항목</div>
  <div class="ls-row">
    <label><input type="checkbox" id="ls-bell" ${s.showBell?'checked':''}> 종</label>
    <label><input type="checkbox" id="ls-arrow" ${s.showArrow?'checked':''}> 방향</label>
    <label><input type="checkbox" id="ls-price" ${s.showPrice?'checked':''}> 가격</label>
    <label><input type="checkbox" id="ls-memo" ${s.showMemo?'checked':''}> 비고</label>
  </div>
</div>
<div class="ls-sec">
  <div class="ls-lbl">선 스타일</div>
  <div class="ls-row">
    <label><input type="radio" name="ls-st" value="0" ${s.lineStyle===0?'checked':''}><i class="sp"></i>실선</label>
    <label><input type="radio" name="ls-st" value="1" ${s.lineStyle===1?'checked':''}><i class="sp dot"></i>점선</label>
    <label><input type="radio" name="ls-st" value="2" ${s.lineStyle===2?'checked':''}><i class="sp dash"></i>파선</label>
  </div>
</div>
<div class="ls-sec">
  <div class="ls-lbl">선 굵기 <em><span id="ls-wv">${s.lineWidth}</span>px</em></div>
  <input type="range" id="ls-w" min="1" max="4" value="${s.lineWidth}">
</div>
<div class="ls-sec">
  <div class="ls-lbl">폰트 크기 <em><span id="ls-fsv">${s.fontSize}</span>px</em></div>
  <input type="range" id="ls-fs" min="9" max="18" value="${s.fontSize}">
</div>
<div class="ls-sec">
  <div class="ls-lbl">텍스트 가로 위치</div>
  <div class="ls-row">
    <label><input type="radio" name="ls-ha" value="left" ${s.horzAlign==='left'?'checked':''}> 왼쪽</label>
    <label><input type="radio" name="ls-ha" value="center" ${s.horzAlign==='center'?'checked':''}> 가운데</label>
    <label><input type="radio" name="ls-ha" value="right" ${s.horzAlign==='right'?'checked':''}> 오른쪽</label>
  </div>
</div>
<div class="ls-sec"><label><input type="checkbox" id="ls-bold" ${s.fontBold?'checked':''}> 폰트 굵게</label></div>
<div class="ls-grid ls-sec">
  <div><div class="ls-lbl">이상 색상</div><div class="ls-col"><input type="color" id="ls-ac" value="${s.aboveColor}"></div></div>
  <div><div class="ls-lbl">이하 색상</div><div class="ls-col"><input type="color" id="ls-bc" value="${s.belowColor}"></div></div>
</div>
<button class="ls-btn">${ICO_REFRESH} 적용 — 알람선 다시 그리기</button>`;

    widget.appendChild(panel);
    panel.querySelector('.ls-x').onclick = () => panel.remove();
    panel.querySelector('.ls-theme').onclick = () => {
      panelTheme = panelTheme === 'dark' ? 'light' : 'dark';
      saveChartSettings(); showSettingsPanel();
    };
    document.getElementById('ls-w').oninput = function () { document.getElementById('ls-wv').textContent = this.value; };
    document.getElementById('ls-fs').oninput = function () { document.getElementById('ls-fsv').textContent = this.value; };

    panel.querySelector('.ls-btn').onclick = () => {
      lineSettings = {
        showBell: document.getElementById('ls-bell').checked,
        showArrow: document.getElementById('ls-arrow').checked,
        showMemo: document.getElementById('ls-memo').checked,
        showPrice: document.getElementById('ls-price').checked,
        lineStyle: parseInt(panel.querySelector('input[name="ls-st"]:checked')?.value ?? '2'),
        lineWidth: parseInt(document.getElementById('ls-w').value),
        fontSize: parseInt(document.getElementById('ls-fs').value),
        fontBold: document.getElementById('ls-bold').checked,
        horzAlign: panel.querySelector('input[name="ls-ha"]:checked')?.value ?? 'right',
        vertAlign: 'bottom',
        aboveColor: document.getElementById('ls-ac').value,
        belowColor: document.getElementById('ls-bc').value,
      };
      saveChartSettings();
      redrawAllTVLines();
      panel.remove();
    };
  }

  window.addEventListener('kta-alarms', e => {
    const alarms = e.detail || [];
    latestAlarms = alarms;
    syncFab();
    if (!_chart) { pendingAlarms = alarms; return; }
    drawTVLines();
  });

  function saveChartSettings() {
    window.dispatchEvent(new CustomEvent('kta-save-line-settings', { detail: { ...lineSettings, panelTheme } }));
  }

  window.addEventListener('kta-line-settings', e => {
    const d = e.detail || {};
    Object.assign(lineSettings, d);
    if (d.panelTheme) panelTheme = d.panelTheme;
  });

  window.addEventListener('kta-update-memo', e => {
    const { id, memo } = e.detail || {};
    const idx = latestAlarms.findIndex(a => a.id === id);
    if (idx >= 0) latestAlarms[idx].memo = memo;
    const entry = _shapeMap.get(id);
    if (entry) {
      try { _chart?.removeEntity(entry.eid); } catch(e) {}
      _shapeMap.delete(id);
    }
    drawTVLines();
  });
})();
