(function () {
  'use strict';

  if (window.__ubPollTimer) { clearInterval(window.__ubPollTimer); window.__ubPollTimer = null; }

  window.addEventListener('error', function (e) {
    if (e.message && e.message.includes('Extension context invalidated')) e.preventDefault();
  });

  const STORAGE_KEY = 'upbit_alarms_v2';
  const SETTINGS_KEY = 'upbit_alarm_settings_v1';
  const CHART_SETTINGS_KEY = 'kta_chart_settings_v1';
  const HISTORY_KEY = 'kta_alarm_history_v1';
  const POLL_INTERVAL = 1500;

  let alarms = [];
  let currentSettings = { sound: 'fanfare', volume: 70, reactivate: 'custom', reactivateMinutes: 1 };

  function isCtxValid() {
    try { return !!chrome.runtime.id; } catch { return false; }
  }
  function isActive(a) { return !a.fired && !a.disabled; }

  function loadSettings() {
    chrome.storage.local.get(SETTINGS_KEY, data => {
      currentSettings = { sound: 'ding', reactivate: 'custom', reactivateMinutes: 1, ...(data[SETTINGS_KEY] || {}) };
    });
  }

  function loadChartSettings() {
    chrome.storage.local.get(CHART_SETTINGS_KEY, data => {
      const s = data[CHART_SETTINGS_KEY];
      if (s) window.dispatchEvent(new CustomEvent('kta-line-settings', { detail: s }));
    });
  }

  function checkReactivations() {
    const now = Date.now();
    let changed = false;
    alarms.forEach(a => {
      if (a.disabled && a.reactivateAt && now >= a.reactivateAt) {
        a.disabled = false;
        delete a.reactivateAt;
        changed = true;
      }
    });
    if (changed) chrome.storage.local.set({ [STORAGE_KEY]: alarms });
  }

  function loadAlarms() {
    chrome.storage.local.get(STORAGE_KEY, data => {
      alarms = data[STORAGE_KEY] || [];
      migrateV1();
      checkReactivations();
      if (alarms.some(isActive)) startPolling();
      dispatchAlarmsToChart();
    });
  }

  function migrateV1() {
    if (alarms.length) return;
    try {
      const old = localStorage.getItem('upbit_alarms_v1');
      if (!old) return;
      const parsed = JSON.parse(old);
      if (!parsed.length) return;
      alarms = parsed.map(a => ({
        ...a,
        sym: a.code.replace('KRW-', ''),
        kor: '',
        disabled: a.fired || false,
        fired: false
      }));
      chrome.storage.local.set({ [STORAGE_KEY]: alarms });
      localStorage.removeItem('upbit_alarms_v1');
    } catch {}
  }

  function disableAlarm(id, reactivateAt) {
    chrome.storage.local.get(STORAGE_KEY, data => {
      const arr = data[STORAGE_KEY] || [];
      const a = arr.find(x => x.id === id);
      if (a) { a.disabled = true; a.fired = false; if (reactivateAt) a.reactivateAt = reactivateAt; }
      chrome.storage.local.set({ [STORAGE_KEY]: arr });
    });
  }

  function enableAlarm(id) {
    chrome.storage.local.get(STORAGE_KEY, data => {
      const arr = data[STORAGE_KEY] || [];
      const a = arr.find(x => x.id === id);
      if (a) { a.disabled = false; delete a.reactivateAt; }
      chrome.storage.local.set({ [STORAGE_KEY]: arr });
    });
  }

  function getReactivateMs() {
    switch (currentSettings.reactivate) {
      case '30min': return 30 * 60 * 1000;
      case '1hour': return 60 * 60 * 1000;
      case 'custom': return Math.max(1, currentSettings.reactivateMinutes || 60) * 60 * 1000;
      default: return 0;
    }
  }

  function playAlarmSound() {
    if (currentSettings.sound === 'none') return;
    fetch(chrome.runtime.getURL(`sounds/${currentSettings.sound}.wav`)).then(r=>r.blob()).then(blob=>{const u=URL.createObjectURL(blob);const a=new Audio(u);a.volume=(currentSettings.volume??70)/100;a.play().catch(()=>{});a.addEventListener('ended',()=>URL.revokeObjectURL(u));}).catch(()=>{});
  }

  function fetchPrices() {
    if (!isCtxValid()) {
      if (window.__ubPollTimer) { clearInterval(window.__ubPollTimer); window.__ubPollTimer = null; }
      return;
    }
    const codes = [...new Set(alarms.filter(isActive).map(a => a.code))];
    if (!codes.length) {
      if (window.__ubPollTimer) { clearInterval(window.__ubPollTimer); window.__ubPollTimer = null; }
      return;
    }
    try {
      chrome.runtime.sendMessage({ action: 'fetchPrices', codes }, res => {
        try {
          if (chrome.runtime.lastError || !res || !res.ok) return;
          Object.keys(res.prices).forEach(code => checkAlarms(code, res.prices[code]));
        } catch {}
      });
    } catch {
      if (window.__ubPollTimer) { clearInterval(window.__ubPollTimer); window.__ubPollTimer = null; }
    }
  }

  function startPolling() {
    if (window.__ubPollTimer) clearInterval(window.__ubPollTimer);
    fetchPrices();
    window.__ubPollTimer = setInterval(fetchPrices, POLL_INTERVAL);
  }

  function checkAlarms(code, price) {
    alarms.forEach(alarm => {
      if (!isActive(alarm) || alarm.code !== code) return;
      const triggered =
        (alarm.dir === 'above' && price >= alarm.price) ||
        (alarm.dir === 'below' && price <= alarm.price);
      if (triggered) {
        alarm.disabled = true;
        alarm.fired = false;
        const delay = getReactivateMs();
        disableAlarm(alarm.id, delay > 0 ? Date.now() + delay : null);
        fireAlarm(alarm, price, delay);
      }
    });
  }

  function showToast(msg, memo, url) {
    const toast = document.createElement('div');
    toast.style.cssText = `
      position:fixed;top:24px;left:50%;transform:translateX(-50%) translateY(-80px);
      z-index:999999;background:linear-gradient(180deg, rgba(255,255,255,.05), rgba(255,255,255,0));
      background-color:#1e2127;color:#e9ecf1;border:1px solid #3d434d;
      border-radius:13px;padding:12px 18px;font-size:12.5px;font-weight:800;
      box-shadow:0 22px 44px -14px rgba(0,0,0,.7), inset 0 1px 0 rgba(255,255,255,.055);
      transition:transform .35s cubic-bezier(.2,1,.4,1);
      white-space:pre-line;text-align:center;min-width:250px;cursor:pointer;
      font-family:'Pretendard','Noto Sans KR',system-ui,sans-serif;
    `;
    const msgEl = document.createElement('div');
    msgEl.textContent = msg;
    toast.appendChild(msgEl);
    if (memo) {
      const memoEl = document.createElement('div');
      memoEl.textContent = memo;
      memoEl.style.cssText = 'margin-top:4px;font-size:11px;font-weight:700;color:#ef5350;';
      toast.appendChild(memoEl);
    }
    document.body.appendChild(toast);
    requestAnimationFrame(() => { toast.style.transform = 'translateX(-50%) translateY(0)'; });
    const dismiss = () => {
      toast.style.transform = 'translateX(-50%) translateY(-80px)';
      setTimeout(() => toast.remove(), 400);
    };
    toast.addEventListener('click', () => {
      if (url) window.location.href = url;
      dismiss();
    });
    setTimeout(dismiss, 7000);
  }

  function saveAlarmHistory(alarm, currentPrice) {
    chrome.storage.local.get(HISTORY_KEY, data => {
      const history = data[HISTORY_KEY] || [];
      history.unshift({ id: Date.now(), exchange: 'upbit', label: alarm.label, sym: alarm.sym || alarm.code.replace('KRW-', ''), price: alarm.price, dir: alarm.dir, currentPrice, memo: alarm.memo || '', firedAt: Date.now(), unread: true });
      if (history.length > 50) history.length = 50;
      chrome.storage.local.set({ [HISTORY_KEY]: history });
    });
  }

  function fireAlarm(alarm, currentPrice, delay) {
    saveAlarmHistory(alarm, currentPrice);
    if (isCtxValid()) chrome.runtime.sendMessage({ action: 'sendPush', alarm, currentPrice, exchange: 'upbit' }, () => {});
    const dirText = alarm.dir === 'above' ? '이상' : '이하';
    const body = `${alarm.label} ${Number(alarm.price).toLocaleString()}원 ${dirText} 도달!\n현재가: ${Number(currentPrice).toLocaleString()}원`;
    const url = `https://upbit.com/exchange?code=CRIX.UPBIT.${alarm.code}`;
    showToast(`🔔 ${body}`, alarm.memo || '', url);
    if (Notification.permission === 'granted') {
      new Notification('🔔 업비트 가격 알람', { body });
    }
    playAlarmSound();
    if (delay > 0) setTimeout(() => enableAlarm(alarm.id), delay);
  }

  function dispatchAlarmsToChart() {
    const sym = getUpbitSym();
    if (!sym) return;
    const pageAlarms = alarms.filter(a => a.code === `KRW-${sym}`);
    window.dispatchEvent(new CustomEvent('kta-alarms', { detail: pageAlarms }));
  }

  chrome.storage.onChanged.addListener(changes => {
    if (changes[STORAGE_KEY]) {
      alarms = changes[STORAGE_KEY].newValue || [];
      if (alarms.some(isActive)) startPolling();
      else if (window.__ubPollTimer) { clearInterval(window.__ubPollTimer); window.__ubPollTimer = null; }
      dispatchAlarmsToChart();
    }
    if (changes[SETTINGS_KEY]) {
      currentSettings = { sound: 'ding', reactivate: 'custom', reactivateMinutes: 1, ...(changes[SETTINGS_KEY].newValue || {}) };
    }
  });

  window.addEventListener('kta-symbol-changed', () => {
    setTimeout(dispatchAlarmsToChart, 200);
  });

  window.addEventListener('kta-save-line-settings', e => {
    if (!e.detail) return;
    chrome.storage.local.set({ [CHART_SETTINGS_KEY]: e.detail });
  });

  window.addEventListener('kta-update-memo', e => {
    const { id, memo } = e.detail || {};
    if (!id) return;
    chrome.storage.local.get(STORAGE_KEY, data => {
      const arr = data[STORAGE_KEY] || [];
      const alarm = arr.find(a => a.id === id);
      if (alarm) { alarm.memo = memo; chrome.storage.local.set({ [STORAGE_KEY]: arr }); }
    });
  });

  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      checkReactivations();
      if (alarms.some(isActive)) startPolling();
    }
  });

  if (Notification.permission === 'default') Notification.requestPermission();
  loadSettings();
  loadChartSettings();
  loadAlarms();

  // ── 빠른 추가 + 버튼 ──────────────────────────────────────────────
  function getUpbitSym() {
    const m = location.search.match(/[?&]code=CRIX\.UPBIT\.KRW-([A-Z0-9]+)/i);
    return m ? m[1].toUpperCase() : null;
  }

  function injectQuickAddBtn(sym) {
    if (document.getElementById('kta-quick-add-btn')) return;
    const btn = document.createElement('button');
    btn.id = 'kta-quick-add-btn';
    btn.textContent = '+';
    btn.title = `${sym} 알람 추가`;
    // 위치(bottom:80px / right:20px)는 그대로.
    // [2026-08-07] 색을 앱 accent(로즈) 고정에서 **거래소 색**으로 교체.
    // 이 파일은 업비트 전용 content script라 업비트 파랑으로 고정한다.
    // 값은 시안(ktraderkey_kalert_mockup_artifact.html)의 --up1/--up2 다크셋 그대로.
    Object.assign(btn.style, {
      position: 'fixed', bottom: '80px', right: '20px',
      width: '46px', height: '46px', borderRadius: '50%',
      background: 'linear-gradient(160deg,#60a5fa,#2563eb)', color: '#fff', fontSize: '21px',
      fontWeight: 'bold', border: 'none', cursor: 'pointer',
      zIndex: '999999',
      boxShadow: '0 10px 24px -6px #2563eb, inset 0 1px 0 rgba(255,255,255,.35), 0 0 0 4px rgba(96,165,250,.16)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: "'Pretendard',system-ui,sans-serif", transition: '.18s'
    });
    btn.addEventListener('click', () => {
      if (!isCtxValid()) return;
      chrome.runtime.sendMessage({ action: 'quickAdd', sym });
    });
    document.body.appendChild(btn);
  }

  function initQuickAddBtn() {
    chrome.storage.local.get('upbit_alarm_settings_v1', data => {
      const s = data['upbit_alarm_settings_v1'] || {};
      if (s.quickAddBtn === false) return;
      const sym = getUpbitSym();
      if (sym) injectQuickAddBtn(sym);
    });
  }

  initQuickAddBtn();

  let _lastHref = location.href;
  setInterval(() => {
    if (location.href !== _lastHref) {
      _lastHref = location.href;
      document.getElementById('kta-quick-add-btn')?.remove();
      initQuickAddBtn();
      dispatchAlarmsToChart();
    }
  }, 500);
  window.addEventListener('popstate', () => { document.getElementById('kta-quick-add-btn')?.remove(); initQuickAddBtn(); });


})();
