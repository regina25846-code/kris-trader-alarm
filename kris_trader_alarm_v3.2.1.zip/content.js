(function () {
  'use strict';

  // ── [2026-08-23] 같은 페이지에 이 스크립트가 여러 개 겹쳐 도는 걸 막는 세대(generation) 가드 ──
  // background.js가 tabs.onActivated / webNavigation.onCompleted 마다 content.js를 executeScript로
  // 재주입한다. 즉 형이 업비트 탭을 왔다갔다 할 때마다 같은 페이지 안에 이 IIFE가 하나씩 더 쌓인다.
  // 예전 코드는 __ubPollTimer(가격 폴링)만 정리해서, 추세선 쪽 타이머·상태(trendCheckTimer,
  // trendLastDiff, trendCheckState, alarms)는 인스턴스마다 따로 살아있었다. 그 인스턴스들이 각자
  // 독립적으로 같은 봉을 판정하는데, 중복방지 상태(lastFiredBarT)는 chrome.storage 왕복(수십~수백ms)
  // 으로만 공유되기 때문에 그 왕복보다 짧은 간격으로 둘이 겹치면 둘 다 "아직 안 울렸다"고 보고
  // 각자 알림을 쏜다 → 실측된 0.15~0.18초 간격 중복발동. 세대 번호를 window에 박아서 최신 인스턴스
  // 하나만 살아있게 하고, 낡은 인스턴스는 타이머·리스너 진입점마다 즉시 빠져나가게 한다.
  const KTA_GEN = (window.__ktaGen = (window.__ktaGen || 0) + 1);
  function isLive() { return window.__ktaGen === KTA_GEN; }

  if (window.__ubPollTimer) { clearInterval(window.__ubPollTimer); window.__ubPollTimer = null; }
  if (window.__ktaTrendTimer) { clearInterval(window.__ktaTrendTimer); window.__ktaTrendTimer = null; }

  window.addEventListener('error', function (e) {
    if (e.message && e.message.includes('Extension context invalidated')) e.preventDefault();
  });

  const STORAGE_KEY = 'upbit_alarms_v2';
  const SETTINGS_KEY = 'upbit_alarm_settings_v1';
  const CHART_SETTINGS_KEY = 'kta_chart_settings_v1';
  const HISTORY_KEY = 'kta_alarm_history_v1';
  const POLL_INTERVAL = 1500;

  // ── 알람 배열 갱신 직렬화 (lost update 방지) ─────────────────────────────
  // chrome.storage에는 원자적 갱신(compare-and-swap)이 없다. "읽기 → 고치기 → 쓰기" 사이에
  // 다른 코드가 같은 키를 건드리면 나중 쓰기가 앞의 결과를 통째로 덮어써서(lost update)
  // 방금 끈 알람이 되살아나거나 방금 울린 봉 기록이 사라진다 — interval 재활성 직후
  // 2~3초 만에 또 울리던 실제 원인이었다(무장 로직이 disableAlarm의 결과를 덮어씀).
  // 이 페이지 안의 알람 배열 갱신을 전부 한 줄로 세워서 그 창을 없앤다.
  let alarmWriteChain = Promise.resolve();
  function updateAlarms(mutator) {
    alarmWriteChain = alarmWriteChain.then(() => new Promise(resolve => {
      let settled = false;
      const finish = () => { if (!settled) { settled = true; resolve(); } };
      // 콜백이 영영 안 와도(컨텍스트 무효화 등) 체인이 막히지 않게 하는 안전장치.
      setTimeout(finish, 5000);
      try {
        chrome.storage.local.get(STORAGE_KEY, data => {
          try {
            const arr = data[STORAGE_KEY] || [];
            const next = mutator(arr);
            if (next === false) { finish(); return; }
            chrome.storage.local.set({ [STORAGE_KEY]: Array.isArray(next) ? next : arr }, finish);
          } catch (e) { finish(); }
        });
      } catch (e) { finish(); }
    }));
    return alarmWriteChain;
  }

  // 추세선(익스텐디드 라인) 알람의 현재 시각 기준 가격 계산.
  // 선형축: 산술보간(p1 + (p2-p1)*k), 로그축: 기하보간(p1 * (p2/p1)^k) — 화면상 직선과 일치.
  function trendPriceAt(a, nowSec) {
    let A = a.a1, B = a.a2;
    if (!A || !B) return null;
    if (B.t < A.t) { const tmp = A; A = B; B = tmp; }
    const t1 = A.t, p1 = A.p, t2 = B.t, p2 = B.p;
    if (![t1, t2, p1, p2, nowSec].every(Number.isFinite)) return null;
    if (t2 === t1) return null;
    const k = (nowSec - t1) / (t2 - t1);
    const ext = a.extend || 'right';
    if (ext === 'none' && (k < 0 || k > 1)) return null;
    if (ext === 'right' && k < 0) return null;
    if (a.scale === 'log') {
      if (p1 <= 0 || p2 <= 0) return null;
      return p1 * Math.pow(p2 / p1, k);
    }
    return p1 + (p2 - p1) * k;
  }

  // [2026-08-23] 2단계: 캔들 기반 트리거 엔진. 오푸스 실측설계 확정안 그대로 구현.
  // tf(TradingView resolution 문자열)별 봉 길이(초). '1M'(월봉)은 실제 달 길이가 들쭉날쭉하지만
  // 여기선 봉 구간 안에서 추세선 값의 최솟/최댓값을 어림잡는 용도라 근사치(30일)로 충분(형 확인, 4단계 보류).
  function tfSec(tf) {
    const map = { '1S': 1, '1': 60, '3': 180, '5': 300, '10': 600, '15': 900, '30': 1800, '60': 3600, '240': 14400, '1D': 86400, '1W': 604800, '1M': 2592000 };
    return map[tf] || 60;
  }
  // 캔들 폴링 주기 C(tf) = clamp(30초, tf/4, 300초) — 레이트리밋 예산 안에서 타임프레임에 맞게 촘촘/느슨하게.
  function candlePollIntervalMs(tf) {
    return Math.min(300000, Math.max(30000, tfSec(tf) * 1000 / 4));
  }
  // 지금 이 순간이 속한 봉의 시작 시각(초).
  // [2026-08-23 수정] 분봉은 UTC 정각 정렬이라 단순 나눗셈으로 맞지만, 업비트 KRW 일봉/주봉은
  // KST 09시 기준이라 UTC로 보면 15:00에 봉이 바뀐다. 그냥 floor(now/86400)*86400을 쓰면
  // 패스트패스와 캔들폴링이 "같은 터치"를 서로 다른 봉 번호로 세서 perBar 중복방지가 통째로
  // 무력화된다(일봉 추세선에서 실제로 두 번 울리는 원인). 그래서 캔들 응답에서 실제 봉 경계
  // 오프셋을 배워두고(trendBarOffset) 여기서 같이 보정한다. 아직 못 배웠으면 오프셋 0 = 기존 동작.
  const trendBarOffset = new Map(); // tf → 봉 경계 오프셋(초)
  function currentBarTimeSec(tf, nowSec) {
    const sec = tfSec(tf);
    const off = trendBarOffset.get(tf) || 0;
    return Math.floor((nowSec - off) / sec) * sec + off;
  }
  // background.js의 fetchCandles 메시지 핸들러(캐시+토큰버킷+429백오프 포함, 1단계에서 구현) 호출.
  function fetchCandlesFor(market, tf, count) {
    return new Promise((resolve, reject) => {
      if (!isCtxValid()) { reject(new Error('ctx_invalid')); return; }
      try {
        chrome.runtime.sendMessage({ action: 'fetchCandles', market, tf, count, maxAgeMs: candlePollIntervalMs(tf) }, res => {
          if (chrome.runtime.lastError || !res || !res.ok) { reject(new Error((res && res.error) || 'fetch_failed')); return; }
          resolve(res.candles);
        });
      } catch (e) { reject(e); }
    });
  }
  // 한 봉(캔들)의 고저가 추세선 구간과 겹치는지 — 방향(이상/이하) 구분 없이 스침만 보면 됨(수평선도 같은 코드로 자연 처리).
  function computeTouched(alarm, candle) {
    const barTimeSec = Math.floor(new Date(candle.candle_date_time_utc + 'Z').getTime() / 1000);
    const dur = tfSec(alarm.tf);
    // 거래소가 실제로 쓰는 봉 경계를 여기서 배워서 패스트패스(currentBarTimeSec)와 봉 번호를 일치시킨다.
    if (Number.isFinite(barTimeSec) && dur > 0) trendBarOffset.set(alarm.tf, ((barTimeSec % dur) + dur) % dur);
    const v1 = trendPriceAt(alarm, barTimeSec);
    const v2 = trendPriceAt(alarm, barTimeSec + dur);
    if (v1 == null && v2 == null) return { touched: false, barTimeSec };
    const lo = v1 == null ? v2 : (v2 == null ? v1 : Math.min(v1, v2));
    const hi = v1 == null ? v2 : (v2 == null ? v1 : Math.max(v1, v2));
    const touched = candle.low_price <= hi && candle.high_price >= lo;
    return { touched, lineLo: lo, lineHi: hi, barTimeSec };
  }
  // 실시간 체결가 크로싱 감지(패스트패스) — 매 틱마다 "선 기준 위/아래"가 뒤집히면 스침으로 판정.
  // 방향 무관(죽은 dir 필드에 더는 의존 안 함)이라 예전처럼 "이미 위에 있으면 즉시 발동" 오탐이 안 생김:
  // 알람이 새로 무장(armTrendAlarm)되면 이 기준점(trendLastDiff)도 같이 리셋되고, 리셋 직후 첫 샘플은
  // 기준점만 잡을 뿐 발동엔 쓰이지 않아서 "생성 시점에 이미 선에 걸쳐있어도 그 순간엔 안 울림"이 자연히 보장됨.
  const trendLastDiff = new Map();
  // [2026-08-23 수정] armedBarTime 게이트는 여기(패스트패스)엔 안 씀 — 크로싱 감지 자체가 "기준점
  // 리셋 직후 첫 샘플은 발동 안 함" 규칙으로 이미 "생성 시점에 이미 닿아있어도 그 순간엔 안 울림"을
  // 보장하기 때문에, 봉 단위로 통째로 더 억누르면 오히려 형이 지적한 대로 "같은 봉 안에서 진짜로
  // 다시 스치는 것"까지 다음 봉까지(최대 tf분) 못 잡는 부작용이 생김. 봉단위 게이트는 캔들폴링
  // (checkOneTrendAlarm, 아래)에만 필요 — 거긴 크로싱이 아니라 "지금 이 봉이 닿아있냐"는 정적
  // 판정이라 이미 닿아있던 봉을 매번 다시 감지하는 걸 막으려면 봉단위 스킵이 꼭 필요함.
  function checkTrendFastPath(alarm, price, nowSec) {
    const ref = trendPriceAt(alarm, nowSec);
    if (ref == null) return;
    const diff = price - ref;
    const prevDiff = trendLastDiff.get(alarm.id);
    trendLastDiff.set(alarm.id, diff);
    if (prevDiff === undefined) return;
    const crossed = (prevDiff <= 0 && diff >= 0) || (prevDiff >= 0 && diff <= 0);
    if (!crossed) return;
    const barTimeSec = currentBarTimeSec(alarm.tf, nowSec);
    fireTrendAlarm(alarm, price, ref, barTimeSec);
  }
  // 캔들 API 기반 따라잡기 폴링 — 패스트패스가 놓쳤을 수 있는 실제 고저(윅) 스침을 늦게라도 잡아줌.
  const trendCheckState = new Map();
  // 타이머 핸들은 window에 둔다(__ubPollTimer와 같은 이유) — 재주입된 새 인스턴스가 낡은 인스턴스의
  // 캔들 폴링 타이머를 확실히 끌 수 있어야 인스턴스가 겹겹이 쌓이지 않는다.
  let trendCheckTimer = null;
  function stopTrendChecking() {
    if (trendCheckTimer) clearInterval(trendCheckTimer);
    if (window.__ktaTrendTimer) clearInterval(window.__ktaTrendTimer);
    trendCheckTimer = null;
    window.__ktaTrendTimer = null;
  }
  // [2026-08-23 수정] 최신 봉 1개만 보면, 폴링 간격(C(tf)) 안에서 봉이 이미 닫혀버린 경우 그 봉의
  // 스침을 영영 못 봄(형이 실기에서 발견 — "스쳐있는데 트리거가 안 됨"). 직전 확인 이후 지난 시간만큼
  // 여러 봉을 같이 조회해서, 그 사이에 닫힌 봉의 스침까지 놓치지 않게 함. 탭이 백그라운드로 밀려서
  // setInterval이 늦게 도는 경우(브라우저 쓰로틀링)까지 커버하려고 gapMs 기반으로 넉넉히 계산.
  async function checkOneTrendAlarm(alarm, gapMs) {
    try {
      const sec = tfSec(alarm.tf);
      const barsElapsed = gapMs ? Math.ceil(gapMs / 1000 / sec) : 1;
      const count = Math.min(50, Math.max(3, barsElapsed + 2));
      const candles = await fetchCandlesFor(alarm.code, alarm.tf, count);
      if (!candles || !candles.length) return;
      // Upbit 캔들 API 응답 정렬 순서를 가정하지 않고 시각순으로 직접 정렬(오래된 것부터).
      const sorted = [...candles].sort((a, b) => new Date(a.candle_date_time_utc) - new Date(b.candle_date_time_utc));
      const fresh = alarms.find(x => x.id === alarm.id);
      if (!fresh || !isActive(fresh)) return;
      // [2026-08-23 수정] 알람을 새로 그리면(kta-trend-quick-save) armTrendAlarm이 캔들을 한 번
      // 받아와야(200~300ms) armedBarTime이 정해진다. 그 사이에 이 따라잡기 폴링이 먼저 돌면
      // "이미 닿아있는 봉은 건너뛴다"는 확정 사양이 무시되고 그리자마자 울려버린다.
      // 무장이 끝날 때까지만 기다린다 — 15초가 지나면 무장이 실패한 걸로 보고 그냥 감시 재개(fail-open).
      if (fresh.armPending && (Date.now() - fresh.armPending) < 15000) return;
      // [2026-08-23 수정] 예전엔 "lastFiredBarT와 같은 봉"만 건너뛰었다. 그런데 lastFiredBarT는
      // 봉 하나만 기억하는 값이고 여기 따라잡기 루프는 여러 봉을 훑기 때문에, 이미 울렸던 과거 봉이
      // "가장 최근에 울린 봉"이 아니게 되는 순간(= 다음 봉이 울린 직후) 다시 후보로 되살아나서
      // 폴링 돌 때마다 계속 재발동했다(형이 겪은 짧은 간격 반복 알림의 큰 축). 봉 시각은 단조증가라
      // "마지막으로 울린 봉보다 뒤인 봉만" 발동하도록 부등호로 바꾸면 구조적으로 재발동이 불가능해진다.
      const lastFired = fresh.lastFiredBarT;
      let toFire = null;
      for (const c of sorted) {
        const { touched, barTimeSec } = computeTouched(fresh, c);
        if (!touched || barTimeSec === fresh.armedBarTime) continue;
        if (lastFired != null && barTimeSec <= lastFired) continue;
        toFire = { c, barTimeSec }; // 여러 봉이 밀려있으면 가장 최근 것 하나로만 알림(스팸 방지).
      }
      if (!toFire) return;
      const nowSec = Math.floor(Date.now() / 1000);
      const ref = trendPriceAt(fresh, nowSec);
      fireTrendAlarm(fresh, toFire.c.trade_price, ref != null ? ref : toFire.c.trade_price, toFire.barTimeSec);
    } catch (e) { /* 레이트리밋/네트워크 실패는 조용히 넘어가고 다음 주기에 재시도 */ }
  }
  function checkTrendAlarmsTick() {
    // 낡은 인스턴스(재주입 전 세대)는 여기서 스스로 손을 뗀다 — 안 그러면 최신 인스턴스와
    // 같은 봉을 이중으로 판정해서 알림이 여러 번 울린다.
    if (!isLive()) { stopTrendChecking(); return; }
    if (!isCtxValid()) { stopTrendChecking(); return; }
    const now = Date.now();
    const active = alarms.filter(a => a.type === 'trend' && isActive(a));
    if (!active.length) { stopTrendChecking(); return; }
    active.forEach(a => {
      const st = trendCheckState.get(a.id) || { lastCheckAt: 0 };
      if (now - st.lastCheckAt < candlePollIntervalMs(a.tf)) return;
      const gapMs = st.lastCheckAt ? (now - st.lastCheckAt) : 0;
      st.lastCheckAt = now;
      trendCheckState.set(a.id, st);
      checkOneTrendAlarm(a, gapMs);
    });
  }
  function startTrendChecking() {
    if (!isLive()) return;
    if (trendCheckTimer && window.__ktaTrendTimer === trendCheckTimer) return;
    stopTrendChecking();
    checkTrendAlarmsTick();
    trendCheckTimer = setInterval(checkTrendAlarmsTick, 5000);
    window.__ktaTrendTimer = trendCheckTimer;
  }
  // ── 발동 중복방지 잠금 (window = 페이지 전역이라 재주입된 인스턴스끼리도 공유됨) ──────────
  // lastFiredBarT는 chrome.storage 왕복으로만 공유돼서, 그 왕복(수십~수백ms)보다 짧은 간격으로
  // 두 경로(패스트패스/캔들폴링)나 두 인스턴스가 겹치면 둘 다 "아직 안 울렸다"고 본다.
  // 이 잠금은 그 왕복을 기다리지 않고 즉시 서는 동기 관문이라 그 창을 완전히 닫는다.
  const KTA_FIRE_LOCK = (window.__ktaFireLock = window.__ktaFireLock || {});
  // 3초 쿨다운은 정상 발동을 절대 못 막는다: perBar 최소 재발동 간격 = 봉 길이(추세선은 1초봉 금지라 ≥60초),
  // once = 두 번 다시 안 울림, interval = getReactivateMs() 최소 1분. 즉 3초 안 재발동은 무조건 레이스다.
  const TREND_FIRE_COOLDOWN_MS = 3000;
  function claimTrendFire(alarmId, barTimeSec) {
    const now = Date.now();
    const rec = KTA_FIRE_LOCK[alarmId];
    // 봉 시각은 단조증가 — 이미 울린 봉과 같거나 그보다 과거인 봉은 다시 울리지 않는다.
    if (rec && (barTimeSec <= rec.bar || (now - rec.at) < TREND_FIRE_COOLDOWN_MS)) return false;
    KTA_FIRE_LOCK[alarmId] = { bar: barTimeSec, at: now };
    return true;
  }
  // 재무장(새로 그리기/좌표 다시찍기/재활성화)은 "처음부터 다시"라서 잠금도 같이 푼다.
  function releaseTrendFireLock(alarmId) { delete KTA_FIRE_LOCK[alarmId]; }

  // repeat 3모드: perBar(기본, 다음 봉에서 재발동 가능)/once(한번 울리면 계속 꺼둠)/interval(기존 재활성 설정 재사용).
  function fireTrendAlarm(alarm, price, ref, barTimeSec) {
    const repeat = alarm.repeat || 'perBar';
    // 봉 워터마크는 이제 3모드 전부에 적용한다 — 예전엔 perBar에만 걸어놔서 once/interval은
    // 따라잡기 폴링이 과거 봉을 다시 집어올 때 그대로 다시 울렸다(재활성 직후 연속 알림의 원인).
    if (alarm.lastFiredBarT != null && barTimeSec <= alarm.lastFiredBarT) return;
    // 스토리지 왕복과 무관한 동기 관문 — 여기를 통과한 호출만 실제로 알림을 쏜다.
    if (!claimTrendFire(alarm.id, barTimeSec)) return;
    alarm.lastFiredBarT = barTimeSec;
    if (repeat === 'perBar') {
      updateAlarms(arr => {
        const a = arr.find(x => x.id === alarm.id);
        if (!a) return false;
        a.lastFiredBarT = barTimeSec;
        return arr;
      });
    } else if (repeat === 'once') {
      alarm.disabled = true;
      disableAlarm(alarm.id, null, barTimeSec);
    } else {
      alarm.disabled = true;
      const delay = getReactivateMs();
      disableAlarm(alarm.id, delay > 0 ? Date.now() + delay : null, barTimeSec);
    }
    fireAlarm(alarm, price, repeat === 'interval' ? getReactivateMs() : 0, ref);
  }
  // 생성/좌표 다시찍기/재활성화 시점에 호출 — 지금 진행중인 봉이 "이미" 선에 닿아있으면 그 봉은 건너뛰고
  // 다음 봉부터 감시(형 확정: 무조건 스킵이 아니라 "이미 닿아있을 때만"). 실패하면 안전하게 즉시감시로 둠.
  function armTrendAlarm(alarmId) {
    trendLastDiff.delete(alarmId);
    releaseTrendFireLock(alarmId);
    chrome.storage.local.get(STORAGE_KEY, data => {
      const arr = data[STORAGE_KEY] || [];
      const alarm = arr.find(x => x.id === alarmId);
      if (!alarm || alarm.type !== 'trend') return;
      // [2026-08-23 수정] 예전엔 위 get으로 뜬 arr(스냅샷)을 아래 캔들 fetch(200~300ms) 끝난 뒤에
      // 그대로 덮어썼다. 그 사이에 다른 경로가 기록한 lastFiredBarT/disabled가 통째로 날아가서
      // (lost update) 방금 끈 알람이 되살아나거나 방금 울린 봉이 다시 울릴 수 있었다.
      // 이제는 updateAlarms(직렬 큐)로 "읽기→고치기→쓰기"를 통째로 묶어서 그 창을 없앤다.
      const applyArmed = (armedBarTime, watermark) => {
        updateAlarms(arr2 => {
          const a2 = arr2.find(x => x.id === alarmId);
          if (!a2) return false;
          a2.armedBarTime = armedBarTime;
          // 무장은 "지금부터 감시"라는 뜻인데, 예전엔 lastFiredBarT를 그냥 null로 비워버려서
          // 따라잡기 폴링이 무장 이전 과거 봉까지 다시 집어와 연달아 울렸다(특히 interval 재활성 직후).
          // 무장 시점의 직전 봉을 워터마크로 박아서 과거 구간을 잘라낸다.
          a2.lastFiredBarT = watermark != null ? watermark : null;
          delete a2.armPending;
          return arr2;
        });
      };
      fetchCandlesFor(alarm.code, alarm.tf, 1)
        .then(candles => {
          const c = candles && candles[0];
          if (!c) { applyArmed(null, null); return; }
          const { touched, barTimeSec } = computeTouched(alarm, c);
          applyArmed(touched ? barTimeSec : null, barTimeSec - tfSec(alarm.tf));
        })
        .catch(() => applyArmed(null, null));
    });
  }

  let alarms = [];
  let currentSettings = { sound: 'fanfare', volume: 70, reactivate: 'custom', reactivateMinutes: 1 };

  function isCtxValid() {
    try { return !!chrome.runtime.id; } catch { return false; }
  }
  function isActive(a) { return !a.fired && !a.disabled; }

  function loadSettings() {
    chrome.storage.local.get(SETTINGS_KEY, data => {
      currentSettings = { sound: 'ding', reactivate: 'custom', reactivateMinutes: 1, trendSameAsPrice: true, trendSound: 'ding3', trendLastExtend: 'right', trendLastScale: 'linear', trendLastRepeat: 'perBar', ...(data[SETTINGS_KEY] || {}) };
    });
  }

  function loadChartSettings() {
    chrome.storage.local.get(CHART_SETTINGS_KEY, data => {
      const s = data[CHART_SETTINGS_KEY];
      if (s) window.dispatchEvent(new CustomEvent('kta-line-settings', { detail: s }));
    });
  }

  function checkReactivations() {
    const now = Date.now();
    // [2026-08-23 수정] 예전엔 alarms 배열을 통째로 저장해서, 저장 직전에 다른 경로가 바꾼 내용을
    // 덮어썼다(lost update). 실제로 되살아난 알람의 id만 골라서 최신 저장본에 얹는다.
    const reactivated = [];
    alarms.forEach(a => {
      if (a.disabled && a.reactivateAt && now >= a.reactivateAt) {
        a.disabled = false;
        delete a.reactivateAt;
        reactivated.push(a.id);
      }
    });
    if (!reactivated.length) return;
    updateAlarms(arr => {
      let hit = false;
      arr.forEach(a => {
        if (reactivated.indexOf(a.id) === -1) return;
        a.disabled = false;
        delete a.reactivateAt;
        hit = true;
      });
      return hit ? arr : false;
    });
  }

  function loadAlarms() {
    chrome.storage.local.get(STORAGE_KEY, data => {
      alarms = data[STORAGE_KEY] || [];
      migrateV1();
      checkReactivations();
      if (alarms.some(isActive)) startPolling();
      if (alarms.some(a => a.type === 'trend' && isActive(a))) startTrendChecking();
      dispatchAlarmsToChart();
    });
  }

  function migrateV1() {
    if (alarms.length) return;
    try {
      const old = localStorage.getItem('upbit_alarms_v1');
      if (!old) return;
      const parsed = JSON.parse(old);
      if (!parsed.length) return;
      alarms = parsed.map(a => ({
        ...a,
        sym: a.code.replace('KRW-', ''),
        kor: '',
        disabled: a.fired || false,
        fired: false
      }));
      chrome.storage.local.set({ [STORAGE_KEY]: alarms });
      localStorage.removeItem('upbit_alarms_v1');
    } catch {}
  }

  // lastFiredBarT를 같이 넘기는 이유: once/interval은 perBar와 달리 alarms 배열을 통째로 저장하지
  // 않고 이 함수로만 저장하기 때문에, 안 넘기면 방금 울린 봉 기록이 저장소에 안 남아서 따라잡기
  // 폴링이 같은 봉을 또 울린다.
  function disableAlarm(id, reactivateAt, lastFiredBarT) {
    return updateAlarms(arr => {
      const a = arr.find(x => x.id === id);
      if (a) {
        a.disabled = true; a.fired = false;
        if (reactivateAt) a.reactivateAt = reactivateAt;
        if (lastFiredBarT != null) a.lastFiredBarT = lastFiredBarT;
      }
      return arr;
    });
  }

  function enableAlarm(id) {
    // 재무장(armTrendAlarm)은 여기서 직접 안 부르고 아래 onChanged 리스너의 disabled 전환 감지로
    // 일원화함 — 팝업 토글로 재활성화하는 경로(popup.js가 storage를 직접 씀)까지 같이 잡으려고.
    return updateAlarms(arr => {
      const a = arr.find(x => x.id === id);
      if (a) { a.disabled = false; delete a.reactivateAt; }
      return arr;
    });
  }

  function getReactivateMs() {
    switch (currentSettings.reactivate) {
      case '30min': return 30 * 60 * 1000;
      case '1hour': return 60 * 60 * 1000;
      case 'custom': return Math.max(1, currentSettings.reactivateMinutes || 60) * 60 * 1000;
      default: return 0;
    }
  }

  function playAlarmSound(alarm) {
    // 추세선 알람은 "가격 알람과 동일" 설정(기본값)이면 sound를, 아니면 trendSound를 쓴다.
    const useTrend = alarm && alarm.type === 'trend' && currentSettings.trendSameAsPrice === false;
    const soundName = useTrend ? currentSettings.trendSound : currentSettings.sound;
    if (soundName === 'none') return;
    fetch(chrome.runtime.getURL(`sounds/${soundName}.wav`)).then(r=>r.blob()).then(blob=>{const u=URL.createObjectURL(blob);const a=new Audio(u);a.volume=(currentSettings.volume??70)/100;a.play().catch(()=>{});a.addEventListener('ended',()=>URL.revokeObjectURL(u));}).catch(()=>{});
  }

  function fetchPrices() {
    // 낡은 인스턴스는 가격 폴링도 하지 않는다(패스트패스 이중 발동 차단).
    if (!isLive()) return;
    if (!isCtxValid()) {
      if (window.__ubPollTimer) { clearInterval(window.__ubPollTimer); window.__ubPollTimer = null; }
      return;
    }
    const codes = [...new Set(alarms.filter(isActive).map(a => a.code))];
    if (!codes.length) {
      if (window.__ubPollTimer) { clearInterval(window.__ubPollTimer); window.__ubPollTimer = null; }
      return;
    }
    try {
      chrome.runtime.sendMessage({ action: 'fetchPrices', codes }, res => {
        try {
          if (chrome.runtime.lastError || !res || !res.ok) return;
          Object.keys(res.prices).forEach(code => checkAlarms(code, res.prices[code]));
        } catch {}
      });
    } catch {
      if (window.__ubPollTimer) { clearInterval(window.__ubPollTimer); window.__ubPollTimer = null; }
    }
  }

  function startPolling() {
    if (!isLive()) return;
    if (window.__ubPollTimer) clearInterval(window.__ubPollTimer);
    fetchPrices();
    window.__ubPollTimer = setInterval(fetchPrices, POLL_INTERVAL);
  }

  // [2026-08-23] 추세선 알람은 더 이상 이 자리에서 즉시비교로 안 잡음 — 죽은 dir 필드 기반 비교가
  // 방향/캔들과 무관하게 오탐을 냈던 원인이라, checkTrendFastPath(크로싱 감지)로 완전히 분리했음.
  // 가격 알람(수평 기준가)은 기존 방식 그대로 — 버그 리포트 없었고 dir이 실제로 유효한 필드임.
  function checkAlarms(code, price) {
    const nowSec = Math.floor(Date.now() / 1000);
    alarms.forEach(alarm => {
      if (!isActive(alarm) || alarm.code !== code) return;
      if (alarm.type === 'trend') {
        checkTrendFastPath(alarm, price, nowSec);
        return;
      }
      const ref = alarm.price;
      const triggered =
        (alarm.dir === 'above' && price >= ref) ||
        (alarm.dir === 'below' && price <= ref);
      if (triggered) {
        alarm.disabled = true;
        alarm.fired = false;
        const delay = getReactivateMs();
        disableAlarm(alarm.id, delay > 0 ? Date.now() + delay : null);
        fireAlarm(alarm, price, delay, ref);
      }
    });
  }

  function showToast(msg, memo, url) {
    const toast = document.createElement('div');
    toast.style.cssText = `
      position:fixed;top:24px;left:50%;transform:translateX(-50%) translateY(-80px);
      z-index:999999;background:linear-gradient(180deg, rgba(255,255,255,.05), rgba(255,255,255,0));
      background-color:#1e2127;color:#e9ecf1;border:1px solid #3d434d;
      border-radius:13px;padding:12px 18px;font-size:12.5px;font-weight:800;
      box-shadow:0 22px 44px -14px rgba(0,0,0,.7), inset 0 1px 0 rgba(255,255,255,.055);
      transition:transform .35s cubic-bezier(.2,1,.4,1);
      white-space:pre-line;text-align:center;min-width:250px;cursor:pointer;
      font-family:'Pretendard','Noto Sans KR',system-ui,sans-serif;
    `;
    const msgEl = document.createElement('div');
    msgEl.textContent = msg;
    toast.appendChild(msgEl);
    if (memo) {
      const memoEl = document.createElement('div');
      memoEl.textContent = memo;
      memoEl.style.cssText = 'margin-top:4px;font-size:11px;font-weight:700;color:#ef5350;';
      toast.appendChild(memoEl);
    }
    document.body.appendChild(toast);
    requestAnimationFrame(() => { toast.style.transform = 'translateX(-50%) translateY(0)'; });
    const dismiss = () => {
      toast.style.transform = 'translateX(-50%) translateY(-80px)';
      setTimeout(() => toast.remove(), 400);
    };
    toast.addEventListener('click', () => {
      if (url) window.location.href = url;
      dismiss();
    });
    setTimeout(dismiss, 7000);
  }

  function saveAlarmHistory(alarm, currentPrice, ref) {
    const thresholdPrice = ref != null ? ref : alarm.price;
    chrome.storage.local.get(HISTORY_KEY, data => {
      const history = data[HISTORY_KEY] || [];
      history.unshift({ id: Date.now(), exchange: 'upbit', label: alarm.label, sym: alarm.sym || alarm.code.replace('KRW-', ''), price: thresholdPrice, dir: alarm.dir, currentPrice, memo: alarm.memo || '', firedAt: Date.now(), unread: true });
      if (history.length > 50) history.length = 50;
      chrome.storage.local.set({ [HISTORY_KEY]: history });
    });
  }

  function fireAlarm(alarm, currentPrice, delay, ref) {
    const thresholdPrice = ref != null ? ref : alarm.price;
    saveAlarmHistory(alarm, currentPrice, thresholdPrice);
    if (isCtxValid()) chrome.runtime.sendMessage({ action: 'sendPush', alarm: { ...alarm, price: thresholdPrice }, currentPrice, exchange: 'upbit' }, () => {});
    const label = alarm.type === 'trend' ? `${alarm.label} 추세선` : alarm.label;
    // 추세선은 이상/이하 방향 개념이 없음(죽은 dir 필드 더는 안 씀) — "터치" 문구로 통일.
    const body = alarm.type === 'trend'
      ? `${label} 터치! ${Number(thresholdPrice).toLocaleString()}원\n현재가: ${Number(currentPrice).toLocaleString()}원`
      : `${label} ${Number(thresholdPrice).toLocaleString()}원 ${alarm.dir === 'above' ? '이상' : '이하'} 도달!\n현재가: ${Number(currentPrice).toLocaleString()}원`;
    const url = `https://upbit.com/exchange?code=CRIX.UPBIT.${alarm.code}`;
    showToast(`🔔 ${body}`, alarm.memo || '', url);
    if (Notification.permission === 'granted') {
      new Notification('🔔 업비트 가격 알람', { body });
    }
    playAlarmSound(alarm);
    if (delay > 0) setTimeout(() => enableAlarm(alarm.id), delay);
  }

  function dispatchAlarmsToChart() {
    const sym = getUpbitSym();
    if (!sym) return;
    const pageAlarms = alarms.filter(a => a.code === `KRW-${sym}`);
    window.dispatchEvent(new CustomEvent('kta-alarms', { detail: pageAlarms }));
  }

  chrome.storage.onChanged.addListener(changes => {
    // 낡은 인스턴스의 리스너는 제거할 방법이 없으니(스크립트 재주입이라 참조가 안 남음)
    // 여기서 스스로 빠진다 — 안 그러면 저장소가 바뀔 때마다 낡은 인스턴스도 폴링을 되살린다.
    if (!isLive()) return;
    if (changes[STORAGE_KEY]) {
      const oldArr = changes[STORAGE_KEY].oldValue || [];
      alarms = changes[STORAGE_KEY].newValue || [];
      // 추세 알람이 disabled:true→false로 바뀌는 걸 여기서 한 번에 감지해서 재무장.
      // popup.js 토글(직접 storage 기록)이든 content.js 자체 재활성화 타이머든 경로 상관없이 다 잡힘 —
      // 안 하면 꺼져있는 동안의 낡은 armedBarTime이 남아서 "이미 닿아있는 채로 재활성화"하면 즉시 재발동될 수 있음.
      alarms.forEach(a => {
        if (a.type !== 'trend') return;
        const prev = oldArr.find(x => x.id === a.id);
        if (prev && prev.disabled && !a.disabled) armTrendAlarm(a.id);
      });
      if (alarms.some(isActive)) startPolling();
      else if (window.__ubPollTimer) { clearInterval(window.__ubPollTimer); window.__ubPollTimer = null; }
      if (alarms.some(a => a.type === 'trend' && isActive(a))) startTrendChecking();
      else stopTrendChecking();
      dispatchAlarmsToChart();
    }
    if (changes[SETTINGS_KEY]) {
      currentSettings = { sound: 'ding', reactivate: 'custom', reactivateMinutes: 1, trendSameAsPrice: true, trendSound: 'ding3', trendLastExtend: 'right', trendLastScale: 'linear', trendLastRepeat: 'perBar', ...(changes[SETTINGS_KEY].newValue || {}) };
    }
  });

  // 아래 window/runtime 리스너들도 낡은 인스턴스가 같이 반응하면 저장소 쓰기가 중복돼서
  // lost update(방금 기록한 상태가 낡은 스냅샷에 덮여 사라짐)를 만든다 — 전부 최신 세대만 처리.
  window.addEventListener('kta-symbol-changed', () => {
    if (!isLive()) return;
    setTimeout(dispatchAlarmsToChart, 200);
  });

  window.addEventListener('kta-save-line-settings', e => {
    if (!isLive() || !e.detail) return;
    chrome.storage.local.set({ [CHART_SETTINGS_KEY]: e.detail });
  });

  window.addEventListener('kta-update-memo', e => {
    if (!isLive()) return;
    const { id, memo } = e.detail || {};
    if (!id) return;
    updateAlarms(arr => {
      const alarm = arr.find(a => a.id === id);
      if (!alarm) return false;
      alarm.memo = memo;
      return arr;
    });
  });

  // [2026-08-23] 3단계: 온차트 더블클릭 편집 배너(chart_lines.js)는 chrome.storage에 직접 접근 못 하는
  // MAIN world라 켜기/끄기·삭제도 이 이벤트 중계를 거쳐야 함 — 팝업 목록의 토글/삭제와 동일 로직.
  window.addEventListener('kta-alarm-toggle', e => {
    if (!isLive()) return;
    const { id } = e.detail || {};
    if (!id) return;
    updateAlarms(arr => {
      const a = arr.find(x => x.id === id);
      if (!a) return false;
      if (a.disabled) { a.disabled = false; a.fired = false; }
      else { a.disabled = true; }
      return arr;
    });
  });

  window.addEventListener('kta-alarm-delete', e => {
    if (!isLive()) return;
    const { id } = e.detail || {};
    if (!id) return;
    updateAlarms(arr => arr.filter(x => x.id !== id));
  });

  // [2026-08-23] 가격 알람(수평선) 좌표 다시찍기 — 처음엔 추세선의 kta-trend-quick-save(editId
  // 경로)와 같은 철학으로 "좌표(가격)만 갱신하고 방향(dir)·조건은 안 건드림"이라고 짰는데, 그건
  // 추세선(dir이 죽은 필드)에서만 성립하는 전제였음.
  // [2026-08-24 수정] 오푸스 최종검토에서 확정: 가격 알람은 dir이 살아있는 필드라, 현재가 위에
  // 있던 알람을 아래로 다시 찍어도 dir이 'above'로 그대로 남아서 checkAlarms의 price>=ref가
  // 다시찍자마자 바로 참이 돼 즉시 발동해버림 — 이번 작업 전체의 목표("만들자마자 안 울림")가
  // 재배치 경로에서만 빠져있던 안전 구멍. 신규생성(kta-price-quick-create)과 동일하게 실시간가
  // 재확인 후 dir도 같이 재판정하도록 통일 — 동률/판정불가는 그대로 두고 거절(kta-price-repriced
  // ok:false)한다.
  window.addEventListener('kta-price-quick-reprice', e => {
    if (!isLive()) return;
    const { id, price } = e.detail || {};
    if (!id || !Number.isFinite(price)) return;
    const sym = getUpbitSym();
    if (!sym) { window.dispatchEvent(new CustomEvent('kta-price-repriced', { detail: { ok: false, id, reason: 'no-sym' } })); return; }
    const code = 'KRW-' + sym;
    chrome.runtime.sendMessage({ action: 'fetchPrices', codes: [code] }, res => {
      if (chrome.runtime.lastError || !res || !res.ok || !Number.isFinite(res.prices?.[code])) {
        window.dispatchEvent(new CustomEvent('kta-price-repriced', { detail: { ok: false, id, reason: 'price-fetch-failed' } }));
        return;
      }
      const cur = res.prices[code];
      const dir = decidePriceDir(price, cur);
      if (!dir) {
        window.dispatchEvent(new CustomEvent('kta-price-repriced', { detail: { ok: false, id, reason: 'tie' } }));
        return;
      }
      updateAlarms(arr => {
        const alarm = arr.find(a => a.id === id);
        if (!alarm) return false;
        alarm.price = price;
        alarm.dir = dir;
        alarm.fired = false; alarm.disabled = false; delete alarm.reactivateAt;
        return arr;
      }).then(() => {
        startPolling();
        window.dispatchEvent(new CustomEvent('kta-price-repriced', { detail: { ok: true, id, price, dir } }));
      });
    });
  });

  // ── 추세선(익스텐디드 라인) 좌표 찍기: 팝업 → content(여기) → 페이지(chart_lines.js) 중계 ──
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!isLive()) return;
    if (msg && msg.action === 'startTrendPick') {
      window.dispatchEvent(new CustomEvent('kta-start-trend-pick', { detail: { editId: msg.editId } }));
      sendResponse && sendResponse({ ok: true });
    }
    // [2026-08-23] 가격 알람 차트클릭 생성/재배치 — 팝업의 "차트에서 가격 찍기" 버튼, 더블클릭
    // 편집배너의 "좌표 다시찍기" 둘 다 이 메시지를 거쳐 chart_lines.js로 중계됨.
    if (msg && msg.action === 'startPriceAlarmPick') {
      window.dispatchEvent(new CustomEvent('kta-start-price-pick', { detail: { editId: msg.editId } }));
      sendResponse && sendResponse({ ok: true });
    }
  });

  // [2026-08-23] 가격 알람 픽 배너의 "직접 입력" 탈출구 — 기존 quickAdd(팝업 숫자입력) 경로 그대로 재사용.
  window.addEventListener('kta-open-price-popup', () => {
    if (!isLive() || !isCtxValid()) return;
    const sym = getUpbitSym();
    if (!sym) return;
    chrome.runtime.sendMessage({ action: 'quickAdd', sym });
  });

  // [2026-08-23] 클릭한 가격이 현재가 대비 위/아래인지 판정하는 단일 규칙(오푸스 설계 그대로) —
  // 동률은 절대 above/below로 억지 판정하지 않고 null(생성 거절). 자석이 마지막봉 종가에 붙으면
  // 그 값이 현재가와 정확히 같아지는데(실측 F1), 그대로 above/below를 매겨서 만들면 >=/<= 조건상
  // 다음 폴링에 바로 발동해버려서 "만들자마자 울리는 알람"이 구조적으로 생김 — 이 한 줄이 그 방어선.
  function decidePriceDir(target, cur) {
    if (!Number.isFinite(target) || !Number.isFinite(cur) || cur <= 0) return null;
    if (target > cur) return 'above';
    if (target < cur) return 'below';
    return null;
  }

  // [2026-08-23] 가격 알람 차트클릭 신규 생성 — 오푸스 설계(project_kalert_price_alarm_click_create_
  // 20260823) 그대로: chart_lines가 이미 값싼 근사치(마지막봉 종가)로 뻔한 동률은 걸러줬지만, 그 값이
  // 정말 최신이라는 보장은 없어서 저장 직전 실시간가로 한 번 더 확정 판정(2중 방어의 마지막 관문).
  window.addEventListener('kta-price-quick-create', e => {
    if (!isLive()) return;
    const { price } = e.detail || {};
    if (!Number.isFinite(price) || price <= 0) return;
    const sym = getUpbitSym();
    if (!sym) { window.dispatchEvent(new CustomEvent('kta-price-created', { detail: { ok: false, reason: 'no-sym' } })); return; }
    const code = 'KRW-' + sym;
    chrome.runtime.sendMessage({ action: 'fetchPrices', codes: [code] }, res => {
      if (chrome.runtime.lastError || !res || !res.ok || !Number.isFinite(res.prices?.[code])) {
        window.dispatchEvent(new CustomEvent('kta-price-created', { detail: { ok: false, reason: 'price-fetch-failed' } }));
        return;
      }
      const cur = res.prices[code];
      const dir = decidePriceDir(price, cur);
      if (!dir) {
        // 값싼 근사치로는 못 걸렀지만 실시간가로 재확인하니 진짜 동률(또는 판정불가) — 생성 안 함.
        window.dispatchEvent(new CustomEvent('kta-price-created', { detail: { ok: false, reason: 'tie' } }));
        return;
      }
      const newId = Date.now();
      updateAlarms(arr => {
        arr.push({ id: newId, code, sym, kor: '', label: sym, price, dir, memo: '', fired: false, disabled: false });
        return arr;
      }).then(() => {
        startPolling();
        window.dispatchEvent(new CustomEvent('kta-price-created', { detail: { ok: true, id: newId, price, dir } }));
      });
    });
  });

  // chart_lines.js의 좌표찍기 완료 후 인라인 미니폼(배너 안 메모입력)에서 바로 저장.
  // 신규 생성(editId 없음)과 기존 알람 좌표 재설정(editId 있음, 메모/조건은 건드리지 않음)을 모두 처리.
  window.addEventListener('kta-trend-quick-save', e => {
    if (!isLive()) return;
    const detail = e.detail || {};
    const { a1, a2, scale, tf, memo, editId } = detail;
    if (!a1 || !a2) return;
    // 1초봉은 chart_lines.js의 startTrendPick 단계에서 이미 막지만, 방어적으로 여기서도 한 번 더 차단.
    if (tf === '1S') return;
    if (editId) {
      // 좌표 재설정(다시찍기)은 좌표·타임프레임만 갱신 — 연장방향/가격축은 팝업 목록의 별도
      // 편집 드롭다운이 담당하는 필드라 여기서 덮어쓰지 않음(2026-08-23, 형 피드백으로 분리).
      updateAlarms(arr => {
        const alarm = arr.find(x => x.id === editId);
        if (!alarm) return false;
        alarm.a1 = a1; alarm.a2 = a2; alarm.tf = tf;
        alarm.fired = false; alarm.disabled = false; delete alarm.reactivateAt;
        alarm.armPending = Date.now(); // armTrendAlarm이 끝날 때까지 따라잡기 폴링 보류
        return arr;
      // 좌표가 바뀌었으니 지금 봉이 이미 닿아있는지 다시 판정해서 무장 상태를 새로 잡음.
      }).then(() => armTrendAlarm(editId));
      return;
    }
    const sym = getUpbitSym();
    if (!sym) return;
    // 연장방향/가격축/반복방식은 마지막으로 저장한 값을 기본으로 사용(형이 별도로 안 건드리는 한 유지되길 원함).
    const extend = currentSettings.trendLastExtend || 'right';
    const trendScale = currentSettings.trendLastScale || scale || 'linear';
    const repeat = currentSettings.trendLastRepeat || 'perBar';
    const newId = Date.now();
    updateAlarms(arr => {
      arr.push({
        id: newId, code: 'KRW-' + sym, sym, kor: '', label: sym,
        type: 'trend', a1, a2, extend, scale: trendScale, tf,
        repeat, armedBarTime: null, lastFiredBarT: null, armPending: Date.now(),
        memo: (memo || '').trim(), fired: false, disabled: false
      });
      return arr;
    }).then(() => {
      startTrendChecking();
      armTrendAlarm(newId);
    });
  });

  document.addEventListener('visibilitychange', () => {
    if (!isLive()) return;
    if (document.visibilityState === 'visible') {
      checkReactivations();
      if (alarms.some(isActive)) startPolling();
      if (alarms.some(a => a.type === 'trend' && isActive(a))) startTrendChecking();
    }
  });

  if (Notification.permission === 'default') Notification.requestPermission();
  loadSettings();
  loadChartSettings();
  loadAlarms();

  // ── 빠른 추가 + 버튼 ──────────────────────────────────────────────
  function getUpbitSym() {
    const m = location.search.match(/[?&]code=CRIX\.UPBIT\.KRW-([A-Z0-9]+)/i);
    return m ? m[1].toUpperCase() : null;
  }

  // 위치(bottom:80px / right:20px)는 그대로.
  // [2026-08-07] 색을 앱 accent(로즈) 고정에서 **거래소 색**으로 교체.
  // 이 파일은 업비트 전용 content script라 업비트 파랑으로 고정한다.
  // 값은 시안(ktraderkey_kalert_mockup_artifact.html)의 --up1/--up2 다크셋 그대로.
  // [2026-08-23] +버튼을 스피드다이얼로 개편 — 클릭하면 "가격알람"/"추세선알람" 두 자식버튼이
  // 순차 애니메이션으로 튀어나옴. 추세선알람은 팝업을 거치지 않고 바로 좌표찍기로 진입.
  function injectQuickAddStyleOnce() {
    if (document.getElementById('kta-fab-style')) return;
    const style = document.createElement('style');
    style.id = 'kta-fab-style';
    style.textContent = `
#kta-fab-wrap{position:fixed;bottom:80px;right:20px;z-index:999999;width:46px;height:46px;}
#kta-fab-wrap .kta-fab-main{position:absolute;left:0;top:0;width:46px;height:46px;border-radius:50%;
  background:linear-gradient(160deg,#60a5fa,#2563eb);color:#fff;padding:0;
  border:none;cursor:pointer;box-shadow:0 10px 24px -6px #2563eb, inset 0 1px 0 rgba(255,255,255,.35), 0 0 0 4px rgba(96,165,250,.16);
  display:flex;align-items:center;justify-content:center;font-family:'Pretendard',system-ui,sans-serif;
  transition:transform .22s cubic-bezier(.2,1.2,.4,1);z-index:2;}
#kta-fab-wrap .kta-fab-main svg{display:block;pointer-events:none;}
#kta-fab-wrap.open .kta-fab-main{transform:rotate(45deg);}
/* 자식 버튼 = +버튼과 동일 크기(46px), 같은 원점(top:0;left:0)에서 축 하나로만 이동 —
   가격은 바로 위(translateY), 추세는 바로 왼쪽(translateX)으로만 튀어나와서 대각선으로 안 밀림. */
#kta-fab-wrap .kta-fab-child{position:absolute;left:0;top:0;width:46px;height:46px;border-radius:50%;
  border:none;cursor:pointer;color:#fff;font-size:12px;font-weight:800;display:flex;align-items:center;justify-content:center;
  opacity:0;pointer-events:none;
  transition:transform .22s cubic-bezier(.2,1.2,.4,1), opacity .18s;
  box-shadow:0 6px 16px -4px rgba(0,0,0,.5), inset 0 1px 0 rgba(255,255,255,.3);
  font-family:'Pretendard',system-ui,sans-serif;white-space:nowrap;text-align:center;line-height:1.15;}
#kta-fab-wrap.open .kta-fab-child{opacity:1;pointer-events:auto;}
/* [2026-08-23] 메인(+)버튼과 같은 파란색이라 구분이 잘 안 된다는 형 피드백 — 추세(로즈)·메인(블루)과
   또렷이 구분되면서도 안 튀는 앰버/골드로 교체. "가격=금액" 연상도 자연스러움. */
#kta-fab-wrap .kta-fab-price{background:linear-gradient(160deg,#fbbf24,#d97706);transform:translateY(0) scale(.6);}
#kta-fab-wrap.open .kta-fab-price{transform:translateY(-56px) scale(1);}
#kta-fab-wrap .kta-fab-trend{background:linear-gradient(160deg,#fb7185,#be123c);transition-delay:0s;transform:translateX(0) scale(.6);}
#kta-fab-wrap.open .kta-fab-trend{transform:translateX(-56px) scale(1);transition-delay:.04s;}
`;
    document.head.appendChild(style);
  }

  function injectQuickAddBtn(sym) {
    if (document.getElementById('kta-fab-wrap')) return;
    injectQuickAddStyleOnce();
    const wrap = document.createElement('div');
    wrap.id = 'kta-fab-wrap';

    const trendBtn = document.createElement('button');
    trendBtn.className = 'kta-fab-child kta-fab-trend';
    trendBtn.textContent = '추세';
    trendBtn.title = '추세선 알람 — 차트에서 좌표 찍기';
    trendBtn.addEventListener('click', ev => {
      ev.stopPropagation();
      wrap.classList.remove('open');
      window.dispatchEvent(new CustomEvent('kta-start-trend-pick'));
    });

    const priceBtn = document.createElement('button');
    priceBtn.className = 'kta-fab-child kta-fab-price';
    priceBtn.textContent = '가격';
    // [2026-08-23] 팝업 숫자입력(quickAdd) 대신 차트 클릭 생성으로 기본 동작 교체(형 요청 1번) —
    // 숫자로 직접 입력하고 싶을 때는 픽 배너의 "직접 입력" 링크로 여전히 quickAdd 경로를 탈 수 있음.
    priceBtn.title = `${sym} 가격 알람 — 차트에서 가격 찍기`;
    priceBtn.addEventListener('click', ev => {
      ev.stopPropagation();
      wrap.classList.remove('open');
      window.dispatchEvent(new CustomEvent('kta-start-price-pick'));
    });

    const main = document.createElement('button');
    main.className = 'kta-fab-main';
    main.id = 'kta-quick-add-btn';
    // 텍스트 "+" 글자는 폰트마다 시각 중심이 미묘하게 안 맞아서 45도 회전 시 X가 비뚤어 보임 —
    // viewBox 정중앙(12,12) 기준 대칭 막대 2개짜리 SVG로 교체해 회전축을 완벽히 중앙에 고정.
    main.innerHTML = '<svg viewBox="0 0 24 24" width="20" height="20"><rect x="10.5" y="3" width="3" height="18" rx="1.5" fill="currentColor"/><rect x="3" y="10.5" width="18" height="3" rx="1.5" fill="currentColor"/></svg>';
    main.title = `${sym} 알람 추가`;
    main.addEventListener('click', ev => {
      ev.stopPropagation();
      wrap.classList.toggle('open');
    });

    // 바깥 클릭 시 닫기 — stopPropagation은 절대 안 씀(차트 팬/줌 안 깨지게).
    document.addEventListener('click', () => wrap.classList.remove('open'));

    wrap.appendChild(trendBtn);
    wrap.appendChild(priceBtn);
    wrap.appendChild(main);
    document.body.appendChild(wrap);
  }

  function initQuickAddBtn() {
    chrome.storage.local.get('upbit_alarm_settings_v1', data => {
      const s = data['upbit_alarm_settings_v1'] || {};
      if (s.quickAddBtn === false) return;
      const sym = getUpbitSym();
      if (sym) injectQuickAddBtn(sym);
    });
  }

  initQuickAddBtn();

  // URL 감시 타이머도 세대마다 하나씩 쌓이므로 낡은 세대는 스스로 멈춘다.
  let _lastHref = location.href;
  const _hrefTimer = setInterval(() => {
    if (!isLive()) { clearInterval(_hrefTimer); return; }
    if (location.href !== _lastHref) {
      _lastHref = location.href;
      document.getElementById('kta-fab-wrap')?.remove();
      initQuickAddBtn();
      dispatchAlarmsToChart();
    }
  }, 500);
  window.addEventListener('popstate', () => { if (!isLive()) return; document.getElementById('kta-fab-wrap')?.remove(); initQuickAddBtn(); });


})();
