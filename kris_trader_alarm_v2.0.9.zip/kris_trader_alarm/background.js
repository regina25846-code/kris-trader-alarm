const CURRENT_VERSION = '2.0.8';
const VERSION_CHECK_URL = 'https://regina25846-code.github.io/kris-trader-alarm/version.json';
const UPDATE_PAGE_URL   = 'https://regina25846-code.github.io/kris-trader-alarm/';

function checkForUpdate() {
  fetch(VERSION_CHECK_URL + '?t=' + Date.now())
    .then(r => r.json())
    .then(data => {
      const latest = data.version || '0';
      if (latest > CURRENT_VERSION) {
        chrome.storage.local.set({ pendingUpdate: { version: latest, page: data.page || UPDATE_PAGE_URL, changelog: data.changelog || '' } });
        chrome.action.setBadgeText({ text: 'UP' });
        chrome.action.setBadgeBackgroundColor({ color: '#ef5350' });
      } else {
        chrome.storage.local.remove('pendingUpdate');
        chrome.action.setBadgeText({ text: '' });
      }
    })
    .catch(() => {});
}

const UPBIT_URLS = [{ urlPrefix: 'https://upbit.com/' }, { urlPrefix: 'https://www.upbit.com/' }];
const BITHUMB_URLS = [{ urlPrefix: 'https://www.bithumb.com/' }];

function injectTab(tabId, file) {
  chrome.scripting.executeScript({
    target: { tabId },
    files: [file]
  }).catch(() => {});
}

function injectAllTabs() {
  chrome.tabs.query({ url: ['https://upbit.com/*', 'https://www.upbit.com/*'] }, (tabs) => {
    (tabs || []).forEach(tab => injectTab(tab.id, 'content.js'));
  });
  chrome.tabs.query({ url: ['https://www.bithumb.com/*'] }, (tabs) => {
    (tabs || []).forEach(tab => injectTab(tab.id, 'bithumb_content.js'));
  });
}

chrome.webNavigation.onCompleted.addListener((details) => {
  if (details.frameId === 0) injectTab(details.tabId, 'content.js');
}, { url: UPBIT_URLS });

chrome.webNavigation.onCompleted.addListener((details) => {
  if (details.frameId === 0) injectTab(details.tabId, 'bithumb_content.js');
}, { url: BITHUMB_URLS });

chrome.runtime.onStartup.addListener(() => { injectAllTabs(); checkForUpdate(); });
chrome.runtime.onInstalled.addListener(() => { injectAllTabs(); checkForUpdate(); });

chrome.tabs.onActivated.addListener(({ tabId }) => {
  chrome.tabs.get(tabId, (tab) => {
    if (!tab.url) return;
    if (tab.url.startsWith('https://upbit.com/') || tab.url.startsWith('https://www.upbit.com/')) {
      injectTab(tabId, 'content.js');
    } else if (tab.url.startsWith('https://www.bithumb.com/')) {
      injectTab(tabId, 'bithumb_content.js');
    }
  });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'fetchPrices' && msg.codes && msg.codes.length) {
    fetch(`https://api.upbit.com/v1/ticker?markets=${msg.codes.join(',')}`)
      .then(r => r.json())
      .then(data => {
        const prices = {};
        data.forEach(d => { prices[d.market] = d.trade_price; });
        sendResponse({ ok: true, prices });
      })
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.action === 'fetchMarkets') {
    fetch('https://api.upbit.com/v1/market/all?isDetails=false')
      .then(r => r.json())
      .then(data => {
        const markets = data
          .filter(m => m.market.startsWith('KRW-'))
          .map(m => ({ code: m.market, sym: m.market.replace('KRW-', ''), kor: m.korean_name, eng: m.english_name }));
        sendResponse({ ok: true, markets });
      })
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.action === 'quickAdd') {
    chrome.storage.local.set({ quickAddSym: msg.sym }, () => {
      chrome.action.openPopup().catch(() => {});
    });
    return;
  }
  if (msg.action === 'fetchBithumbPrices') {
    fetch('https://api.bithumb.com/public/ticker/ALL_KRW')
      .then(r => r.json())
      .then(data => {
        const prices = {};
        if (data.status === '0000') {
          Object.entries(data.data).forEach(([sym, info]) => {
            if (sym !== 'date') prices[sym] = parseFloat(info.closing_price);
          });
        }
        sendResponse({ ok: true, prices });
      })
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
});
