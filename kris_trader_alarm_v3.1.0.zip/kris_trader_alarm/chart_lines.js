(function () {
  'use strict';

  let _chart = null;
  let latestAlarms = [];
  let pendingAlarms = null;
  let renderDebounce = null;
  let _setupDone = false;
  let panelTheme = 'dark';

  function getTheme() {
    return panelTheme === 'dark'
      ? { bg: '#1e2235', bg2: '#13162a', border: '#2f3349', text: '#d1d4dc', lbl: '#9096b0', accent: '#6366f1', accentH: '#4f52cc', x: '#6a6f8a', div: '#2f3349', icon: '☀️', nextLabel: '라이트' }
      : { bg: '#ffffff', bg2: '#f0f3fa', border: '#d0d4e8', text: '#1a1d2e', lbl: '#666a80', accent: '#5558d4', accentH: '#4346b0', x: '#8888a0', div: '#d0d4e8', icon: '🌙', nextLabel: '다크' };
  }

  const DEFAULT_SETTINGS = {
    showBell: false, showArrow: false, showMemo: true, showPrice: false,
    aboveColor: '#ef5350', belowColor: '#26a69a',
    lineStyle: 2, lineWidth: 1,
    fontSize: 11, fontBold: false,
    horzAlign: 'right', vertAlign: 'bottom',
  };
  let lineSettings = { ...DEFAULT_SETTINGS };

  // ── 차트 탐색 ─────────────────────────────────────────────────────────
  // TV 차트는 #tv_chart_container 안의 iframe.contentWindow.tradingViewApi 에 있음

  function findChart() {
    try {
      const iframe = document.querySelector('#tv_chart_container iframe');
      if (!iframe) return null;
      const api = iframe.contentWindow?.tradingViewApi;
      if (!api) return null;
      return api.activeChart();
    } catch (e) { return null; }
  }

  // 300ms마다 차트 탐색 + FAB 갱신 + 라인 그리기
  setInterval(() => {
    if (!_chart) {
      _chart = findChart();
      if (_chart && !_setupDone) {
        _setupDone = true;
        console.log('[KTA] chart 발견, 이벤트 연결');
        setupEvents();
        const toRender = pendingAlarms ?? latestAlarms;
        pendingAlarms = null;
        if (toRender.length) renderLines(toRender);
      }
    }
    syncFab();
    if (_chart) drawOverlayLines();
  }, 300);

  function setupEvents() {
    const chart = _chart;
    try {
      chart.onSymbolChanged().subscribe(null, () => {
        removeOverlay();
        window.dispatchEvent(new CustomEvent('kta-symbol-changed'));
      });
    } catch (e) {}

    ['crossHairMoved', 'crosshairMoved'].forEach(name => {
      try { chart[name]()?.subscribe(null, () => drawOverlayLines()); } catch (e) {}
    });

    // 클릭은 라벨 span에서 직접 처리 (iframe이 클릭 이벤트를 가로채기 때문)
  }

  function removeOverlay() {
    document.getElementById('kta-line-overlay')?.remove();
  }

  // 메인 가격 패널의 실제 좌표 (canvas 기반으로 정확하게 탐색)
  function getMainPaneBounds() {
    const iframe = document.querySelector('#tv_chart_container iframe');
    if (!iframe) return null;
    const ir = iframe.getBoundingClientRect();
    try {
      const canvases = Array.from(iframe.contentWindow.document.querySelectorAll('canvas'));
      const mapped = canvases
        .map(c => { const r = c.getBoundingClientRect(); return { w: r.width, h: r.height, top: ir.top + r.top, left: ir.left + r.left }; })
        .filter(c => c.w > 300 && c.h > 50);
      if (!mapped.length) return null;
      const maxH = Math.max(...mapped.map(c => c.h));
      const mainPanes = mapped.filter(c => c.h === maxH);
      return {
        top: Math.min(...mainPanes.map(c => c.top)),
        left: Math.min(...mainPanes.map(c => c.left)),
        right: Math.max(...mainPanes.map(c => c.left + c.w)),
        height: maxH,
      };
    } catch (e) { return null; }
  }

  // 가격 → fixed Y픽셀 (메인 패널 기준)
  function priceToFixedY(pane, range, price) {
    if (!range || range.from == null || range.to == null || range.from === range.to) return null;
    const y = pane.height * (range.to - price) / (range.to - range.from);
    if (y < -30 || y > pane.height + 30) return null; // 화면 밖
    return pane.top + y;
  }

  function buildLabel(alarm) {
    const isAbove = alarm.dir === 'above';
    const parts = [];
    if (lineSettings.showBell) parts.push('🔔');
    if (lineSettings.showArrow) parts.push(isAbove ? '↑' : '↓');
    if (lineSettings.showPrice) parts.push(Number(alarm.price).toLocaleString());
    if (lineSettings.showMemo && alarm.memo) parts.push(alarm.memo);
    return parts.join(' ');
  }

  function getOrCreateOverlay() {
    // position:fixed 로 body에 직접 붙임 → iframe z-index 문제 없음
    let el = document.getElementById('kta-line-overlay');
    if (!el) {
      el = document.createElement('div');
      el.id = 'kta-line-overlay';
      el.style.cssText = 'position:fixed;top:0;left:0;width:0;height:0;pointer-events:none;z-index:2147483640;overflow:visible;';
      document.body.appendChild(el);
    }
    return el;
  }

  function drawOverlayLines(explicit = false) {
    syncFab();

    if (!_chart) return;
    const container = document.getElementById('tv_chart_container');
    if (!container) return;

    const overlay = getOrCreateOverlay();
    const active = latestAlarms.filter(a => !a.fired && !a.disabled);
    if (!active.length) { overlay.innerHTML = ''; return; }

    const pane = getMainPaneBounds();
    if (!pane) { if (!explicit && overlay.children.length > 0) return; overlay.innerHTML = ''; return; }

    let range;
    try { range = _chart.getVisiblePriceRange(); } catch (e) {
      if (!explicit && overlay.children.length > 0) return;
      overlay.innerHTML = ''; return;
    }
    if (!range || range.from == null || range.to == null || range.from === range.to) {
      if (!explicit && overlay.children.length > 0) return;
      overlay.innerHTML = ''; return;
    }

    const dashMap = { 0: 'solid', 1: 'dotted', 2: 'dashed' };
    const dash = dashMap[lineSettings.lineStyle] ?? 'dashed';

    overlay.innerHTML = '';

    active.forEach(a => {
      const price = parseFloat(a.price);
      const yFixed = priceToFixedY(pane, range, price);
      if (yFixed == null) return; // 화면 밖 스킵

      const isAbove = a.dir === 'above';
      const color = isAbove ? lineSettings.aboveColor : lineSettings.belowColor;

      const lineEl = document.createElement('div');
      lineEl.dataset.alarmId = a.id;
      const L = Math.round(pane.left);
      const R = Math.round(window.innerWidth - pane.right);
      lineEl.style.cssText = `position:fixed;left:${L}px;right:${R}px;top:${Math.round(yFixed)}px;height:0;` +
        `border-top:${lineSettings.lineWidth}px ${dash} ${color};`;

      const label = buildLabel(a);
      const span = document.createElement('span');
      span.textContent = label || '●';
      const ha = lineSettings.horzAlign;
      const va = lineSettings.vertAlign;
      const hStyle = ha === 'right' ? 'right:80px' : ha === 'left' ? 'left:8px' : 'left:50%;transform:translateX(-50%)';
      const vStyle = va === 'top' ? 'bottom:3px' : 'top:3px';
      span.style.cssText = `position:absolute;${hStyle};${vStyle};` +
        `color:${color};font-size:${lineSettings.fontSize}px;` +
        `font-weight:${lineSettings.fontBold ? '700' : '400'};` +
        `font-family:'Noto Sans KR',sans-serif;white-space:nowrap;` +
        `pointer-events:auto;cursor:pointer;`;
      span.title = '클릭 → 설정';
      span.addEventListener('click', (e) => { e.stopPropagation(); showSettingsPanel(a); });
      lineEl.appendChild(span);

      overlay.appendChild(lineEl);
    });
  }

  function findUpbitLogo() {
    const header = document.querySelector('header');
    if (!header) return null;
    const a = header.querySelector('a');
    if (a) return a;
    return header.firstElementChild || null;
  }

  function getLogoAnchorPos() {
    const el = findUpbitLogo();
    if (!el) return null;
    const r = el.getBoundingClientRect();
    if (!r.width || r.top > 80) return null;
    return {
      l: Math.max(2, Math.round(r.left) - 42),
      t: Math.max(2, Math.round(r.top + (r.height - 32) / 2)),
    };
  }

  function syncFab() {
    const onChart = !!document.getElementById('tv_chart_container');
    const widget = document.getElementById('kta-widget');

    if (!onChart) {
      if (widget) { widget._cleanup?.(); widget.remove(); }
      return;
    }

    // 이미 존재하면 위치만 업데이트
    if (widget) {
      const pos = getLogoAnchorPos();
      if (pos) { widget.style.left = pos.l + 'px'; widget.style.top = pos.t + 'px'; }
      return;
    }

    const pos = getLogoAnchorPos() || { l: 4, t: 8 };
    const w = document.createElement('div');
    w.id = 'kta-widget';
    w.style.cssText = `position:fixed;left:${pos.l}px;top:${pos.t}px;z-index:2147483647;`;
    w._cleanup = () => {};

    const btn = document.createElement('button');
    btn.id = 'kta-line-fab';
    btn.title = '클릭으로 알람선 설정 열기';
    btn.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white" width="24" height="24" style="display:block;pointer-events:none;"><path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/></svg>`;
    btn.style.cssText = `display:flex;align-items:center;justify-content:center;width:36px;height:32px;background:#003597;border:none;padding:0;border-radius:6px 6px 0 0;cursor:pointer;user-select:none;`;
    w.appendChild(btn);
    document.body.appendChild(w);

    btn.addEventListener('click', e => {
      e.stopPropagation();
      const panel = document.getElementById('kta-line-settings');
      if (panel) panel.remove();
      else showSettingsPanel(null);
    });
  }

  function renderLines(alarms) {
    latestAlarms = alarms;
    if (!_chart) { pendingAlarms = alarms; return; }
    if (renderDebounce) clearTimeout(renderDebounce);
    renderDebounce = setTimeout(() => { renderDebounce = null; drawOverlayLines(); }, 16);
  }

  // ── 설정 패널 ─────────────────────────────────────────────────────────

  function showSettingsPanel(alarm) {
    document.getElementById('kta-line-settings')?.remove();
    const widget = document.getElementById('kta-widget');
    if (!widget) return;
    const s = lineSettings;
    const t = getTheme();

    const panel = document.createElement('div');
    panel.id = 'kta-line-settings';
    panel.innerHTML = `
<style>
#kta-line-settings{position:absolute;top:100%;left:0;margin-top:-1px;width:272px;background:${t.bg};border:1px solid ${t.border};border-radius:0 6px 6px 6px;padding:14px;color:${t.text};font:13px/1.6 'Pretendard',system-ui,sans-serif;box-shadow:0 4px 24px rgba(0,0,0,.5);max-height:calc(100vh - 60px);overflow-y:auto;}
#kta-line-settings .ls-hd{font-weight:700;font-size:18px;display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:10px;}
#kta-line-settings .ls-hd-left{display:flex;align-items:center;gap:8px;}
#kta-line-settings .ls-theme{background:${t.bg2};border:1px solid ${t.border};color:${t.text};font:13px 'Pretendard',system-ui,sans-serif;padding:2px 8px;border-radius:5px;cursor:pointer;line-height:1.6;}
#kta-line-settings .ls-theme:hover{border-color:${t.accent};}
#kta-line-settings .ls-sec{margin-bottom:9px;}
#kta-line-settings .ls-lbl{color:${t.text};font-size:15px;font-weight:700;margin-bottom:4px;}
#kta-line-settings .ls-row{display:flex;gap:10px;flex-wrap:wrap;}
#kta-line-settings label{cursor:pointer;display:flex;align-items:center;gap:4px;font-size:13px;}
#kta-line-settings input[type=range]{width:100%;accent-color:${t.accent};vertical-align:middle;}
#kta-line-settings input[type=color]{width:100%;height:28px;border:none;border-radius:4px;cursor:pointer;padding:1px;}
#kta-line-settings input[type=text]{width:100%;background:${t.bg2};border:1px solid ${t.border};border-radius:6px;color:${t.text};padding:6px 8px;font:14px 'Pretendard',system-ui,sans-serif;outline:none;box-sizing:border-box;}
#kta-line-settings input[type=text]:focus{border-color:${t.accent};}
#kta-line-settings .ls-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;}
#kta-line-settings .ls-btn{width:100%;padding:9px;background:${t.accent};border:none;border-radius:6px;color:#fff;font-weight:700;cursor:pointer;font-size:15px;font-family:'Pretendard',system-ui,sans-serif;margin-top:10px;}
#kta-line-settings .ls-btn:hover{background:${t.accentH};}
#kta-line-settings .ls-x{cursor:pointer;color:${t.x};font-size:20px;line-height:1;}
#kta-line-settings .ls-div{border:none;border-top:1px solid ${t.div};margin:10px 0;}
</style>
<div class="ls-hd">
  <div class="ls-hd-left">알람선 설정<button class="ls-theme">${t.icon} ${t.nextLabel}모드</button></div>
  <span class="ls-x">✕</span>
</div>

${alarm ? `<div class="ls-sec">
  <div class="ls-lbl">비고 메모</div>
  <input type="text" id="kta-memo-input" placeholder="메모 없음" value="${(alarm.memo || '').replace(/"/g, '&quot;')}">
</div>
<hr class="ls-div">` : ''}

<div class="ls-sec">
  <div class="ls-lbl">표시 항목 (전체 적용)</div>
  <div class="ls-row">
    <label><input type="checkbox" id="ls-bell" ${s.showBell?'checked':''}> 종 🔔</label>
    <label><input type="checkbox" id="ls-arrow" ${s.showArrow?'checked':''}> 방향 ↑↓</label>
    <label><input type="checkbox" id="ls-price" ${s.showPrice?'checked':''}> 가격</label>
    <label><input type="checkbox" id="ls-memo" ${s.showMemo?'checked':''}> 비고</label>
  </div>
</div>

<div class="ls-sec">
  <div class="ls-lbl">선 스타일</div>
  <div class="ls-row">
    <label><input type="radio" name="ls-st" value="0" ${s.lineStyle===0?'checked':''}> 실선</label>
    <label><input type="radio" name="ls-st" value="1" ${s.lineStyle===1?'checked':''}> 점선</label>
    <label><input type="radio" name="ls-st" value="2" ${s.lineStyle===2?'checked':''}> 파선</label>
  </div>
</div>

<div class="ls-sec">
  <div class="ls-lbl">선 굵기: <span id="ls-wv">${s.lineWidth}</span>px</div>
  <input type="range" id="ls-w" min="1" max="4" value="${s.lineWidth}">
</div>

<div class="ls-sec">
  <div class="ls-lbl">폰트 크기: <span id="ls-fsv">${s.fontSize}</span>px</div>
  <input type="range" id="ls-fs" min="9" max="18" value="${s.fontSize}">
</div>

<div class="ls-sec">
  <div class="ls-lbl">텍스트 가로 위치</div>
  <div class="ls-row">
    <label><input type="radio" name="ls-ha" value="left" ${s.horzAlign==='left'?'checked':''}> 왼쪽</label>
    <label><input type="radio" name="ls-ha" value="center" ${s.horzAlign==='center'?'checked':''}> 가운데</label>
    <label><input type="radio" name="ls-ha" value="right" ${s.horzAlign==='right'?'checked':''}> 오른쪽</label>
  </div>
</div>

<div class="ls-sec">
  <div class="ls-lbl">텍스트 세로 위치</div>
  <div class="ls-row">
    <label><input type="radio" name="ls-va" value="top" ${s.vertAlign==='top'?'checked':''}> 선 위</label>
    <label><input type="radio" name="ls-va" value="bottom" ${s.vertAlign==='bottom'?'checked':''}> 선 아래</label>
  </div>
</div>

<div class="ls-sec"><label><input type="checkbox" id="ls-bold" ${s.fontBold?'checked':''}> 폰트 굵게</label></div>

<div class="ls-grid ls-sec">
  <div><div class="ls-lbl">이상 색상</div><input type="color" id="ls-ac" value="${s.aboveColor}"></div>
  <div><div class="ls-lbl">이하 색상</div><input type="color" id="ls-bc" value="${s.belowColor}"></div>
</div>

<button class="ls-btn">모든 알람선에 적용</button>`;

    widget.appendChild(panel);

    panel.querySelector('.ls-x').onclick = () => panel.remove();
    panel.querySelector('.ls-theme').onclick = () => {
      panelTheme = panelTheme === 'dark' ? 'light' : 'dark';
      saveChartSettings();
      syncFab();
      showSettingsPanel(alarm);
    };
    document.getElementById('ls-w').oninput = function () { document.getElementById('ls-wv').textContent = this.value; };
    document.getElementById('ls-fs').oninput = function () { document.getElementById('ls-fsv').textContent = this.value; };

    const memoInput = document.getElementById('kta-memo-input');

    function readSettings() {
      return {
        showBell: document.getElementById('ls-bell').checked,
        showArrow: document.getElementById('ls-arrow').checked,
        showMemo: document.getElementById('ls-memo').checked,
        showPrice: document.getElementById('ls-price').checked,
        lineStyle: parseInt(panel.querySelector('input[name="ls-st"]:checked')?.value ?? '2'),
        lineWidth: parseInt(document.getElementById('ls-w').value),
        fontSize: parseInt(document.getElementById('ls-fs').value),
        fontBold: document.getElementById('ls-bold').checked,
        horzAlign: panel.querySelector('input[name="ls-ha"]:checked')?.value ?? 'right',
        vertAlign: panel.querySelector('input[name="ls-va"]:checked')?.value ?? 'bottom',
        aboveColor: document.getElementById('ls-ac').value,
        belowColor: document.getElementById('ls-bc').value,
      };
    }

    panel.querySelectorAll('input').forEach(input => {
      if (input.id === 'kta-memo-input') return;
      const ev = (input.type === 'range' || input.type === 'color') ? 'input' : 'change';
      input.addEventListener(ev, () => {
        Object.assign(lineSettings, readSettings());
        drawOverlayLines(true);
      });
    });

    panel.querySelector('.ls-btn').onclick = () => {
      if (alarm && memoInput) {
        const newMemo = memoInput.value.trim();
        if (newMemo !== (alarm.memo || '').trim()) {
          const idx = latestAlarms.findIndex(a => a.id === alarm.id);
          if (idx >= 0) latestAlarms[idx].memo = newMemo;
          alarm.memo = newMemo;
          window.dispatchEvent(new CustomEvent('kta-update-memo', { detail: { id: alarm.id, memo: newMemo } }));
        }
      }
      const ns = readSettings();
      Object.assign(lineSettings, ns);
      saveChartSettings();
      drawOverlayLines(true);
      panel.remove();
    };
  }

  window.addEventListener('kta-alarms', e => {
    const alarms = e.detail || [];
    latestAlarms = alarms;
    syncFab();
    if (!_chart) { pendingAlarms = alarms; return; }
    renderLines(alarms);
  });

  function saveChartSettings() {
    window.dispatchEvent(new CustomEvent('kta-save-line-settings', { detail: {
      ...lineSettings,
      panelTheme,
    }}));
  }

  window.addEventListener('kta-line-settings', e => {
    const d = e.detail || {};
    Object.assign(lineSettings, d);
    if (d.panelTheme) panelTheme = d.panelTheme;
  });
})();
