'use strict';

// 페이지 컨텍스트(MAIN world)에서 실행 - React __reactProps$ 직접 호출 가능
document.addEventListener('__tk_react_click', e => {
  const el = e.detail?.el;
  if (!el) return;
  const pk = Object.keys(el).find(k => k.startsWith('__reactProps'));
  const onClick = pk && el[pk]?.onClick;
  if (onClick) {
    onClick({
      target: el, currentTarget: el, type: 'click',
      nativeEvent: new MouseEvent('click', { bubbles: true }),
      preventDefault() {}, stopPropagation() {},
      isPropagationStopped() { return false; },
      isDefaultPrevented() { return false; },
      persist() {},
    });
  } else {
    el.click();
  }
});
