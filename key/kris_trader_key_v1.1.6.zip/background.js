'use strict';

const CURRENT_VERSION = '1.1.6';
const VERSION_CHECK_URL = 'https://regina25846-code.github.io/kris-trader-alarm/key/version.json';
const UPDATE_PAGE_URL   = 'https://regina25846-code.github.io/kris-trader-alarm/key/';

function checkForUpdate() {
  fetch(VERSION_CHECK_URL + '?t=' + Date.now())
    .then(r => r.json())
    .then(data => {
      const latest = data.version || '0';
      if (latest > CURRENT_VERSION) {
        chrome.storage.local.set({ pendingUpdate: { version: latest, page: data.page || UPDATE_PAGE_URL, changelog: data.changelog || '' } });
        chrome.action.setBadgeText({ text: 'UP' });
        chrome.action.setBadgeBackgroundColor({ color: '#ef5350' });
      } else {
        chrome.storage.local.remove('pendingUpdate');
        chrome.action.setBadgeText({ text: '' });
      }
    })
    .catch(() => {});
}

chrome.runtime.onInstalled.addListener(() => { checkForUpdate(); });
chrome.runtime.onStartup.addListener(() => { checkForUpdate(); });
