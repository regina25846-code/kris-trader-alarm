'use strict';
// MAIN world — chrome.storage 사용 불가, DOM 속성으로 isolated world에서 설정 수신

function reactClickBtn(btn) {
  if (!btn) return;
  const pk = Object.keys(btn).find(k => k.startsWith('__reactProps'));
  if (pk && btn[pk]?.onClick) {
    btn[pk].onClick({
      target: btn, currentTarget: btn, type: 'click',
      nativeEvent: new MouseEvent('click', { bubbles: true }),
      preventDefault() {}, stopPropagation() {},
      isPropagationStopped() { return false; },
      isDefaultPrevented() { return false; },
      persist() {},
    });
  } else {
    btn.click();
  }
}

new MutationObserver(() => {
  // isolated world가 data-bt-autoconfirm="0" 으로 비활성화하지 않는 한 자동 승인
  if (document.documentElement.dataset.btAutoconfirm === '0') return;

  // 매수/매도 확인 버튼 감지 → 즉시 클릭
  const confirmBtn = [...document.querySelectorAll('button')].find(b => {
    const t = b.innerText.replace(/\s+/g, ' ').trim();
    return t.includes('매수 확인') || t.includes('매도 확인');
  });
  if (confirmBtn) { reactClickBtn(confirmBtn); return; }

  // 취소 확인 다이얼로그: "아니오" 버튼이 모달 안에 있을 때 → "주문 취소" 클릭
  const noBtn = [...document.querySelectorAll('button')].find(b => {
    if (b.innerText.trim() !== '아니오') return false;
    let el = b.parentElement;
    while (el) {
      if (el.className?.includes?.('Modal_modal') || el.className?.includes?.('modal')) return true;
      el = el.parentElement;
    }
    return false;
  });
  if (noBtn) {
    const parent = noBtn.closest('[class*="Modal_modal"], [class*="modal"]');
    const confirmBtn2 = parent
      ? [...parent.querySelectorAll('button')].find(b => b.innerText.trim() === '주문 취소')
      : null;
    if (confirmBtn2) reactClickBtn(confirmBtn2);
  }
}).observe(document.body, { childList: true, subtree: true });
