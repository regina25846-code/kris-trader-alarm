(function () {
  'use strict';

  if (window.__btInit) return;
  window.__btInit = true;

  // 팝업(popup.js)이 실제로 저장하는 키와 반드시 같아야 한다.
  // v1.1.6에서 popup.js만 v1→v2로 바뀌고 이 파일이 v1에 남아 있어서,
  // 팝업에서 저장한 값이 전혀 반영되지 않고 v1.1.6 이전 설정으로 주문이 나가던 버그가 있었다.
  const STORAGE_KEY = 'bithumb_shortcut_v2';
  const LEGACY_STORAGE_KEY = 'bithumb_shortcut_v1'; // 읽기 전용 폴백(v2가 아예 없을 때만)
  const BUILD_TAG = 'bithumb-content 2026-08-07b (storage=v2, 금액검증 2단계+제출전 최종관문, 효과음 컨텍스트 재사용)';

  const SOUND_DEFS = {
    buy: {
      sound1: [{ f:523,d:.08 },{ f:659,d:.08 },{ f:784,d:.15 }],
      sound2: [{ f:880,d:.05 },{ f:1047,d:.18,g:.25 }],
      sound3: [{ f:440,d:.06 },{ f:523,d:.06 },{ f:659,d:.06 },{ f:784,d:.12 }],
    },
    sell: {
      sound1: [{ f:784,d:.08 },{ f:659,d:.08 },{ f:523,d:.15 }],
      sound2: [{ f:1047,d:.05 },{ f:880,d:.18,g:.25 }],
      sound3: [{ f:523,d:.06 },{ f:440,d:.06 },{ f:349,d:.12 }],
    },
    cancel: {
      sound1: [{ f:220,d:.25,t:'sawtooth',g:.2 }],
      sound2: [{ f:330,d:.1 },{ f:220,d:.15,g:.2 }],
      sound3: [{ f:440,d:.05 },{ f:330,d:.05 },{ f:220,d:.08 },{ f:165,d:.12,g:.15 }],
    },
  };

  const WAV_SOUNDS = new Set(['ddukbaegi','ding3','donggeon','fanfare','levelup','tada','victory','minus']);

  // ── 오디오 ────────────────────────────────────────────────────────────
  // [2026-08-07] 매수/매도 효과음만 안 나던 버그 수정.
  //  원인 1) 재생할 때마다 new AudioContext()를 새로 만들었다. Chrome은 alt/ctrl 등
  //          수식키가 섞인 keydown을 "사용자 활성화(user activation)"로 인정하지 않기 때문에,
  //          alt+숫자로 실행되는 매수/매도에서는 그 순간 새로 만들어진 AudioContext가
  //          suspended 상태로 생성돼 오실레이터가 울리지 않았다.
  //          반대로 취소 단축키는 기본값이 수식키 없는 'a' / 'shift+s'(Shift는 활성화를
  //          막지 않음)라서 컨텍스트가 running으로 생성돼 정상적으로 소리가 났다.
  //          → "취소만 되고 매수/매도만 안 되던" 현상과 정확히 일치.
  //  원인 2) Chrome은 문서당 AudioContext 개수를 제한한다(약 6개). 주문을 연달아 내면
  //          new AudioContext()가 예외를 던졌고 빈 catch에 먹혀 조용히 실패했다.
  //  해결: 컨텍스트를 하나만 만들어 재사용 + 재생 직전 resume() + 사용자 입력 때 미리 깨우기.
  let _audioCtx = null;

  function getAudioCtx() {
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      if (!_audioCtx || _audioCtx.state === 'closed') _audioCtx = new AC();
      if (_audioCtx.state === 'suspended') _audioCtx.resume().catch(() => {});
      return _audioCtx;
    } catch (e) { return null; }
  }

  // 진짜 클릭/탭이 한 번이라도 들어오면 컨텍스트를 미리 만들어 running으로 깨워 둔다.
  // 이후 alt+1 같은 수식키 단축키에서는 이미 살아 있는 컨텍스트를 재사용하므로
  // 사용자 활성화가 인정되지 않아도 소리가 정상적으로 난다.
  function primeAudio() { if (cfg?.sound?.enabled) getAudioCtx(); }
  ['pointerdown', 'mousedown', 'touchend', 'keydown'].forEach(ev => {
    document.addEventListener(ev, primeAudio, { capture: true, passive: true });
  });

  function playElementAudio(src, vol, revokeUrl) {
    try {
      const a = new Audio(src);
      a.volume = vol;
      if (revokeUrl) a.addEventListener('ended', () => URL.revokeObjectURL(src));
      a.play().catch(err => { try { console.warn('[KT-Bithumb] 효과음 재생 실패:', err?.name || err); } catch (e) {} });
    } catch (e) {
      try { console.warn('[KT-Bithumb] 효과음 생성 실패:', e); } catch (e2) {}
    }
  }

  function playSound(type) {
    const snd = cfg.sound;
    if (!snd?.enabled) return;
    const vol = (snd.volume ?? 50) / 100;
    const sel = snd[type] || 'sound1';
    if (sel === 'custom') {
      const dataUrl = snd[`${type}Custom`];
      if (dataUrl) playElementAudio(dataUrl, vol, false);
      return;
    }
    if (WAV_SOUNDS.has(sel)) {
      // 확장이 리로드/업데이트되면 이미 열려있던 탭의 content script는 붕 뜬 상태로 남는데,
      // 이때 chrome.runtime 참조가 무효화돼 있을 수 있다(Extension context invalidated).
      // 그 상태에서 chrome.runtime.getURL을 바로 부르면 TypeError가 던져지므로 먼저 가드한다.
      if (!chrome?.runtime?.getURL) {
        console.warn('[KT-Bithumb] 효과음 로드 건너뜀 — chrome.runtime이 무효화됨(확장 새로고침 후 탭도 새로고침 필요).');
        return;
      }
      fetch(chrome.runtime.getURL(`sounds/${sel}.wav`))
        .then(r => r.blob())
        .then(blob => playElementAudio(URL.createObjectURL(blob), vol, true))
        .catch(err => { try { console.warn('[KT-Bithumb] 효과음 로드 실패:', err); } catch (e) {} });
      return;
    }
    const notes = SOUND_DEFS[type]?.[sel];
    if (!notes) return;
    const ctx = getAudioCtx();
    if (!ctx) return;
    const schedule = () => {
      try {
        let t = ctx.currentTime + 0.01;
        notes.forEach(({ f, d, g = 0.3, t: wt = 'sine' }) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.connect(gain); gain.connect(ctx.destination);
          osc.type = wt; osc.frequency.setValueAtTime(f, t);
          gain.gain.setValueAtTime(g * vol, t);
          gain.gain.exponentialRampToValueAtTime(0.001, t + d);
          osc.start(t); osc.stop(t + d + 0.02);
          t += d * 0.75;
        });
      } catch (e) {
        try { console.warn('[KT-Bithumb] 효과음 스케줄 실패:', e); } catch (e2) {}
      }
    };
    // resume()이 비동기라 아직 suspended면 깨어난 뒤에 스케줄한다(그래야 소리가 잘림 없이 남).
    if (ctx.state === 'suspended') ctx.resume().then(schedule).catch(schedule);
    else schedule();
  }

  const DEFAULT_SHORTCUTS = [
    { modifier: '',      key: 'a', command: 'CANCEL_1',   fixed: false },
    { modifier: 'shift', key: 's', command: 'CANCEL_ALL', fixed: false },
  ];

  const cfg = {
    autoConfirm: true,
    sound: { enabled: false, volume: 50, buy: 'sound1', sell: 'sound1', cancel: 'sound1' },
    shortcuts: DEFAULT_SHORTCUTS.map(s => ({ ...s })),
  };

  function syncAutoConfirmAttr() {
    document.documentElement.dataset.btAutoconfirm = cfg.autoConfirm ? '1' : '0';
  }

  function describeShortcuts() {
    return cfg.shortcuts.map(s => {
      const mod = s.modifier ? s.modifier + '+' : '';
      let extra = '';
      if (s.price) extra += ` 총액:${s.price}`;
      if (s.qty)   extra += ` 수량:${s.qty}`;
      return `${mod}${s.key || '-'}=${s.command || '-'}${extra}`;
    }).join(' | ');
  }

  function applySettings(saved, srcLabel) {
    if (saved) {
      cfg.autoConfirm = saved.autoConfirm !== false;
      if (saved.sound) cfg.sound = { ...cfg.sound, ...saved.sound };
      if (Array.isArray(saved.shortcuts)) cfg.shortcuts = saved.shortcuts;
    }
    syncAutoConfirmAttr();
    try {
      console.log(`[KT-Bithumb] ${BUILD_TAG} / 설정출처: ${srcLabel} / ${describeShortcuts()}`);
    } catch (e) {}
  }

  function loadSettings() {
    // v2(팝업이 쓰는 키)가 항상 우선. v2가 아예 없을 때만 구버전 v1로 폴백해서
    // v1.1.6 이전 사용자의 단축키가 통째로 사라지는 것만 막는다.
    chrome.storage.local.get([STORAGE_KEY, LEGACY_STORAGE_KEY], d => {
      if (d[STORAGE_KEY]) applySettings(d[STORAGE_KEY], STORAGE_KEY);
      else if (d[LEGACY_STORAGE_KEY]) applySettings(d[LEGACY_STORAGE_KEY], LEGACY_STORAGE_KEY + ' (구버전 폴백)');
      else applySettings(null, '기본값');
    });
  }

  chrome.storage.onChanged.addListener(changes => {
    if (changes[STORAGE_KEY] || changes[LEGACY_STORAGE_KEY]) loadSettings();
  });

  loadSettings();

  // ── Helpers ───────────────────────────────────────────────────────────
  const wait = ms => new Promise(r => setTimeout(r, ms));

  function isOnTradePage() {
    return location.pathname.startsWith('/react/trade/order/');
  }

  function getCurrentCoin() {
    const m = location.pathname.match(/\/order\/([A-Z]+)-/);
    return m ? m[1] : '';
  }

  // ── Selectors ─────────────────────────────────────────────────────────
  function getBuyTabBtn()  { return [...document.querySelectorAll('.Orders-module_orders-tab__button__sFJpl')].find(b => b.innerText.includes('매수')); }
  function getSellTabBtn() { return [...document.querySelectorAll('.Orders-module_orders-tab__button__sFJpl')].find(b => b.innerText.includes('매도')); }

  function getCurrentTab() {
    // aria-selected가 버튼이 아니라 부모 li(role=tab)에 있음(2026-07-16 빗썸 리빌드로 구조 변경됨)
    if (getBuyTabBtn()?.closest('[role="tab"]')?.getAttribute('aria-selected') === 'true') return 'buy';
    if (getSellTabBtn()?.closest('[role="tab"]')?.getAttribute('aria-selected') === 'true') return 'sell';
    // fallback: 제출 버튼 가시성
    const buyBtn = document.querySelector('[class*="button-row__buy"]');
    const r = buyBtn?.getBoundingClientRect();
    return (r && r.width > 0 && r.height > 0) ? 'buy' : 'sell';
  }

  function getOrderTypeBtn(type) {
    const label = type === 'limit' ? '지정' : '시장';
    return [...document.querySelectorAll('.BuySellTab-module_primaryTab-wrap__action__lyZKL')]
      .find(b => b.innerText.trim() === label);
  }

  function isOrderTypeActive(type) {
    return getOrderTypeBtn(type)?.getAttribute('aria-selected') === 'true';
  }

  function getPctBtn(pct) {
    return [...document.querySelectorAll('.OrderForm-module_order-form-qty-per__button__agQSS')]
      .find(b => b.innerText.trim() === pct);
  }

  function getSubmitBtn(type) {
    const keyword = type === 'buy' ? 'buy' : 'sell';
    return document.querySelector(`[class*="button-row__${keyword}"]`);
  }

  function getPriceInput()  { return document.querySelector('[data-testid="price-row-input"]'); }
  function getQtyInput()    { return document.querySelector('[data-testid="qty-row-input"]'); }
  function getAmountInput() { return document.querySelector('[data-testid="amount-row-input"]'); }

  function setReactInputValue(el, value) {
    try {
      const desc = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
      desc.set.call(el, String(value));
      el.dispatchEvent(new Event('input',  { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    } catch(e) {}
  }

  function fireClick(el) {
    if (!el) return;
    el.dispatchEvent(new PointerEvent('click', { bubbles: true, cancelable: true, detail: 1 }));
  }

  // postMessage로 MAIN world에 전달 (CustomEvent는 isolated→main 경계 통과 안 됨)
  function dispatchToMain(type) {
    window.postMessage({ __bt: true, type }, '*');
  }

  // ── Tab key labels (data-bt-key + CSS ::after, innerText 불변) ─────────
  const TAB_KEY_MAP = [
    { key: '1', match: b => b.className.includes('orders-tab__button') && b.innerText.includes('매수') },
    { key: '2', match: b => b.className.includes('orders-tab__button') && b.innerText.includes('매도') },
    { key: '3', match: b => b.innerText.trim() === '미체결 주문' },
    { key: '4', match: b => b.innerText.trim() === '체결 주문' },
    { key: '5', match: b => b.innerText.trim() === '원화' },
    { key: '6', match: b => b.innerText.trim() === '보유' },
    { key: '7', match: b => b.innerText.trim() === '관심' },
  ];

  function injectTabLabels() {
    if (!isOnTradePage()) return;
    TAB_KEY_MAP.forEach(({ key, match }) => {
      if (document.querySelector(`button[data-bt-key="${key}"]`)) return;
      const btn = [...document.querySelectorAll('button')].find(b => match(b) && isVisible(b));
      if (btn) btn.dataset.btKey = key;
    });
  }

  let _labelTimer = null;
  new MutationObserver(() => {
    clearTimeout(_labelTimer);
    _labelTimer = setTimeout(injectTabLabels, 400);
  }).observe(document.body, { childList: true, subtree: true });

  // ── Tab navigation (keys 1–7 when modal is closed) ───────────────────
  function navTab(key) {
    const textMap = { '3': '미체결 주문', '4': '체결 주문', '5': '원화', '6': '보유', '7': '관심' };
    if (key === '1') { if (getCurrentTab() !== 'buy')  { const b = getBuyTabBtn();  if (b) fireClick(b); } return; }
    if (key === '2') { if (getCurrentTab() !== 'sell') { const b = getSellTabBtn(); if (b) fireClick(b); } return; }
    const text = textMap[key];
    if (text) {
      const b = [...document.querySelectorAll('button')].find(b => b.innerText.trim() === text && isVisible(b));
      if (b) fireClick(b);
    }
  }

  // ── Tab / order type switching ────────────────────────────────────────
  async function switchToTab(type) {
    if (getCurrentTab() === type) return false;
    const btn = type === 'buy' ? getBuyTabBtn() : getSellTabBtn();
    if (btn) { fireClick(btn); await wait(120); return true; }
    return false;
  }

  async function switchOrderType(type) {
    if (isOrderTypeActive(type)) return false;
    const btn = getOrderTypeBtn(type);
    if (btn) { fireClick(btn); await wait(100); return true; }
    return false;
  }

  // ── 금액/가격으로 수량 계산 후 주입 ─────────────────────────────────────
  // [2026-08-07 · 실거래 사고 수정]
  //  사고: alt+1에 총액 5,100원을 설정했는데 실제로는 약 500,000원어치가 주문됨.
  //        (수량 337,609.72316002 × 가격 1.481 = 500,000)
  //  확정된 원인: 337609.723160027 은 정확히 String(500000 / 1.481) 이다. 즉 이 수량은
  //        빗썸이 만든 값이 아니라 **이 함수가 직접 계산해 넣은 값**이고, 그 재료가 된 amt가
  //        5100이 아니라 500000이었다. executeCustomOrder는 총액 5,100 주입을 verifyInjected로
  //        확인해 통과시킨 직후 이 함수를 불렀는데, 이 함수가 확인된 "의도 금액"을 쓰지 않고
  //        DOM(총액 입력창)을 **다시 읽었다**. 그 사이 빗썸 React가 총액칸을 직전 주문값
  //        500,000으로 되돌려놨고, 되돌아간 값으로 수량이 계산돼 그대로 주문이 나갔다.
  //  수정: (1) 의도 금액을 인자로 받아 DOM 재조회 대신 그 값으로 계산한다.
  //        (2) DOM 값이 의도와 다르면(=페이지가 되돌린 상태) 즉시 주문을 중단한다.
  //        (3) 수량 주입 결과도 검증한다.
  async function fillQtyFromAmount(expectedAmt) {
    const priceEl = getPriceInput();
    const amtEl   = getAmountInput();
    const qtyEl   = getQtyInput();
    if (!priceEl || !amtEl || !qtyEl) {
      logOrder('수량 계산 중단 — 가격/총액/수량 입력창을 찾지 못함');
      return false;
    }

    const price  = toNum(priceEl.value);
    const domAmt = toNum(amtEl.value);
    logOrder(`수량 계산 진입: 가격="${priceEl.value}"(${price}) / 화면총액="${amtEl.value}"(${domAmt}) / 의도총액=${expectedAmt ?? '(미지정)'}`);

    // 의도 금액이 있는 경우(커스텀 주문)에는 화면을 다시 읽지 않고 검증된 의도 금액으로 계산한다.
    // ★ 이번 사고의 핵심 수정 지점 ★ — 기존 코드는 여기서 DOM을 재조회했고,
    //   그 값이 직전 주문값(500000)이면 그대로 500,000원어치 수량을 계산해 넣어버렸다.
    // 화면 총액이 의도와 달라도 여기서 바로 중단하지는 않는다(빗썸이 총액칸을 자체적으로
    // 재계산/재포맷하는 정상 동작까지 오차단하면 기능이 아예 못 쓰게 되기 때문).
    // 진짜 관문은 제출 직전의 verifyBeforeSubmit(가격×수량 대조)이다.
    let amt;
    if (expectedAmt != null) {
      const want = toNum(expectedAmt);
      if (!approxEqual(want, domAmt, 0.005)) {
        console.warn(`[KT-Bithumb] 주의 — 화면 총액(${domAmt})이 의도 총액(${want})과 다릅니다. 의도값 기준으로 수량을 계산합니다.`);
      }
      amt = want;
    } else {
      amt = domAmt; // 퍼센트 주문은 의도 금액이 없으므로 화면 값을 쓸 수밖에 없다.
    }

    if (!(price > 0) || !(amt > 0)) {
      logOrder(`수량 계산 생략 — 가격(${price}) 또는 총액(${amt})이 유효하지 않음`);
      return expectedAmt == null;   // 퍼센트 주문은 원래 동작 유지, 커스텀 주문은 실패 처리
    }

    const wantQty = amt / price;
    setReactInputValue(qtyEl, String(wantQty));
    await wait(80);
    const gotQty = toNum(getQtyInput()?.value);
    logOrder(`수량 주입: 기대 ${wantQty} → 화면 "${getQtyInput()?.value}"(${gotQty})`);

    if (expectedAmt != null && !approxEqual(wantQty, gotQty, 0.01)) {
      console.warn(`[KT-Bithumb] 수량 주입 실패 — 기대 ${wantQty}, 화면 ${gotQty}. 주문 중단.`);
      showAbortToast(`수량 입력 실패로 주문을 취소했습니다.\n(기대 ${wantQty} / 화면 ${getQtyInput()?.value ?? '없음'})`);
      return false;
    }
    return true;
  }

  // ── Order execute ─────────────────────────────────────────────────────
  async function executeOrder(type, pct) {
    const tabSwitched = await switchToTab(type);
    if (tabSwitched) await wait(100);
    const typeSwitched = await switchOrderType('limit');
    if (typeSwitched) await wait(80);
    const pctBtn = getPctBtn(pct);
    if (pctBtn) { fireClick(pctBtn); await wait(200); }
    // 퍼센트 주문은 "의도 금액"이 없다(빗썸이 잔고 비율로 채워 넣는 값이 곧 의도).
    // 그래서 금액 대조는 못 하고, 대신 실제로 어떤 값으로 나가는지 로그로 남긴다.
    await fillQtyFromAmount(null);
    await wait(80);
    logOrder(`퍼센트 주문 제출 — ${type} ${pct} / 가격="${getPriceInput()?.value}" 수량="${getQtyInput()?.value}" 총액="${getAmountInput()?.value}"`);
    fireClick(getSubmitBtn(type));
    playSound(type === 'buy' ? 'buy' : 'sell');
    if (cfg.autoConfirm) await waitAndClickConfirm();
  }

  async function executeMarketOrder(type, pct) {
    const tabSwitched = await switchToTab(type);
    if (tabSwitched) await wait(80);
    const typeSwitched = await switchOrderType('market');
    if (typeSwitched) await wait(100);
    const pctBtn = getPctBtn(pct);
    if (pctBtn) { fireClick(pctBtn); await wait(200); }
    // 시장가는 금액만으로 주문 가능하므로 수량 계산 불필요
    await wait(80);
    logOrder(`시장가 퍼센트 주문 제출 — ${type} ${pct} / 수량="${getQtyInput()?.value}" 총액="${getAmountInput()?.value}"`);
    fireClick(getSubmitBtn(type));
    playSound(type === 'buy' ? 'buy' : 'sell');
    if (cfg.autoConfirm) await waitAndClickConfirm();
  }

  const toNum = v => parseFloat(String(v ?? '').replace(/,/g, ''));

  function logOrder(msg) {
    try { console.log(`[KT-Bithumb] ${msg}`); } catch (e) {}
  }

  // 상대 오차 비교.
  // 기존 verifyInjected는 Math.abs(want-got) < 1 이라는 **절대** 오차를 썼는데,
  // 이건 소수 수량(예: 0.4개를 넣었는데 화면엔 1.3개)을 전부 "일치"로 통과시켜 버리는
  // 구멍이었다. 금액이든 수량이든 자릿수에 상관없이 안전하도록 상대 오차로 바꾼다.
  function approxEqual(want, got, relTol) {
    if (isNaN(want) || isNaN(got)) return false;
    if (want === 0) return got === 0;
    return Math.abs(want - got) / Math.abs(want) <= relTol;
  }

  // 값 주입이 실패했는데도 주문 버튼을 누르면, 화면에 남아 있던 "직전 주문값"으로
  // 실거래가 나가버린다. 주입값이 실제로 입력창에 반영됐는지 확인하고 아니면 중단한다.
  function verifyInjected(el, expected, label, relTol = 0.005) {
    const want = toNum(expected);
    const got  = toNum(el?.value);
    if (approxEqual(want, got, relTol)) return true;
    console.warn(`[KT-Bithumb] ${label} 주입 실패 — 기대값 ${expected}, 실제 입력창 "${el?.value}". 주문 중단.`);
    showAbortToast(`${label} 입력 실패로 주문을 취소했습니다.\n(기대 ${expected} / 화면 ${el?.value ?? '없음'})`);
    return false;
  }

  // 값을 주입한 뒤 두 시점에서 읽어, 페이지가 값을 되돌리는지까지 관찰한다.
  //   strict=true  → 되돌아가면 주문 중단 (그 칸이 곧 체결 기준인 경우: 시장가 총액, 수량)
  //   strict=false → 되돌아가도 경고만 (지정가 총액칸처럼 빗썸이 스스로 재계산하는 보조 칸)
  // 두 시점 값을 항상 콘솔에 남겨서, 다음 테스트 때 되돌림 여부를 눈으로 확정할 수 있게 한다.
  async function injectAndSettle(getEl, value, label, relTol = 0.005, strict = true) {
    const el = getEl();
    if (!el) {
      showAbortToast(`${label} 입력창을 찾지 못해 주문을 취소했습니다.`);
      return false;
    }
    setReactInputValue(el, value);
    // [2026-08-07 속도개선] 형이 "단축키는 미세한 속도차이가 중요하다"고 지적 —
    // 1차 확인이 이제 strict=false면 차단이 아니라 경고용 로그일 뿐이라, 굳이 100ms씩
    // 길게 기다릴 필요가 없어져서 60/90ms로 줄임(진짜 안전장치는 뒤쪽 verifyBeforeSubmit).
    await wait(60);
    const first = getEl()?.value;
    // [2026-08-07 재수정] strict=false(예: 지정가 총액칸처럼 빗썸이 스스로 재계산/재포맷하는
    // 보조 칸)인데도 이 1차 확인은 strict 여부와 상관없이 무조건 주문을 막고 있었다 —
    // 그 결과 총액칸이 100ms 안에 정확히 그 문자열로 안 보이면(빗썸 쪽 포맷팅/재계산 타이밍
    // 차이만으로도) 정상 금액까지 전부 차단되어 "매수 자체가 아예 안 됨" 사고로 재발했다.
    // strict=false일 때는 여기서도 경고만 하고 통과시킨다 — 실제 체결 기준(가격×수량)은
    // 뒤쪽 verifyBeforeSubmit()이 최종 관문으로 여전히 지키고 있다.
    if (!approxEqual(toNum(value), toNum(getEl()?.value), relTol)) {
      const msg = `[KT-Bithumb] ${label} 1차 확인 불일치 — 기대 ${value}, 화면 "${getEl()?.value}".`;
      if (strict) {
        console.warn(msg + ' 주문 중단.');
        showAbortToast(`${label} 입력 실패로 주문을 취소했습니다.\n(기대 ${value} / 화면 ${getEl()?.value ?? '없음'})`);
        return false;
      }
      console.warn(msg + ' strict=false라 통과(최종 관문에서 다시 확인).');
    }
    await wait(90);                        // 되돌림(debounce/재렌더) 감지용 2차 확인
    const second = getEl()?.value;
    logOrder(`${label} 주입: 요청=${value} / 60ms후="${first}" / 150ms후="${second}" / strict=${strict}`);
    if (!approxEqual(toNum(value), toNum(second), relTol)) {
      console.warn(`[KT-Bithumb] ${label}이 페이지에 의해 되돌아감 — 요청 ${value}, 100ms "${first}", 250ms "${second}".`);
      if (strict) {
        showAbortToast(`${label}이 화면에서 되돌아가 주문을 취소했습니다.\n(요청 ${value} / 화면 ${second})`);
        return false;
      }
    }
    return true;
  }

  // ── 제출 직전 최종 관문 ────────────────────────────────────────────────
  // 2026-08-07 사고(5,100원 의도 → 500,000원 주문)를 실제로 막아줬어야 할 검사.
  // 주문 버튼을 누르기 바로 직전에 화면 값만으로 "실제로 나갈 금액"을 다시 계산해서
  // 의도한 금액과 2% 넘게 다르면 클릭 자체를 하지 않는다. 확실하지 않으면 무조건 중단(fail-closed).
  function verifyBeforeSubmit(intent) {
    const priceStr = getPriceInput()?.value;
    const qtyStr   = getQtyInput()?.value;
    const amtStr   = getAmountInput()?.value;
    const price = toNum(priceStr), qty = toNum(qtyStr), amt = toNum(amtStr);
    logOrder(`제출 직전 화면 상태 → 가격="${priceStr}" 수량="${qtyStr}" 총액="${amtStr}" / 의도=${JSON.stringify(intent)}`);

    if (intent?.amount != null) {
      const want = toNum(intent.amount);
      // "실제로 체결되는 기준"만 관문으로 삼는다.
      //  · 지정가: 가격 × 수량이 곧 주문 금액이다. 총액칸은 빗썸이 스스로 재계산하는
      //           보조 표시라서 관문에 넣으면 정상 주문까지 오차단된다(참고용 로그만).
      //  · 시장가: 총액칸 자체가 주문 금액이다.
      const checks = [];
      if (intent.mode === 'limit') {
        checks.push(['가격×수량', (price > 0 && qty > 0) ? price * qty : NaN]);
        if (!approxEqual(want, amt, 0.02)) {
          console.warn(`[KT-Bithumb] 참고 — 화면 총액칸(${amt})이 설정 금액(${want})과 다릅니다. 체결 기준인 가격×수량으로 판정합니다.`);
        }
      } else {
        checks.push(['총액칸', amt]);
      }
      for (const [label, val] of checks) {
        if (isNaN(val)) {
          console.warn(`[KT-Bithumb] 제출 중단 — ${label}을 읽지 못했습니다.`);
          showAbortToast(`주문 금액을 확인하지 못해 주문을 취소했습니다. (${label} 확인 불가)`);
          return false;
        }
        if (!approxEqual(want, val, 0.02)) {
          console.warn(`[KT-Bithumb] 제출 중단 — ${label}=${val}, 의도=${want}. 배율 ${(val / want).toFixed(2)}배.`);
          showAbortToast(`주문 금액이 설정과 달라 주문을 취소했습니다.\n설정 ${want.toLocaleString('ko-KR')}원 / 실제 ${Math.round(val).toLocaleString('ko-KR')}원`);
          return false;
        }
      }
    }

    if (intent?.qty != null) {
      const want = toNum(intent.qty);
      if (!approxEqual(want, qty, 0.01)) {
        console.warn(`[KT-Bithumb] 제출 중단 — 수량 ${qty}, 의도 ${want}.`);
        showAbortToast(`주문 수량이 설정과 달라 주문을 취소했습니다.\n(설정 ${want} / 화면 ${qtyStr})`);
        return false;
      }
    }
    return true;
  }

  function showAbortToast(msg) {
    try {
      const t = document.createElement('div');
      t.style.cssText = 'position:fixed;top:24px;left:50%;transform:translateX(-50%);z-index:2147483647;'
        + 'background:#1a1d27;color:#fff;border:1px solid #e8455a;border-radius:10px;padding:14px 20px;'
        + 'font-size:14px;font-weight:600;white-space:pre-line;text-align:center;box-shadow:0 4px 24px rgba(0,0,0,.6);';
      t.textContent = '⚠️ ' + msg;
      document.body.appendChild(t);
      setTimeout(() => t.remove(), 6000);
    } catch (e) {}
  }

  async function executeCustomOrder(type, orderType, sc) {
    const tabSwitched = await switchToTab(type);
    if (tabSwitched) await wait(80);
    const typeSwitched = await switchOrderType(orderType);
    if (typeSwitched) await wait(100);

    console.log(`[KT-Bithumb] 커스텀 주문 실행: ${type}/${orderType} 총액=${sc.price || '-'} 수량=${sc.qty || '-'}`);

    const intent = { mode: orderType };

    if (sc.price) {
      // 지정가에서는 총액칸이 보조 표시라 되돌아가도 경고만(strict=false),
      // 시장가에서는 총액칸이 곧 주문 금액이라 되돌아가면 중단(strict=true).
      if (!await injectAndSettle(getAmountInput, sc.price, '총액', 0.005, orderType !== 'limit')) return;
      intent.amount = sc.price;
      // 지정가는 수량으로 체결되므로 총액만 맞아서는 안 되고 수량까지 직접 넣어야 한다.
      // 이때 절대로 화면 총액을 다시 읽지 않고, 검증된 의도 금액(sc.price)으로 계산한다.
      if (orderType === 'limit') {
        if (!await fillQtyFromAmount(sc.price)) return;
      }
    } else if (sc.qty) {
      if (!await injectAndSettle(getQtyInput, sc.qty, '수량', 0.01)) return;
      intent.qty = sc.qty;
    }

    await wait(60);
    // 최종 관문 — 여기서 걸리면 주문 버튼을 아예 누르지 않는다.
    if (!verifyBeforeSubmit(intent)) return;

    logOrder(`주문 제출 실행 — ${type}/${orderType} 의도=${JSON.stringify(intent)}`);
    fireClick(getSubmitBtn(type));
    playSound(type === 'buy' ? 'buy' : 'sell');
    if (cfg.autoConfirm) await waitAndClickConfirm();
  }

  function isVisible(el) {
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  // 폴링(50ms 간격) 대신 MutationObserver로 확인 버튼이 나타나는 즉시 반응
  async function waitAndClickConfirm() {
    const match = b => {
      const t = b.innerText.replace(/\s+/g, ' ').trim();
      return t.includes('매수 확인') || t.includes('매도 확인') || t === '주문 확인' || t === '확인';
    };
    const find = () => [...document.querySelectorAll('button')].find(match);
    const existing = find();
    if (existing) { dispatchToMain('__bt_click_confirm'); return; }
    await new Promise(resolve => {
      const observer = new MutationObserver(() => {
        if (find()) {
          observer.disconnect();
          clearTimeout(timer);
          dispatchToMain('__bt_click_confirm');
          resolve();
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
      const timer = setTimeout(() => { observer.disconnect(); resolve(); }, 5000);
    });
  }

  // ── Cancel order ──────────────────────────────────────────────────────
  async function cancelOrder(all) {
    // 미체결 주문 탭으로 이동 (텍스트 기반)
    const histTab = [...document.querySelectorAll('button')]
      .find(b => b.innerText.trim() === '미체결 주문' && isVisible(b));
    if (histTab) { fireClick(histTab); await wait(350); }

    if (all) {
      const cancelBtn = [...document.querySelectorAll('button')]
        .find(b => b.innerText.trim() === '주문 취소' && isVisible(b));
      if (!cancelBtn) return;
      fireClick(cancelBtn);
      await waitAndClickCancelConfirm(3000);
      playSound('cancel');
    } else {
      // 개별 행 취소 버튼 ("취소") 탐색
      let rowBtn = null;
      const deadline = Date.now() + 1500;
      while (Date.now() < deadline) {
        rowBtn = [...document.querySelectorAll('button')]
          .find(b => b.innerText.trim() === '취소' && isVisible(b));
        if (rowBtn) break;
        await wait(30);
      }
      if (!rowBtn) return;
      fireClick(rowBtn);
      await wait(400);
      await waitAndClickByText('취소', 2000);
      playSound('cancel');
    }
  }

  async function waitAndClickByText(text, timeout = 2000) {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      const el = [...document.querySelectorAll('button, a')]
        .find(b => b.innerText.trim() === text);
      if (el) { el.click(); return true; }
      await wait(30);
    }
    return false;
  }

  // 취소 확인 다이얼로그: "아니오" 버튼이 보이면 다이얼로그가 열린 것 → "취소" 클릭
  async function waitAndClickCancelConfirm(timeout = 3000) {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      const noBtn = [...document.querySelectorAll('button')].find(b => b.innerText.trim() === '아니오');
      if (noBtn) {
        // "아니오"와 같은 부모 안의 "취소" 버튼 클릭
        const parent = noBtn.closest('[class*="Modal"], [class*="modal"], [class*="Dialog"], [class*="dialog"], [class*="Confirm"], [class*="confirm"], [class*="Popup"], [class*="popup"]') || noBtn.parentElement?.parentElement;
        const cancelBtn = parent
          ? [...parent.querySelectorAll('button')].find(b => b.innerText.trim() === '취소')
          : null;
        if (cancelBtn || [...document.querySelectorAll('button')].find(b => b.innerText.trim() === '취소')) {
          dispatchToMain('__bt_click_cancel_confirm'); return true;
        }
      }
      await wait(30);
    }
    return false;
  }

  // ── Modal ─────────────────────────────────────────────────────────────
  function closeModal() {
    document.getElementById('bt-modal-overlay')?.remove();
  }

  function showModal(type, orderType) {
    closeModal();
    const coin = getCurrentCoin();
    const isBuy = type === 'buy';
    const colorClass = isBuy ? 'buy' : 'sell';

    const overlay = document.createElement('div');
    overlay.id = 'bt-modal-overlay';
    overlay.innerHTML = `
      <div id="bt-modal-box">
        <div class="bt-modal-title">${coin ? coin + ' ' : ''}${isBuy ? '매수' : '매도'} 주문</div>
        <div class="bt-modal-type">${orderType === 'market' ? '시장가' : '지정가'}</div>
        <div class="bt-pct-row">
          <button class="bt-pct-btn ${colorClass}" data-pct="10%">10%</button>
          <button class="bt-pct-btn ${colorClass}" data-pct="25%">25%</button>
          <button class="bt-pct-btn ${colorClass}" data-pct="50%">50%</button>
          <button class="bt-pct-btn ${colorClass}" data-pct="75%">75%</button>
          <button class="bt-pct-btn ${colorClass}" data-pct="최대">최대</button>
        </div>
        <button class="bt-cancel-btn">취소 (ESC)</button>
      </div>
    `;

    overlay.querySelector('.bt-cancel-btn').addEventListener('click', closeModal);
    overlay.addEventListener('click', e => { if (e.target === overlay) closeModal(); });

    overlay.querySelectorAll('.bt-pct-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        const pct = btn.dataset.pct;
        closeModal();
        if (orderType === 'market') await executeMarketOrder(type, pct);
        else await executeOrder(type, pct);
      });
    });

    document.body.appendChild(overlay);
  }

  // ── Shortcut matching ─────────────────────────────────────────────────
  function matchShortcut(e, sc) {
    if (!sc.key || !sc.command) return false;
    const mods = sc.modifier ? sc.modifier.split('+') : [];
    return sc.key.toLowerCase() === e.key.toLowerCase()
      && mods.includes('shift') === !!e.shiftKey
      && mods.includes('ctrl')  === !!e.ctrlKey
      && mods.includes('alt')   === !!e.altKey
      && !e.metaKey;
  }

  async function executeCommand(sc) {
    switch (sc.command) {
      case 'BUY':                showModal('buy',  'limit');  break;
      case 'SELL':               showModal('sell', 'limit');  break;
      case 'MARKET_BUY':         showModal('buy',  'market'); break;
      case 'MARKET_SELL':        showModal('sell', 'market'); break;
      case 'BUY_10':             await executeOrder('buy',  '10%'); break;
      case 'BUY_25':             await executeOrder('buy',  '25%'); break;
      case 'BUY_50':             await executeOrder('buy',  '50%'); break;
      case 'BUY_75':             await executeOrder('buy',  '75%'); break;
      case 'BUY_MAX':            await executeOrder('buy',  '최대'); break;
      case 'SELL_10':            await executeOrder('sell', '10%'); break;
      case 'SELL_25':            await executeOrder('sell', '25%'); break;
      case 'SELL_50':            await executeOrder('sell', '50%'); break;
      case 'SELL_75':            await executeOrder('sell', '75%'); break;
      case 'SELL_MAX':           await executeOrder('sell', '최대'); break;
      case 'MARKET_BUY_10':      await executeMarketOrder('buy',  '10%'); break;
      case 'MARKET_BUY_25':      await executeMarketOrder('buy',  '25%'); break;
      case 'MARKET_BUY_50':      await executeMarketOrder('buy',  '50%'); break;
      case 'MARKET_BUY_75':      await executeMarketOrder('buy',  '75%'); break;
      case 'MARKET_BUY_MAX':     await executeMarketOrder('buy',  '최대'); break;
      case 'MARKET_SELL_10':     await executeMarketOrder('sell', '10%'); break;
      case 'MARKET_SELL_25':     await executeMarketOrder('sell', '25%'); break;
      case 'MARKET_SELL_50':     await executeMarketOrder('sell', '50%'); break;
      case 'MARKET_SELL_75':     await executeMarketOrder('sell', '75%'); break;
      case 'MARKET_SELL_MAX':    await executeMarketOrder('sell', '최대'); break;
      case 'CUSTOM_LIMIT_BUY':   await executeCustomOrder('buy',  'limit',  sc); break;
      case 'CUSTOM_LIMIT_SELL':  await executeCustomOrder('sell', 'limit',  sc); break;
      case 'CUSTOM_MARKET_BUY':  await executeCustomOrder('buy',  'market', sc); break;
      case 'CUSTOM_MARKET_SELL': await executeCustomOrder('sell', 'market', sc); break;
      case 'CANCEL_1':           await cancelOrder(false); break;
      case 'CANCEL_ALL':         await cancelOrder(true);  break;
    }
  }

  // ── Key handler ───────────────────────────────────────────────────────
  document.addEventListener('keydown', async e => {
    if (!isOnTradePage()) return;

    if (e.key === 'Escape') { closeModal(); return; }

    if (!e.metaKey && !e.ctrlKey && !e.altKey) {
      const tag = e.target?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
    }

    if (document.getElementById('bt-modal-overlay')) {
      const keyMap = { '1': '10%', '2': '25%', '3': '50%', '4': '75%', '5': '최대' };
      if (keyMap[e.key]) {
        document.querySelector(`.bt-pct-btn[data-pct="${keyMap[e.key]}"]`)?.click();
        return;
      }
    }

    for (const sc of cfg.shortcuts) {
      if (matchShortcut(e, sc)) {
        e.preventDefault();
        await executeCommand(sc);
        return;
      }
    }

    if (!document.getElementById('bt-modal-overlay')
        && ['1','2','3','4','5','6','7'].includes(e.key)
        && !e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey) {
      e.preventDefault();
      navTab(e.key);
    }
  }, true);

})();
