(function () {
  'use strict';

  if (window.__btInit) return;
  window.__btInit = true;

  const STORAGE_KEY = 'bithumb_shortcut_v1';

  const SOUND_DEFS = {
    buy: {
      sound1: [{ f:523,d:.08 },{ f:659,d:.08 },{ f:784,d:.15 }],
      sound2: [{ f:880,d:.05 },{ f:1047,d:.18,g:.25 }],
      sound3: [{ f:440,d:.06 },{ f:523,d:.06 },{ f:659,d:.06 },{ f:784,d:.12 }],
    },
    sell: {
      sound1: [{ f:784,d:.08 },{ f:659,d:.08 },{ f:523,d:.15 }],
      sound2: [{ f:1047,d:.05 },{ f:880,d:.18,g:.25 }],
      sound3: [{ f:523,d:.06 },{ f:440,d:.06 },{ f:349,d:.12 }],
    },
    cancel: {
      sound1: [{ f:220,d:.25,t:'sawtooth',g:.2 }],
      sound2: [{ f:330,d:.1 },{ f:220,d:.15,g:.2 }],
      sound3: [{ f:440,d:.05 },{ f:330,d:.05 },{ f:220,d:.08 },{ f:165,d:.12,g:.15 }],
    },
  };

  const WAV_SOUNDS = new Set(['ddukbaegi','ding3','donggeon','fanfare','levelup','tada','victory','minus']);

  function playSound(type) {
    const snd = cfg.sound;
    if (!snd?.enabled) return;
    const vol = (snd.volume ?? 50) / 100;
    const sel = snd[type] || 'sound1';
    if (sel === 'custom') {
      const dataUrl = snd[`${type}Custom`];
      if (dataUrl) { const a = new Audio(dataUrl); a.volume = vol; a.play().catch(() => {}); }
      return;
    }
    if (WAV_SOUNDS.has(sel)) {
      fetch(chrome.runtime.getURL(`sounds/${sel}.wav`)).then(r=>r.blob()).then(blob=>{const u=URL.createObjectURL(blob);const a=new Audio(u);a.volume=vol;a.play().catch(()=>{});a.addEventListener('ended',()=>URL.revokeObjectURL(u));}).catch(()=>{});
      return;
    }
    const notes = SOUND_DEFS[type]?.[sel];
    if (!notes) return;
    try {
      const ctx = new AudioContext();
      let t = ctx.currentTime + 0.01;
      notes.forEach(({ f, d, g = 0.3, t: wt = 'sine' }) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain); gain.connect(ctx.destination);
        osc.type = wt; osc.frequency.setValueAtTime(f, t);
        gain.gain.setValueAtTime(g * vol, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + d);
        osc.start(t); osc.stop(t + d + 0.02);
        t += d * 0.75;
      });
      setTimeout(() => ctx.close(), 2000);
    } catch(e) {}
  }

  const DEFAULT_SHORTCUTS = [
    { modifier: '',      key: 'a', command: 'CANCEL_1',   fixed: false },
    { modifier: 'shift', key: 's', command: 'CANCEL_ALL', fixed: false },
  ];

  const cfg = {
    autoConfirm: true,
    sound: { enabled: false, volume: 50, buy: 'sound1', sell: 'sound1', cancel: 'sound1' },
    shortcuts: DEFAULT_SHORTCUTS.map(s => ({ ...s })),
  };

  function syncAutoConfirmAttr() {
    document.documentElement.dataset.btAutoconfirm = cfg.autoConfirm ? '1' : '0';
  }

  function loadSettings() {
    chrome.storage.local.get(STORAGE_KEY, d => {
      const saved = d[STORAGE_KEY];
      if (saved) {
        cfg.autoConfirm = saved.autoConfirm !== false;
        if (saved.sound) cfg.sound = { ...cfg.sound, ...saved.sound };
        if (Array.isArray(saved.shortcuts)) cfg.shortcuts = saved.shortcuts;
      }
      syncAutoConfirmAttr();
    });
  }

  chrome.storage.onChanged.addListener(changes => {
    if (changes[STORAGE_KEY]) loadSettings();
  });

  loadSettings();

  // ── Helpers ───────────────────────────────────────────────────────────
  const wait = ms => new Promise(r => setTimeout(r, ms));

  function isOnTradePage() {
    return location.pathname.startsWith('/react/trade/order/');
  }

  function getCurrentCoin() {
    const m = location.pathname.match(/\/order\/([A-Z]+)-/);
    return m ? m[1] : '';
  }

  // ── Selectors ─────────────────────────────────────────────────────────
  function getBuyTabBtn()  { return [...document.querySelectorAll('.Orders_orders-tab__button__bSVbC')].find(b => b.innerText.includes('매수')); }
  function getSellTabBtn() { return [...document.querySelectorAll('.Orders_orders-tab__button__bSVbC')].find(b => b.innerText.includes('매도')); }

  function getCurrentTab() {
    // aria-selected 우선 (isOrderTypeActive와 동일한 방식)
    if (getBuyTabBtn()?.getAttribute('aria-selected') === 'true') return 'buy';
    if (getSellTabBtn()?.getAttribute('aria-selected') === 'true') return 'sell';
    // fallback: 제출 버튼 가시성
    const buyBtn = document.querySelector('[class*="button-row__buy"]');
    const r = buyBtn?.getBoundingClientRect();
    return (r && r.width > 0 && r.height > 0) ? 'buy' : 'sell';
  }

  function getOrderTypeBtn(type) {
    const label = type === 'limit' ? '지정' : '시장';
    return [...document.querySelectorAll('.BuySellTab_primaryTab-wrap__action__ZJiLc')]
      .find(b => b.innerText.trim() === label);
  }

  function isOrderTypeActive(type) {
    return getOrderTypeBtn(type)?.getAttribute('aria-selected') === 'true';
  }

  function getPctBtn(pct) {
    return [...document.querySelectorAll('.OrderForm_order-form-qty-per__button__MYSqC')]
      .find(b => b.innerText.trim() === pct);
  }

  function getSubmitBtn(type) {
    const keyword = type === 'buy' ? 'buy' : 'sell';
    return document.querySelector(`[class*="button-row__${keyword}"]`);
  }

  function getPriceInput()  { return document.querySelector('[data-testid="price-row-input"]'); }
  function getQtyInput()    { return document.querySelector('[data-testid="qty-row-input"]'); }
  function getAmountInput() { return document.querySelector('[data-testid="amount-row-input"]'); }

  function setReactInputValue(el, value) {
    try {
      const desc = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
      desc.set.call(el, String(value));
      el.dispatchEvent(new Event('input',  { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    } catch(e) {}
  }

  function fireClick(el) {
    if (!el) return;
    el.dispatchEvent(new PointerEvent('click', { bubbles: true, cancelable: true, detail: 1 }));
  }

  // postMessage로 MAIN world에 전달 (CustomEvent는 isolated→main 경계 통과 안 됨)
  function dispatchToMain(type) {
    window.postMessage({ __bt: true, type }, '*');
  }

  // ── Tab key labels (data-bt-key + CSS ::after, innerText 불변) ─────────
  const TAB_KEY_MAP = [
    { key: '1', match: b => b.className.includes('orders-tab__button') && b.innerText.includes('매수') },
    { key: '2', match: b => b.className.includes('orders-tab__button') && b.innerText.includes('매도') },
    { key: '3', match: b => b.innerText.trim() === '미체결 주문' },
    { key: '4', match: b => b.innerText.trim() === '체결 주문' },
    { key: '5', match: b => b.innerText.trim() === '원화' },
    { key: '6', match: b => b.innerText.trim() === '보유' },
    { key: '7', match: b => b.innerText.trim() === '관심' },
  ];

  function injectTabLabels() {
    if (!isOnTradePage()) return;
    TAB_KEY_MAP.forEach(({ key, match }) => {
      if (document.querySelector(`button[data-bt-key="${key}"]`)) return;
      const btn = [...document.querySelectorAll('button')].find(b => match(b) && isVisible(b));
      if (btn) btn.dataset.btKey = key;
    });
  }

  let _labelTimer = null;
  new MutationObserver(() => {
    clearTimeout(_labelTimer);
    _labelTimer = setTimeout(injectTabLabels, 400);
  }).observe(document.body, { childList: true, subtree: true });

  // ── Tab navigation (keys 1–7 when modal is closed) ───────────────────
  function navTab(key) {
    const textMap = { '3': '미체결 주문', '4': '체결 주문', '5': '원화', '6': '보유', '7': '관심' };
    if (key === '1') { if (getCurrentTab() !== 'buy')  { const b = getBuyTabBtn();  if (b) fireClick(b); } return; }
    if (key === '2') { if (getCurrentTab() !== 'sell') { const b = getSellTabBtn(); if (b) fireClick(b); } return; }
    const text = textMap[key];
    if (text) {
      const b = [...document.querySelectorAll('button')].find(b => b.innerText.trim() === text && isVisible(b));
      if (b) fireClick(b);
    }
  }

  // ── Tab / order type switching ────────────────────────────────────────
  async function switchToTab(type) {
    if (getCurrentTab() === type) return;
    const btn = type === 'buy' ? getBuyTabBtn() : getSellTabBtn();
    if (btn) { fireClick(btn); await wait(120); }
  }

  async function switchOrderType(type) {
    if (isOrderTypeActive(type)) return;
    const btn = getOrderTypeBtn(type);
    if (btn) { fireClick(btn); await wait(100); }
  }

  // ── 금액/가격으로 수량 계산 후 주입 ─────────────────────────────────────
  async function fillQtyFromAmount() {
    const priceEl  = getPriceInput();
    const amtEl    = getAmountInput();
    const qtyEl    = getQtyInput();
    if (!priceEl || !amtEl || !qtyEl) return;

    const price = parseFloat((priceEl.value || '').replace(/,/g, ''));
    const amt   = parseFloat((amtEl.value  || '').replace(/,/g, ''));
    if (price > 0 && amt > 0) {
      setReactInputValue(qtyEl, String(amt / price));
      await wait(80);
    }
  }

  // ── Order execute ─────────────────────────────────────────────────────
  async function executeOrder(type, pct) {
    await switchToTab(type);
    await wait(100);
    await switchOrderType('limit');
    await wait(80);
    const pctBtn = getPctBtn(pct);
    if (pctBtn) { fireClick(pctBtn); await wait(200); }
    await fillQtyFromAmount();
    await wait(80);
    fireClick(getSubmitBtn(type));
    playSound(type === 'buy' ? 'buy' : 'sell');
    if (cfg.autoConfirm) await waitAndClickConfirm();
  }

  async function executeMarketOrder(type, pct) {
    await switchToTab(type);
    await wait(80);
    await switchOrderType('market');
    await wait(100);
    const pctBtn = getPctBtn(pct);
    if (pctBtn) { fireClick(pctBtn); await wait(200); }
    // 시장가는 금액만으로 주문 가능하므로 수량 계산 불필요
    await wait(80);
    fireClick(getSubmitBtn(type));
    playSound(type === 'buy' ? 'buy' : 'sell');
    if (cfg.autoConfirm) await waitAndClickConfirm();
  }

  async function executeCustomOrder(type, orderType, sc) {
    await switchToTab(type);
    await wait(80);
    await switchOrderType(orderType);
    await wait(100);

    if (sc.price) {
      const amtEl = getAmountInput();
      if (amtEl) { setReactInputValue(amtEl, sc.price); await wait(100); }
      if (orderType === 'limit') await fillQtyFromAmount();
    } else if (sc.qty) {
      const qtyEl = getQtyInput();
      if (qtyEl) { setReactInputValue(qtyEl, sc.qty); await wait(80); }
    }

    await wait(100);
    fireClick(getSubmitBtn(type));
    playSound(type === 'buy' ? 'buy' : 'sell');
    if (cfg.autoConfirm) await waitAndClickConfirm();
  }

  function isVisible(el) {
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  async function waitAndClickConfirm() {
    const d1 = Date.now() + 5000;
    while (Date.now() < d1) {
      const btn = [...document.querySelectorAll('button')].find(b => {
        const t = b.innerText.replace(/\s+/g, ' ').trim();
        return t.includes('매수 확인') || t.includes('매도 확인') || t === '주문 확인' || t === '확인';
      });
      if (btn) { dispatchToMain('__bt_click_confirm'); break; }
      await wait(50);
    }
  }

  // ── Cancel order ──────────────────────────────────────────────────────
  async function cancelOrder(all) {
    // 미체결 주문 탭으로 이동 (텍스트 기반)
    const histTab = [...document.querySelectorAll('button')]
      .find(b => b.innerText.trim() === '미체결 주문' && isVisible(b));
    if (histTab) { fireClick(histTab); await wait(350); }

    if (all) {
      const cancelBtn = [...document.querySelectorAll('button')]
        .find(b => b.innerText.trim() === '주문 취소' && isVisible(b));
      if (!cancelBtn) return;
      fireClick(cancelBtn);
      await waitAndClickCancelConfirm(3000);
      playSound('cancel');
    } else {
      // 개별 행 취소 버튼 ("취소") 탐색
      let rowBtn = null;
      const deadline = Date.now() + 1500;
      while (Date.now() < deadline) {
        rowBtn = [...document.querySelectorAll('button')]
          .find(b => b.innerText.trim() === '취소' && isVisible(b));
        if (rowBtn) break;
        await wait(30);
      }
      if (!rowBtn) return;
      fireClick(rowBtn);
      await wait(400);
      await waitAndClickByText('취소', 2000);
      playSound('cancel');
    }
  }

  async function waitAndClickByText(text, timeout = 2000) {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      const el = [...document.querySelectorAll('button, a')]
        .find(b => b.innerText.trim() === text);
      if (el) { el.click(); return true; }
      await wait(30);
    }
    return false;
  }

  // 취소 확인 다이얼로그: "아니오" 버튼이 보이면 다이얼로그가 열린 것 → "취소" 클릭
  async function waitAndClickCancelConfirm(timeout = 3000) {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      const noBtn = [...document.querySelectorAll('button')].find(b => b.innerText.trim() === '아니오');
      if (noBtn) {
        // "아니오"와 같은 부모 안의 "취소" 버튼 클릭
        const parent = noBtn.closest('[class*="Modal"], [class*="modal"], [class*="Dialog"], [class*="dialog"], [class*="Confirm"], [class*="confirm"], [class*="Popup"], [class*="popup"]') || noBtn.parentElement?.parentElement;
        const cancelBtn = parent
          ? [...parent.querySelectorAll('button')].find(b => b.innerText.trim() === '취소')
          : null;
        if (cancelBtn || [...document.querySelectorAll('button')].find(b => b.innerText.trim() === '취소')) {
          dispatchToMain('__bt_click_cancel_confirm'); return true;
        }
      }
      await wait(30);
    }
    return false;
  }

  // ── Bithumb Layout Toggle ─────────────────────────────────────────────
  const BT_OB_W = 280;   // 호가창 폭
  const BT_COL_W = 380;  // 주문폼·체결내역 열 폭
  const BT_SECTION_W = BT_OB_W + BT_COL_W; // 660

  let _btLayoutOn = false;
  let _btResizeHandler = null;
  let _btApplying = false;
  const _btOrig = {};

  function _btSaveStyle(key, el) {
    if (el && !(key in _btOrig)) _btOrig[key] = el.getAttribute('style') || '';
  }

  function applyBtLayout() {
    if (_btApplying) return;
    _btApplying = true;

    const availH = window.innerHeight - 120;

    // 뉴스/공지 숨기기
    ['[class*="Notice"]','[class*="notice"]','[class*="News"]','[class*="news"]',
     '[class*="Ticker"]','[class*="ticker"]','[class*="Banner"]','[class*="banner"]',
    ].forEach(sel => {
      document.querySelectorAll(sel).forEach(el => {
        const cls = el.className || '';
        const ignore = ['Chart','OrderBook','Orders','Info','Trade_trade','History','CoinList'];
        if (!ignore.some(k => cls.includes(k))) el.style.cssText = 'display:none !important';
      });
    });

    // content: flex-row 전체 폭
    const content = document.querySelector('[class*="Trade_trade__content"]');
    if (content) {
      _btSaveStyle('content', content);
      content.style.cssText = [
        'display:flex !important','flex-direction:row !important',
        'gap:0 !important','padding:0 !important','margin:0 !important',
        'width:100vw !important','max-width:none !important',
        'height:' + availH + 'px !important',
        'overflow:hidden !important','box-sizing:border-box !important',
      ].join(';');
    }

    // aside: 원래 폭 고정
    const aside = document.querySelector('[class*="Trade_trade__aside"]');
    const asideW = aside ? Math.round(aside.getBoundingClientRect().width) : 360;
    if (aside) {
      _btSaveStyle('aside', aside);
      aside.style.cssText = [
        'flex-shrink:0 !important','width:' + asideW + 'px !important',
        'height:' + availH + 'px !important','overflow-y:auto !important',
        'margin:0 !important','padding:0 !important',
      ].join(';');
    }

    // TradeHeader, TradeAsset 숨기기
    ['[class*="TradeHeader_trade-header"]','[class*="TradeAsset_trade-asset"]'].forEach((sel, i) => {
      const el = document.querySelector(sel);
      if (el) { _btSaveStyle('hdr' + i, el); el.style.cssText = 'display:none !important'; }
    });

    const chartW = window.innerWidth - asideW - BT_SECTION_W;

    // main: flex-row
    const main = document.querySelector('[class*="Trade_trade__main"]');
    if (main) {
      _btSaveStyle('main', main);
      main.style.cssText = [
        'display:flex !important','flex-direction:row !important',
        'align-items:stretch !important','gap:0 !important',
        'padding:0 !important','margin:0 !important',
        'width:' + (chartW + BT_SECTION_W) + 'px !important',
        'height:' + availH + 'px !important','overflow:hidden !important',
      ].join(';');
    }

    // 차트: 계산된 폭, 전체 높이
    const chart = document.querySelector('[class*="Chart_chart"]');
    if (chart) {
      _btSaveStyle('chart', chart);
      chart.style.cssText = [
        'width:' + chartW + 'px !important','min-width:' + chartW + 'px !important',
        'flex-shrink:0 !important','height:' + availH + 'px !important',
        'margin:0 !important','padding:0 !important','overflow:hidden !important',
      ].join(';');
    }
    const coinChart = document.querySelector('#coin-chart');
    if (coinChart) {
      _btSaveStyle('coinChart', coinChart);
      coinChart.style.cssText = 'width:100% !important; height:100% !important';
    }

    // section: CSS Grid (호가창 col1 full | 주문폼 col2 top auto | 체결내역 col2 bottom 1fr)
    const section = document.querySelector('[class*="Trade_trade__section"]');
    if (section) {
      _btSaveStyle('section', section);
      section.style.cssText = [
        'display:grid !important',
        'grid-template-columns:' + BT_OB_W + 'px ' + BT_COL_W + 'px !important',
        'grid-template-rows:auto 1fr !important',
        'gap:0 !important',
        'width:' + BT_SECTION_W + 'px !important','min-width:' + BT_SECTION_W + 'px !important',
        'flex-shrink:0 !important','height:' + availH + 'px !important',
        'margin:0 !important','padding:0 !important','overflow:hidden !important',
      ].join(';');
    }

    // 호가창: 왼쪽 열 전체 높이
    const orderBook = document.querySelector('[class*="OrderBook_order-book__"]');
    if (orderBook) {
      _btSaveStyle('orderBook', orderBook);
      orderBook.style.cssText = [
        'grid-column:1 !important','grid-row:1 / 3 !important',
        'width:' + BT_OB_W + 'px !important','height:' + availH + 'px !important',
        'margin:0 !important','overflow:hidden !important',
      ].join(';');
    }

    // 주문폼: 오른쪽 상단, auto 높이
    const orders = document.querySelector('[class*="Orders_orders"]');
    if (orders) {
      _btSaveStyle('orders', orders);
      orders.style.cssText = [
        'grid-column:2 !important','grid-row:1 !important',
        'width:' + BT_COL_W + 'px !important',
        'min-height:380px !important','height:auto !important',
        'overflow-y:visible !important','margin:0 !important','flex-shrink:0 !important',
      ].join(';');
    }

    // 체결내역: 오른쪽 하단, 나머지 전부
    const info = document.querySelector('[class*="Info_info__l"]');
    if (info) {
      _btSaveStyle('info', info);
      info.style.cssText = [
        'grid-column:2 !important','grid-row:2 !important',
        'width:' + BT_COL_W + 'px !important','height:100% !important',
        'margin:0 !important','overflow:hidden !important',
      ].join(';');
      const infoHead = info.querySelector('[class*="info-head"]');
      if (infoHead) { _btSaveStyle('infoHead', infoHead); infoHead.style.cssText = 'display:none !important'; }
      const infoTop = info.querySelector('[class*="info-content-top"]');
      if (infoTop) { _btSaveStyle('infoTop', infoTop); infoTop.style.cssText = 'display:none !important'; }
      info.querySelectorAll('svg').forEach((s, idx) => {
        _btSaveStyle('svg' + idx, s); s.style.cssText = 'display:none !important';
      });
    }

    // 주문내역(하단 이력) 숨기기
    const history = document.querySelector('[class*="History_trade-history"]');
    if (history) { _btSaveStyle('history', history); history.style.cssText = 'display:none !important'; }

    setTimeout(() => {
      _btApplying = false;
      window.dispatchEvent(new Event('resize'));
    }, 50);
  }

  function restoreBtLayout() {
    const restoreEl = (sel, key) => {
      const el = document.querySelector(sel);
      if (el && key in _btOrig) el.setAttribute('style', _btOrig[key]);
    };
    restoreEl('[class*="Trade_trade__content"]', 'content');
    restoreEl('[class*="Trade_trade__aside"]', 'aside');
    restoreEl('[class*="Trade_trade__main"]', 'main');
    restoreEl('[class*="Chart_chart"]', 'chart');
    restoreEl('#coin-chart', 'coinChart');
    restoreEl('[class*="Trade_trade__section"]', 'section');
    restoreEl('[class*="OrderBook_order-book__"]', 'orderBook');
    restoreEl('[class*="Orders_orders"]', 'orders');
    restoreEl('[class*="History_trade-history"]', 'history');
    ['[class*="TradeHeader_trade-header"]','[class*="TradeAsset_trade-asset"]'].forEach((sel, i) => {
      const el = document.querySelector(sel);
      if (el && ('hdr' + i) in _btOrig) el.setAttribute('style', _btOrig['hdr' + i]);
    });
    const info = document.querySelector('[class*="Info_info__l"]');
    if (info) {
      if ('info' in _btOrig) info.setAttribute('style', _btOrig.info);
      const infoHead = info.querySelector('[class*="info-head"]');
      if (infoHead && 'infoHead' in _btOrig) infoHead.setAttribute('style', _btOrig.infoHead);
      const infoTop = info.querySelector('[class*="info-content-top"]');
      if (infoTop && 'infoTop' in _btOrig) infoTop.setAttribute('style', _btOrig.infoTop);
      info.querySelectorAll('svg').forEach((s, idx) => {
        if (('svg' + idx) in _btOrig) s.setAttribute('style', _btOrig['svg' + idx]);
      });
    }
    Object.keys(_btOrig).forEach(k => delete _btOrig[k]);
    window.dispatchEvent(new Event('resize'));
  }

  function toggleBtLayout() {
    if (!isOnTradePage()) return;
    _btLayoutOn = !_btLayoutOn;
    if (_btLayoutOn) {
      applyBtLayout();
      if (!_btResizeHandler) {
        _btResizeHandler = () => applyBtLayout();
        window.addEventListener('resize', _btResizeHandler);
      }
    } else {
      if (_btResizeHandler) {
        window.removeEventListener('resize', _btResizeHandler);
        _btResizeHandler = null;
      }
      restoreBtLayout();
    }
  }

  // ── Modal ─────────────────────────────────────────────────────────────
  function closeModal() {
    document.getElementById('bt-modal-overlay')?.remove();
  }

  function showModal(type, orderType) {
    closeModal();
    const coin = getCurrentCoin();
    const isBuy = type === 'buy';
    const colorClass = isBuy ? 'buy' : 'sell';

    const overlay = document.createElement('div');
    overlay.id = 'bt-modal-overlay';
    overlay.innerHTML = `
      <div id="bt-modal-box">
        <div class="bt-modal-title">${coin ? coin + ' ' : ''}${isBuy ? '매수' : '매도'} 주문</div>
        <div class="bt-modal-type">${orderType === 'market' ? '시장가' : '지정가'}</div>
        <div class="bt-pct-row">
          <button class="bt-pct-btn ${colorClass}" data-pct="10%">10%</button>
          <button class="bt-pct-btn ${colorClass}" data-pct="25%">25%</button>
          <button class="bt-pct-btn ${colorClass}" data-pct="50%">50%</button>
          <button class="bt-pct-btn ${colorClass}" data-pct="75%">75%</button>
          <button class="bt-pct-btn ${colorClass}" data-pct="최대">최대</button>
        </div>
        <button class="bt-cancel-btn">취소 (ESC)</button>
      </div>
    `;

    overlay.querySelector('.bt-cancel-btn').addEventListener('click', closeModal);
    overlay.addEventListener('click', e => { if (e.target === overlay) closeModal(); });

    overlay.querySelectorAll('.bt-pct-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        const pct = btn.dataset.pct;
        closeModal();
        if (orderType === 'market') await executeMarketOrder(type, pct);
        else await executeOrder(type, pct);
      });
    });

    document.body.appendChild(overlay);
  }

  // ── Shortcut matching ─────────────────────────────────────────────────
  function matchShortcut(e, sc) {
    if (!sc.key || !sc.command) return false;
    const mods = sc.modifier ? sc.modifier.split('+') : [];
    return sc.key.toLowerCase() === e.key.toLowerCase()
      && mods.includes('shift') === !!e.shiftKey
      && mods.includes('ctrl')  === !!e.ctrlKey
      && mods.includes('alt')   === !!e.altKey
      && !e.metaKey;
  }

  async function executeCommand(sc) {
    switch (sc.command) {
      case 'BUY':                showModal('buy',  'limit');  break;
      case 'SELL':               showModal('sell', 'limit');  break;
      case 'MARKET_BUY':         showModal('buy',  'market'); break;
      case 'MARKET_SELL':        showModal('sell', 'market'); break;
      case 'BUY_10':             await executeOrder('buy',  '10%'); break;
      case 'BUY_25':             await executeOrder('buy',  '25%'); break;
      case 'BUY_50':             await executeOrder('buy',  '50%'); break;
      case 'BUY_75':             await executeOrder('buy',  '75%'); break;
      case 'BUY_MAX':            await executeOrder('buy',  '최대'); break;
      case 'SELL_10':            await executeOrder('sell', '10%'); break;
      case 'SELL_25':            await executeOrder('sell', '25%'); break;
      case 'SELL_50':            await executeOrder('sell', '50%'); break;
      case 'SELL_75':            await executeOrder('sell', '75%'); break;
      case 'SELL_MAX':           await executeOrder('sell', '최대'); break;
      case 'MARKET_BUY_10':      await executeMarketOrder('buy',  '10%'); break;
      case 'MARKET_BUY_25':      await executeMarketOrder('buy',  '25%'); break;
      case 'MARKET_BUY_50':      await executeMarketOrder('buy',  '50%'); break;
      case 'MARKET_BUY_75':      await executeMarketOrder('buy',  '75%'); break;
      case 'MARKET_BUY_MAX':     await executeMarketOrder('buy',  '최대'); break;
      case 'MARKET_SELL_10':     await executeMarketOrder('sell', '10%'); break;
      case 'MARKET_SELL_25':     await executeMarketOrder('sell', '25%'); break;
      case 'MARKET_SELL_50':     await executeMarketOrder('sell', '50%'); break;
      case 'MARKET_SELL_75':     await executeMarketOrder('sell', '75%'); break;
      case 'MARKET_SELL_MAX':    await executeMarketOrder('sell', '최대'); break;
      case 'CUSTOM_LIMIT_BUY':   await executeCustomOrder('buy',  'limit',  sc); break;
      case 'CUSTOM_LIMIT_SELL':  await executeCustomOrder('sell', 'limit',  sc); break;
      case 'CUSTOM_MARKET_BUY':  await executeCustomOrder('buy',  'market', sc); break;
      case 'CUSTOM_MARKET_SELL': await executeCustomOrder('sell', 'market', sc); break;
      case 'CANCEL_1':           await cancelOrder(false); break;
      case 'CANCEL_ALL':         await cancelOrder(true);  break;
      case 'TOGGLE_LAYOUT':      toggleBtLayout();         break;
    }
  }

  // ── Key handler ───────────────────────────────────────────────────────
  document.addEventListener('keydown', async e => {
    if (!isOnTradePage()) return;

    if (e.key === 'Escape') { closeModal(); return; }

    if (!e.metaKey && !e.ctrlKey && !e.altKey) {
      const tag = e.target?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
    }

    if (document.getElementById('bt-modal-overlay')) {
      const keyMap = { '1': '10%', '2': '25%', '3': '50%', '4': '75%', '5': '최대' };
      if (keyMap[e.key]) {
        document.querySelector(`.bt-pct-btn[data-pct="${keyMap[e.key]}"]`)?.click();
        return;
      }
    }

    for (const sc of cfg.shortcuts) {
      if (matchShortcut(e, sc)) {
        e.preventDefault();
        await executeCommand(sc);
        return;
      }
    }

    if (!document.getElementById('bt-modal-overlay')
        && ['1','2','3','4','5','6','7'].includes(e.key)
        && !e.shiftKey && !e.ctrlKey && !e.altKey && !e.metaKey) {
      e.preventDefault();
      navTab(e.key);
    }
  }, true);

})();
