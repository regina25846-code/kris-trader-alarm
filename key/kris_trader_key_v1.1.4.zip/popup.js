'use strict';

// ── Common ─────────────────────────────────────────────────────────────
const MODIFIERS = ['', 'shift', 'ctrl', 'alt', 'ctrl+shift', 'ctrl+alt', 'alt+shift'];
const MODIFIER_LABELS = {
  '': '미설정', 'shift': 'Shift', 'ctrl': 'Ctrl', 'alt': 'Alt',
  'ctrl+shift': 'Ctrl+Shift', 'ctrl+alt': 'Ctrl+Alt', 'alt+shift': 'Alt+Shift',
};
const KEYS = ['',
  '1','2','3','4','5','6','7','8','9','0',
  'a','b','c','d','e','f','g','h','i','j','k','l','m',
  'n','o','p','q','r','s','t','u','v','w','x','y','z',
  '`','-','=','[',']',';',"'",',','.','/',
];
const SOUND_DEFS = {
  buy:    { sound1:[{f:523,d:.08},{f:659,d:.08},{f:784,d:.15}], sound2:[{f:880,d:.05},{f:1047,d:.18,g:.25}], sound3:[{f:440,d:.06},{f:523,d:.06},{f:659,d:.06},{f:784,d:.12}] },
  sell:   { sound1:[{f:784,d:.08},{f:659,d:.08},{f:523,d:.15}], sound2:[{f:1047,d:.05},{f:880,d:.18,g:.25}], sound3:[{f:523,d:.06},{f:440,d:.06},{f:349,d:.12}] },
  cancel: { sound1:[{f:220,d:.25,t:'sawtooth',g:.2}], sound2:[{f:330,d:.1},{f:220,d:.15,g:.2}], sound3:[{f:440,d:.05},{f:330,d:.05},{f:220,d:.08},{f:165,d:.12,g:.15}] },
};

function fmtComma(v) {
  const str = String(v || '').replace(/,/g, '');
  if (str === '') return '';
  const [intPart, decPart] = str.split('.');
  const n = parseInt(intPart, 10);
  if (isNaN(n)) return str;
  return decPart !== undefined ? `${n.toLocaleString('ko-KR')}.${decPart}` : n.toLocaleString('ko-KR');
}

function playWebAudio(notes, volume) {
  try {
    const ctx = new AudioContext();
    let t = ctx.currentTime + 0.01;
    notes.forEach(({ f, d, g = 0.3, t: type = 'sine' }) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain); gain.connect(ctx.destination);
      osc.type = type;
      osc.frequency.setValueAtTime(f, t);
      gain.gain.setValueAtTime(g * volume, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + d);
      osc.start(t); osc.stop(t + d + 0.02);
      t += d * 0.75;
    });
    setTimeout(() => ctx.close(), 2000);
  } catch(e) {}
}

function makeSelect(className, options, selected) {
  const sel = document.createElement('select');
  sel.className = className;
  let currentGroup = null;
  options.forEach(({ value, label, type }) => {
    if (type === 'group') {
      currentGroup = document.createElement('optgroup');
      currentGroup.label = label;
      sel.appendChild(currentGroup);
      return;
    }
    const opt = document.createElement('option');
    opt.value = value;
    opt.textContent = label;
    if (value === selected) opt.selected = true;
    (currentGroup || sel).appendChild(opt);
  });
  return sel;
}

function applyTheme(theme) {
  document.body.classList.toggle('light', theme === 'light');
  const btn = document.getElementById('btn-theme');
  if (btn) btn.textContent = theme === 'light' ? '🌙' : '☀️';
}

// ── Tab state ──────────────────────────────────────────────────────────
let currentTab = 'upbit';

function switchTab(tab) {
  currentTab = tab;
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll('.panel').forEach(p => p.classList.toggle('active', p.id === `panel-${tab}`));
  document.getElementById('settings-upbit').style.display  = tab === 'upbit'   ? '' : 'none';
  document.getElementById('settings-bithumb').style.display = tab === 'bithumb' ? '' : 'none';
  document.getElementById('sound-upbit').style.display     = tab === 'upbit'   ? '' : 'none';
  document.getElementById('sound-bithumb').style.display   = tab === 'bithumb' ? '' : 'none';
}

// ── Site module factory ────────────────────────────────────────────────
function createSite({ ns, storageKey, commands, customCmds, limitCustomCmds, commandDescs, defaultShortcuts, hasTabShortcuts, hasLayoutH }) {
  const $ = id => document.getElementById(`${ns}-${id}`);
  let customData = { buy: null, sell: null, cancel: null };

  function updateCmdLabel(row) {
    const cmdSel = row.querySelector('.cmd-sel');
    if (!cmdSel) return;
    const cmd = cmdSel.value;
    if (!customCmds.has(cmd)) return;
    const baseLabel = commands.find(c => c.value === cmd)?.label || cmd;
    const priceRaw = (row.querySelector('[data-field="price"]')?.value || '').replace(/,/g, '');
    const qtyRaw   = (row.querySelector('[data-field="qty"]')?.value  || '').replace(/,/g, '');
    const pn = parseFloat(priceRaw), qn = parseFloat(qtyRaw);
    let suffix = '';
    if (limitCustomCmds.has(cmd) && !isNaN(pn) && pn > 0) suffix = ` ${fmtComma(priceRaw)}원`;
    else if (!isNaN(qn) && qn > 0) suffix = ` ${fmtComma(qtyRaw)}개`;
    const opt = cmdSel.querySelector(`option[value="${cmd}"]`);
    if (opt) opt.textContent = baseLabel + suffix;
  }

  function makeSubForm(sc) {
    const div = document.createElement('div');
    div.className = 'custom-sub';
    const isLimit = limitCustomCmds.has(sc.command);
    div.innerHTML = `
      <div class="custom-sub-inner">
        ${isLimit ? `<label class="sub-label">총액(KRW) <input class="sub-input" data-field="price" value="${fmtComma(sc.price)}" placeholder="예: 500,000"/></label>` : ''}
        <label class="sub-label">수량 <input class="sub-input" data-field="qty" value="${fmtComma(sc.qty)}" placeholder="예: 0.001"/></label>
      </div>
      <div class="sub-note">※ 단축키 누르면 위 값으로 즉시 주문 실행</div>
    `;
    div.querySelectorAll('.sub-input').forEach(inp => {
      inp.addEventListener('input', function() {
        const raw = this.value.replace(/,/g, '');
        if (raw === '' || raw === '.' || raw.endsWith('.')) return;
        const fmt = fmtComma(raw);
        if (fmt && this.value !== fmt) this.value = fmt;
        const row = this.closest('.shortcut-row');
        if (row) updateCmdLabel(row);
      });
    });
    return div;
  }

  function syncSubForm(row, newCommand) {
    const oldSub = row.querySelector('.custom-sub');
    const isCustom = customCmds.has(newCommand);
    const editBtn = row.querySelector('.btn-edit');
    if (!isCustom) { oldSub?.remove(); editBtn?.remove(); return; }
    let btn = editBtn;
    if (!btn) {
      btn = document.createElement('button');
      btn.className = 'btn-edit'; btn.textContent = '변경';
      row.querySelector('.row-actions').prepend(btn);
      btn.addEventListener('click', () => { const sub = row.querySelector('.custom-sub'); if (sub) { sub.classList.toggle('open'); btn.classList.toggle('open'); } });
    }
    const wasOpen = oldSub?.classList.contains('open');
    const prevPrice = (oldSub?.querySelector('[data-field="price"]')?.value || '').replace(/,/g, '');
    const prevQty   = (oldSub?.querySelector('[data-field="qty"]')?.value   || '').replace(/,/g, '');
    oldSub?.remove();
    const newSub = makeSubForm({ command: newCommand, price: prevPrice, qty: prevQty });
    if (wasOpen) newSub.classList.add('open');
    row.appendChild(newSub);
    updateCmdLabel(row);
  }

  function createRow(sc) {
    const row = document.createElement('div');
    row.className = 'shortcut-row';
    const modOpts = MODIFIERS.map(m => ({ value: m, label: MODIFIER_LABELS[m] }));
    const keyOpts = KEYS.map(k => ({ value: k, label: k || '미설정' }));
    const modSel = makeSelect('mod-sel', modOpts, sc.modifier || '');
    const keySel = makeSelect('key-sel', keyOpts, sc.key || '');
    const cmdSel = makeSelect('cmd-sel', commands, sc.command || '');
    cmdSel.title = commandDescs[sc.command || ''] || '';
    const actions = document.createElement('div');
    actions.className = 'row-actions';
    const delBtn = document.createElement('button');
    delBtn.className = 'btn-del'; delBtn.textContent = '삭제';
    delBtn.addEventListener('click', () => row.remove());
    actions.appendChild(delBtn);
    const main = document.createElement('div');
    main.className = 'row-main';
    main.appendChild(modSel); main.appendChild(keySel); main.appendChild(cmdSel); main.appendChild(actions);
    row.appendChild(main);
    if (customCmds.has(sc.command)) {
      const editBtn = document.createElement('button');
      editBtn.className = 'btn-edit'; editBtn.textContent = '변경';
      actions.prepend(editBtn);
      const sub = makeSubForm(sc);
      row.appendChild(sub);
      editBtn.addEventListener('click', () => { sub.classList.toggle('open'); editBtn.classList.toggle('open'); });
      updateCmdLabel(row);
    }
    cmdSel.addEventListener('change', () => { cmdSel.title = commandDescs[cmdSel.value] || ''; syncSubForm(row, cmdSel.value); updateCmdLabel(row); });
    return row;
  }

  function renderAll(shortcuts) {
    $('rows').innerHTML = '';
    shortcuts.forEach(sc => $('rows').appendChild(createRow(sc)));
  }

  function collectRow(row, fixed) {
    return {
      modifier: row.querySelector('.mod-sel')?.value || '',
      key:      row.querySelector('.key-sel')?.value || '',
      command:  row.querySelector('.cmd-sel')?.value || '',
      fixed,
      price: (row.querySelector('[data-field="price"]')?.value?.trim() || '').replace(/,/g, ''),
      qty:   (row.querySelector('[data-field="qty"]')?.value?.trim()   || '').replace(/,/g, ''),
    };
  }

  function collectAll() {
    const result = [];
    document.querySelectorAll(`#${ns}-rows .shortcut-row`).forEach(r => result.push(collectRow(r, false)));
    return result;
  }

  function toggleCustomRow(type) {
    const val = $(`snd-${type}`)?.value;
    const row = $(`snd-${type}-file-row`);
    if (row) row.style.display = val === 'custom' ? 'block' : 'none';
  }

  const WAV_SOUNDS = new Set(['ddukbaegi','ding3','donggeon','fanfare','levelup','tada','victory','minus']);

  function playSoundPreview(type) {
    const sel = $(`snd-${type}`)?.value;
    if (!sel) return;
    const vol = parseInt($('snd-volume')?.value || 50) / 100;
    if (sel === 'custom') { if (customData[type]) { const a = new Audio(customData[type]); a.volume = vol; a.play(); } return; }
    if (WAV_SOUNDS.has(sel)) {
      fetch(chrome.runtime.getURL(`sounds/${sel}.wav`)).then(r=>r.blob()).then(blob=>{const u=URL.createObjectURL(blob);const a=new Audio(u);a.volume=vol;a.play().catch(()=>{});a.addEventListener('ended',()=>URL.revokeObjectURL(u));}).catch(()=>{});
      return;
    }
    const notes = SOUND_DEFS[type]?.[sel];
    if (notes) playWebAudio(notes, vol);
  }

  function loadSettings() {
    chrome.storage.local.get(storageKey, d => {
      const saved = d[storageKey] || {};
      const shortcuts = Array.isArray(saved.shortcuts) ? saved.shortcuts : defaultShortcuts.map(s => ({...s}));
      renderAll(shortcuts);
      if ($('auto-confirm')) $('auto-confirm').checked = saved.autoConfirm !== false;
      const heightResponsive = saved.heightResponsive ?? false;
      if ($('height-responsive')) $('height-responsive').checked = heightResponsive;
      if ($('chart-height-px'))   $('chart-height-px').value     = saved.chartHeightPx ?? 451;
      const hrRow = document.getElementById(`${ns}-chart-height-row`);
      if (hrRow) hrRow.style.display = heightResponsive ? 'none' : '';
      const snd = saved.sound || {};
      const onEl = $('snd-on'), offEl = $('snd-off');
      if (onEl && offEl) { (snd.enabled !== false ? onEl : offEl).checked = true; }
      const vol = snd.volume ?? 50;
      if ($('snd-volume')) $('snd-volume').value = vol;
      if ($('snd-vol-label')) $('snd-vol-label').textContent = vol + '%';
      ['buy','sell','cancel'].forEach(t => {
        if ($(`snd-${t}`)) $(`snd-${t}`).value = snd[t] || 'sound1';
        if (snd[`${t}Custom`]) customData[t] = snd[`${t}Custom`];
        toggleCustomRow(t);
      });
    });
  }

  function saveSettings() {
    const sc = collectAll();
    const autoConfirm     = $('auto-confirm')?.checked      ?? true;
    const heightResponsive = $('height-responsive')?.checked ?? false;
    const chartHeightPx   = parseInt($('chart-height-px')?.value) || 451;
    const data = { shortcuts: sc, autoConfirm, heightResponsive, chartHeightPx };
    if (hasTabShortcuts) data.tabShortcuts = true;
    data.sound = {
      enabled: $('snd-on')?.checked ?? true,
      volume:  parseInt($('snd-volume')?.value) || 50,
      buy:     $('snd-buy')?.value || 'sound1',
      sell:    $('snd-sell')?.value || 'sound1',
      cancel:  $('snd-cancel')?.value || 'sound1',
      buyCustom: customData.buy, sellCustom: customData.sell, cancelCustom: customData.cancel,
    };
    chrome.storage.local.set({ [storageKey]: data }, () => {
      const btn = $('btn-save');
      if (btn) { btn.textContent = '저장됨 ✓'; setTimeout(() => { btn.textContent = '저장'; }, 1500); }
    });
  }

  function init() {
    loadSettings();
    $('btn-add')?.addEventListener('click', () => {
      $('rows').appendChild(createRow({ modifier: '', key: '', command: '', fixed: false, price: '', qty: '' }));
    });
    $('btn-save')?.addEventListener('click', saveSettings);
    $('height-responsive')?.addEventListener('change', function() {
      const hrRow = document.getElementById(`${ns}-chart-height-row`);
      if (hrRow) hrRow.style.display = this.checked ? 'none' : '';
    });
    $('snd-volume')?.addEventListener('input', function() { if ($('snd-vol-label')) $('snd-vol-label').textContent = this.value + '%'; });
    ['buy','sell','cancel'].forEach(t => {
      $(`snd-${t}`)?.addEventListener('change', () => toggleCustomRow(t));
      $(`snd-${t}-file`)?.addEventListener('change', function() {
        const file = this.files[0]; if (!file) return;
        const reader = new FileReader();
        reader.onload = e => { customData[t] = e.target.result; };
        reader.readAsDataURL(file);
      });
    });
  }

  // Wire preview buttons (called after DOM ready)
  function wirePreviewBtns() {
    document.querySelectorAll(`.btn-preview[data-ns="${ns}"]`).forEach(btn => {
      btn.addEventListener('click', () => playSoundPreview(btn.dataset.type));
    });
  }

  return { init, wirePreviewBtns };
}

// ── Upbit config ───────────────────────────────────────────────────────
const upbitSite = createSite({
  ns: 'u',
  storageKey: 'upbit_shortcut_v1',
  commands: [
    { value: '', label: '─ 명령 선택 ─' },
    { type: 'group', label: '(지정가)매수' },
    { value: 'BUY_10', label: '지정가 10% 매수' }, { value: 'BUY_25', label: '지정가 25% 매수' },
    { value: 'BUY_50', label: '지정가 50% 매수' }, { value: 'BUY_100', label: '지정가 100% 매수' },
    { value: 'CUSTOM_LIMIT_BUY', label: '지정가격 수량 및 가격 매수 ★' },
    { type: 'group', label: '(지정가)매도' },
    { value: 'SELL_10', label: '지정가 10% 매도' }, { value: 'SELL_25', label: '지정가 25% 매도' },
    { value: 'SELL_50', label: '지정가 50% 매도' }, { value: 'SELL_100', label: '지정가 100% 매도' },
    { value: 'CUSTOM_LIMIT_SELL', label: '지정가격 수량 및 가격 매도 ★' },
    { type: 'group', label: '(시장가)매수' },
    { value: 'MARKET_BUY_10', label: '시장가 10% 매수' }, { value: 'MARKET_BUY_25', label: '시장가 25% 매수' },
    { value: 'MARKET_BUY_50', label: '시장가 50% 매수' }, { value: 'MARKET_BUY_100', label: '시장가 100% 매수' },
    { value: 'CUSTOM_MARKET_BUY', label: '시장가격 수량 및 가격 매수 ★' },
    { type: 'group', label: '(시장가)매도' },
    { value: 'MARKET_SELL_10', label: '시장가 10% 매도' }, { value: 'MARKET_SELL_25', label: '시장가 25% 매도' },
    { value: 'MARKET_SELL_50', label: '시장가 50% 매도' }, { value: 'MARKET_SELL_100', label: '시장가 100% 매도' },
    { value: 'CUSTOM_MARKET_SELL', label: '시장가격 수량 및 가격 매도 ★' },
    { type: 'group', label: '주문관련' },
    { value: 'CANCEL_1', label: '최상위 거래주문 취소' }, { value: 'CANCEL_ALL', label: '전체 주문 취소' },
    { type: 'group', label: '유용한 기능' },
    { value: 'TOGGLE_LAYOUT', label: '레이아웃 변경(와이드)' },
  ],
  customCmds: new Set(['CUSTOM_LIMIT_BUY','CUSTOM_LIMIT_SELL','CUSTOM_MARKET_BUY','CUSTOM_MARKET_SELL']),
  limitCustomCmds: new Set(['CUSTOM_LIMIT_BUY','CUSTOM_LIMIT_SELL']),
  commandDescs: { '': '실행할 명령을 선택하세요', 'BUY_10': '지정가 매수 10% 즉시 실행', 'BUY_25': '지정가 매수 25% 즉시 실행', 'BUY_50': '지정가 매수 50% 즉시 실행', 'BUY_100': '지정가 매수 100% 즉시 실행', 'SELL_10': '지정가 매도 10% 즉시 실행', 'SELL_25': '지정가 매도 25% 즉시 실행', 'SELL_50': '지정가 매도 50% 즉시 실행', 'SELL_100': '지정가 매도 100% 즉시 실행', 'MARKET_BUY_10': '시장가 매수 10% 즉시 실행', 'MARKET_BUY_25': '시장가 매수 25% 즉시 실행', 'MARKET_BUY_50': '시장가 매수 50% 즉시 실행', 'MARKET_BUY_100': '시장가 매수 100% 즉시 실행', 'MARKET_SELL_10': '시장가 매도 10% 즉시 실행', 'MARKET_SELL_25': '시장가 매도 25% 즉시 실행', 'MARKET_SELL_50': '시장가 매도 50% 즉시 실행', 'MARKET_SELL_100': '시장가 매도 100% 즉시 실행', 'CANCEL_1': '미체결 주문 1건 취소', 'CANCEL_ALL': '미체결 주문 전체 취소', 'TOGGLE_LAYOUT': '레이아웃 토글 (차트 풀스크린)', 'CUSTOM_LIMIT_BUY': '지정가 총액/수량 매수 즉시 실행 ★', 'CUSTOM_LIMIT_SELL': '지정가 총액/수량 매도 즉시 실행 ★', 'CUSTOM_MARKET_BUY': '시장가 수량 매수 즉시 실행 ★', 'CUSTOM_MARKET_SELL': '시장가 수량 매도 즉시 실행 ★' },
  defaultShortcuts: [
    { modifier: '', key: 'a', command: 'CANCEL_1', fixed: false },
    { modifier: 'shift', key: 's', command: 'CANCEL_ALL', fixed: false },
    { modifier: '', key: 't', command: 'TOGGLE_LAYOUT', fixed: false },
    { modifier: '', key: '', command: '', fixed: false },
  ],
  hasTabShortcuts: true,
  hasLayoutH: true,
});

// ── Bithumb config ─────────────────────────────────────────────────────
const bithumbSite = createSite({
  ns: 'b',
  storageKey: 'bithumb_shortcut_v2',
  commands: [
    { value: '', label: '─ 명령 선택 ─' },
    { type: 'group', label: '(지정가)매수' },
    { value: 'BUY_10', label: '지정가 10% 매수' }, { value: 'BUY_25', label: '지정가 25% 매수' },
    { value: 'BUY_50', label: '지정가 50% 매수' }, { value: 'BUY_75', label: '지정가 75% 매수' },
    { value: 'BUY_MAX', label: '지정가 최대 매수' }, { value: 'CUSTOM_LIMIT_BUY', label: '지정가 금액/수량 매수 ★' },
    { type: 'group', label: '(지정가)매도' },
    { value: 'SELL_10', label: '지정가 10% 매도' }, { value: 'SELL_25', label: '지정가 25% 매도' },
    { value: 'SELL_50', label: '지정가 50% 매도' }, { value: 'SELL_75', label: '지정가 75% 매도' },
    { value: 'SELL_MAX', label: '지정가 최대 매도' }, { value: 'CUSTOM_LIMIT_SELL', label: '지정가 금액/수량 매도 ★' },
    { type: 'group', label: '(시장가)매수' },
    { value: 'MARKET_BUY_10', label: '시장가 10% 매수' }, { value: 'MARKET_BUY_25', label: '시장가 25% 매수' },
    { value: 'MARKET_BUY_50', label: '시장가 50% 매수' }, { value: 'MARKET_BUY_75', label: '시장가 75% 매수' },
    { value: 'MARKET_BUY_MAX', label: '시장가 최대 매수' }, { value: 'CUSTOM_MARKET_BUY', label: '시장가 수량 매수 ★' },
    { type: 'group', label: '(시장가)매도' },
    { value: 'MARKET_SELL_10', label: '시장가 10% 매도' }, { value: 'MARKET_SELL_25', label: '시장가 25% 매도' },
    { value: 'MARKET_SELL_50', label: '시장가 50% 매도' }, { value: 'MARKET_SELL_75', label: '시장가 75% 매도' },
    { value: 'MARKET_SELL_MAX', label: '시장가 최대 매도' }, { value: 'CUSTOM_MARKET_SELL', label: '시장가 수량 매도 ★' },
    { type: 'group', label: '주문 취소' },
    { value: 'CANCEL_1', label: '첫 번째 미체결 주문 취소' }, { value: 'CANCEL_ALL', label: '전체 미체결 주문 취소' },
  ],
  customCmds: new Set(['CUSTOM_LIMIT_BUY','CUSTOM_LIMIT_SELL','CUSTOM_MARKET_BUY','CUSTOM_MARKET_SELL']),
  limitCustomCmds: new Set(['CUSTOM_LIMIT_BUY','CUSTOM_LIMIT_SELL']),
  commandDescs: { '': '실행할 명령을 선택하세요', 'BUY_10': '지정가 10% 즉시 매수', 'BUY_25': '지정가 25% 즉시 매수', 'BUY_50': '지정가 50% 즉시 매수', 'BUY_75': '지정가 75% 즉시 매수', 'BUY_MAX': '지정가 최대 즉시 매수', 'SELL_10': '지정가 10% 즉시 매도', 'SELL_25': '지정가 25% 즉시 매도', 'SELL_50': '지정가 50% 즉시 매도', 'SELL_75': '지정가 75% 즉시 매도', 'SELL_MAX': '지정가 최대 즉시 매도', 'MARKET_BUY_10': '시장가 10% 즉시 매수', 'MARKET_BUY_25': '시장가 25% 즉시 매수', 'MARKET_BUY_50': '시장가 50% 즉시 매수', 'MARKET_BUY_75': '시장가 75% 즉시 매수', 'MARKET_BUY_MAX': '시장가 최대 즉시 매수', 'MARKET_SELL_10': '시장가 10% 즉시 매도', 'MARKET_SELL_25': '시장가 25% 즉시 매도', 'MARKET_SELL_50': '시장가 50% 즉시 매도', 'MARKET_SELL_75': '시장가 75% 즉시 매도', 'MARKET_SELL_MAX': '시장가 최대 즉시 매도', 'CANCEL_1': '미체결 목록 첫 번째 주문 취소', 'CANCEL_ALL': '미체결 목록 전체 주문 일괄 취소', 'CUSTOM_LIMIT_BUY': '지정가 금액/수량 매수 즉시 실행 ★', 'CUSTOM_LIMIT_SELL': '지정가 금액/수량 매도 즉시 실행 ★', 'CUSTOM_MARKET_BUY': '시장가 수량 매수 즉시 실행 ★', 'CUSTOM_MARKET_SELL': '시장가 수량 매도 즉시 실행 ★' },
  defaultShortcuts: [
    { modifier: '', key: 'a', command: 'CANCEL_1', fixed: false },
    { modifier: 'shift', key: 's', command: 'CANCEL_ALL', fixed: false },
    { modifier: '', key: '', command: '', fixed: false },
  ],
  hasTabShortcuts: false,
  hasLayoutH: false,
});

// ── Main init ──────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const savedTheme = localStorage.getItem('kt-theme') || 'light';
  applyTheme(savedTheme);

  // Auto-detect exchange from active tab URL
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    const url = tabs[0]?.url || '';
    let detectedTab = null;
    if (url.includes('upbit.com')) detectedTab = 'upbit';
    else if (url.includes('bithumb.com')) detectedTab = 'bithumb';
    const tab = detectedTab || localStorage.getItem('kt-tab') || 'upbit';
    switchTab(tab);
    if (detectedTab) localStorage.setItem('kt-tab', detectedTab);
  });

  upbitSite.init();
  bithumbSite.init();
  upbitSite.wirePreviewBtns();
  bithumbSite.wirePreviewBtns();

  document.getElementById('btn-theme').addEventListener('click', () => {
    const next = document.body.classList.contains('light') ? 'dark' : 'light';
    localStorage.setItem('kt-theme', next);
    applyTheme(next);
  });

  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      switchTab(btn.dataset.tab);
      localStorage.setItem('kt-tab', btn.dataset.tab);
    });
  });

  document.getElementById('btn-settings').addEventListener('click', () => {
    document.getElementById('settings-overlay').style.display = 'flex';
  });
  document.getElementById('btn-sound').addEventListener('click', () => {
    document.getElementById('sound-overlay').style.display = 'flex';
  });
  document.querySelectorAll('.modal-close').forEach(btn => {
    btn.addEventListener('click', () => { document.getElementById(btn.dataset.close).style.display = 'none'; });
  });
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.style.display = 'none'; });
  });

  // Settings export
  document.getElementById('btn-export-settings').addEventListener('click', () => {
    chrome.storage.local.get(['upbit_shortcut_v1', 'bithumb_shortcut_v2'], data => {
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `kris_trader_key_settings_${new Date().toISOString().slice(0,10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
    });
  });

  // Settings import
  document.getElementById('btn-import-settings').addEventListener('click', () => {
    document.getElementById('import-settings-file').click();
  });
  document.getElementById('import-settings-file').addEventListener('change', function () {
    const file = this.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = e => {
      try {
        const data = JSON.parse(e.target.result);
        const toSet = {};
        if (data.upbit_shortcut_v1) toSet.upbit_shortcut_v1 = data.upbit_shortcut_v1;
        if (data.bithumb_shortcut_v2) toSet.bithumb_shortcut_v2 = data.bithumb_shortcut_v2;
        chrome.storage.local.set(toSet, () => {
          upbitSite.init();
          bithumbSite.init();
          alert('가져오기 완료');
        });
      } catch { alert('파일 파싱 오류'); }
    };
    reader.readAsText(file);
    this.value = '';
  });

  chrome.storage.local.get('pendingUpdate', data => {
    if (data.pendingUpdate) {
      const banner = document.getElementById('update-banner');
      banner.style.display = 'block';
      banner.addEventListener('click', () => {
        chrome.tabs.create({ url: data.pendingUpdate.page });
      });
    }
  });

  document.getElementById('hdr-logo').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://regina25846-code.github.io/kris-trader-alarm/key/manual.html' });
  });
});
