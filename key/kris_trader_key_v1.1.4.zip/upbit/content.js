(function () {
  'use strict';

  if (window.__tkInit) return;
  window.__tkInit = true;

  const STORAGE_KEY = 'upbit_shortcut_v1';

  const SOUND_DEFS = {
    buy:    {
      sound1: [{ f:523,d:.08 },{ f:659,d:.08 },{ f:784,d:.15 }],
      sound2: [{ f:880,d:.05 },{ f:1047,d:.18,g:.25 }],
      sound3: [{ f:440,d:.06 },{ f:523,d:.06 },{ f:659,d:.06 },{ f:784,d:.12 }],
    },
    sell:   {
      sound1: [{ f:784,d:.08 },{ f:659,d:.08 },{ f:523,d:.15 }],
      sound2: [{ f:1047,d:.05 },{ f:880,d:.18,g:.25 }],
      sound3: [{ f:523,d:.06 },{ f:440,d:.06 },{ f:349,d:.12 }],
    },
    cancel: {
      sound1: [{ f:220,d:.25,t:'sawtooth',g:.2 }],
      sound2: [{ f:330,d:.1 },{ f:220,d:.15,g:.2 }],
      sound3: [{ f:440,d:.05 },{ f:330,d:.05 },{ f:220,d:.08 },{ f:165,d:.12,g:.15 }],
    },
  };

  const WAV_SOUNDS = new Set(['ddukbaegi','ding3','donggeon','fanfare','levelup','tada','victory','minus']);

  function playSound(type) {
    const snd = cfg.sound;
    if (!snd?.enabled) return;
    const vol = (snd.volume ?? 50) / 100;
    const sel = snd[type] || 'sound1';
    if (sel === 'custom') {
      const dataUrl = snd[`${type}Custom`];
      if (dataUrl) { const a = new Audio(dataUrl); a.volume = vol; a.play().catch(() => {}); }
      return;
    }
    if (WAV_SOUNDS.has(sel)) {
      fetch(chrome.runtime.getURL(`sounds/${sel}.wav`)).then(r=>r.blob()).then(blob=>{const u=URL.createObjectURL(blob);const a=new Audio(u);a.volume=vol;a.play().catch(()=>{});a.addEventListener('ended',()=>URL.revokeObjectURL(u));}).catch(()=>{});
      return;
    }
    const notes = SOUND_DEFS[type]?.[sel];
    if (!notes) return;
    try {
      const ctx = new AudioContext();
      let t = ctx.currentTime + 0.01;
      notes.forEach(({ f, d, g = 0.3, t: wt = 'sine' }) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain); gain.connect(ctx.destination);
        osc.type = wt; osc.frequency.setValueAtTime(f, t);
        gain.gain.setValueAtTime(g * vol, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + d);
        osc.start(t); osc.stop(t + d + 0.02);
        t += d * 0.75;
      });
      setTimeout(() => ctx.close(), 2000);
    } catch(e) {}
  }

  const DEFAULT_SHORTCUTS = [
    { modifier: '',      key: 'a', command: 'CANCEL_1',     fixed: false },
    { modifier: 'shift', key: 's', command: 'CANCEL_ALL',   fixed: false },
    { modifier: '',      key: 't', command: 'TOGGLE_LAYOUT',fixed: false },
  ];

  const cfg = {
    autoConfirm: false,
    tabShortcuts: false,
    heightResponsive: false,
    chartHeightPx: 451,
    sound: { enabled: false, volume: 50, buy: 'sound1', sell: 'sound1', cancel: 'sound1' },
    shortcuts: DEFAULT_SHORTCUTS.map(s => ({ ...s })),
  };

  function applyTabNumStyle() {
    const ID = 'tk-tab-num-style';
    document.getElementById(ID)?.remove();
    if (!cfg.tabShortcuts) return;
    const s = document.createElement('style');
    s.id = ID;
    s.textContent = [
      `li.tabB__buy a::before    { font-size:.9em; font-weight:700; content:"(1) " !important; }`,
      `li.tabB__sell a::before   { font-size:.9em; font-weight:700; content:"(2) " !important; }`,
      `li.tabB__history a::before { font-size:.9em; font-weight:700; content:"(3,4) " !important; }`,
      `section.ty02 .tabB ul.ty05 li:nth-child(1) a::before { font-size:.9em; font-weight:700; content:"(5) " !important; }`,
      `section.ty02 .tabB ul.ty05 li:nth-child(4) a::before { font-size:.9em; font-weight:700; content:"(6) " !important; }`,
      `section.ty02 .tabB ul.ty05 li:nth-child(5) a::before { font-size:.9em; font-weight:700; content:"(7) " !important; }`,
    ].join('\n');
    document.head.appendChild(s);
  }

  // Migrate old object-format shortcuts to array
  function migrateOldShortcuts(obj) {
    const result = [];
    Object.entries(obj).forEach(([k, sc]) => {
      if (!sc.enabled || !sc.key) return;
      const mods = [];
      if (sc.shift) mods.push('shift');
      if (sc.ctrl)  mods.push('ctrl');
      if (sc.alt)   mods.push('alt');
      result.push({ modifier: mods.join('+'), key: sc.key, command: k, fixed: false, price: '', qty: '' });
    });
    return result.length ? result : DEFAULT_SHORTCUTS.map(s => ({ ...s }));
  }

  function loadSettings() {
    chrome.storage.local.get(STORAGE_KEY, d => {
      const saved = d[STORAGE_KEY];
      if (saved) {
        cfg.autoConfirm     = saved.autoConfirm     ?? cfg.autoConfirm;
        cfg.tabShortcuts    = saved.tabShortcuts    ?? cfg.tabShortcuts;
        cfg.heightResponsive = saved.heightResponsive ?? cfg.heightResponsive;
        cfg.chartHeightPx   = saved.chartHeightPx   ?? cfg.chartHeightPx;
        if (saved.sound) cfg.sound = { ...cfg.sound, ...saved.sound };

        if (Array.isArray(saved.shortcuts)) {
          cfg.shortcuts = saved.shortcuts;
        } else if (saved.shortcuts && typeof saved.shortcuts === 'object') {
          cfg.shortcuts = migrateOldShortcuts(saved.shortcuts);
        }
      }
      applyTabNumStyle();
    });
  }

  chrome.storage.onChanged.addListener(changes => {
    if (changes[STORAGE_KEY]) loadSettings();
  });

  chrome.runtime.onMessage.addListener(_msg => {});

  loadSettings();

  // ── Helpers ──────────────────────────────────────────────────────────
  const wait = ms => new Promise(r => setTimeout(r, ms));

  function getCurrentTab() {
    if (document.querySelector('.tabB__buy.on')) return 'buy';
    if (document.querySelector('.tabB__sell.on')) return 'sell';
    return null;
  }

  async function changeTab(type) {
    if (getCurrentTab() === type) return;
    const btn = document.querySelector(`.tabB__${type} .tabB__button`);
    if (btn) { btn.click(); await wait(120); }
  }

  function clickPercentButton(pct) {
    const btn = [...document.querySelectorAll('.percentage-button')]
      .find(b => b.innerText.trim() === pct);
    if (btn) { btn.click(); return true; }
    return false;
  }

  function getSubmitButton(type) {
    const label = type === 'buy' ? '매수' : '매도';
    const textEl = [...document.querySelectorAll('span, button')]
      .find(el => {
        const t = (el.innerText || el.textContent || '').trim();
        if (t !== label) return false;
        if (el.closest('.tabB__button')) return false;
        return true;
      });
    if (!textEl) return null;
    if (textEl.tagName === 'BUTTON') return textEl;
    let el = textEl.parentElement;
    while (el && el !== document.body) {
      if (el.tagName === 'BUTTON' || el.getAttribute('role') === 'button') return el;
      el = el.parentElement;
    }
    return textEl.parentElement;
  }

  function fireClick(el) {
    if (!el) return;
    el.dispatchEvent(new PointerEvent('click', { bubbles: true, cancelable: true, detail: 1 }));
  }

  function getCurrentCoin() {
    const m = document.title.match(/([A-Z]+)\/KRW/);
    return m ? m[1] : '';
  }

  // Set a React-controlled input value
  function setReactInputValue(el, value) {
    try {
      const desc = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
      desc.set.call(el, String(value));
      el.dispatchEvent(new Event('input',  { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    } catch(e) {}
  }

  function getTotalInput()  { return document.querySelector('[data-testid="total-input"]'); }
  function getQtyInput()    { return document.querySelector('[data-testid="volume-input"]'); }

  // ── Order execute ─────────────────────────────────────────────────────
  async function executeOrder(type, pct) {
    await changeTab(type);
    await wait(100);
    clickPercentButton(pct);
    await wait(150);
    fireClick(getSubmitButton(type));
    playSound(type === 'buy' ? 'buy' : 'sell');
    if (cfg.autoConfirm) await waitAndClickConfirm();
  }

  async function executeMarketOrder(type, pct) {
    await changeTab(type);
    await wait(80);
    const marketBtn = [...document.querySelectorAll('.rightB button')]
      .find(b => b.innerText.trim() === '시장가');
    if (marketBtn) { marketBtn.click(); await wait(100); }
    clickPercentButton(pct);
    await wait(150);
    fireClick(getSubmitButton(type));
    playSound(type === 'buy' ? 'buy' : 'sell');
    if (cfg.autoConfirm) { await wait(500); autoConfirmModal(); }
  }

  async function executeCustomOrder(type, orderType, sc) {
    await changeTab(type);
    await wait(80);

    if (orderType === 'market') {
      const marketBtn = [...document.querySelectorAll('.rightB button')].find(b => b.innerText.trim() === '시장가');
      if (marketBtn) { marketBtn.click(); await wait(100); }
    } else {
      const limitBtn = [...document.querySelectorAll('.rightB button')].find(b => b.innerText.trim() === '지정가');
      if (limitBtn) { limitBtn.click(); await wait(100); }
    }

    if (orderType === 'limit' && sc.price) {
      // sc.price = 원하는 주문총액(KRW). 현재 매수가격으로 수량 계산 후 volume-input에 입력.
      const priceEl = document.querySelector('[data-testid="order-price-input"]');
      const unitPrice = parseFloat((priceEl?.value || '').replace(/,/g, ''));
      if (unitPrice > 0) {
        const qty = sc.price / unitPrice;
        const qtyInput = getQtyInput();
        if (qtyInput) { setReactInputValue(qtyInput, String(qty)); await wait(80); }
      }
    } else if (sc.qty) {
      const qtyInput = getQtyInput();
      if (qtyInput) { setReactInputValue(qtyInput, sc.qty); await wait(80); }
    }

    await wait(100);
    fireClick(getSubmitButton(type));
    playSound(type === 'buy' ? 'buy' : 'sell');
    if (cfg.autoConfirm) await waitAndClickConfirm();
  }

  async function waitAndClickConfirm() {
    let clicked = false;
    const d1 = Date.now() + 3000;
    while (Date.now() < d1) {
      const btn = [...document.querySelectorAll('button, a')].find(b => {
        const t = b.innerText.trim();
        return t === '매수 확인' || t === '매도 확인' || t === '주문 확인';
      });
      if (btn) { fireClick(btn); clicked = true; break; }
      await wait(30);
    }
    if (!clicked) return;
    const d2 = Date.now() + 2000;
    while (Date.now() < d2) {
      const ack = [...document.querySelectorAll('button, a')].find(b => b.innerText.trim() === '확인');
      if (ack) { fireClick(ack); return; }
      await wait(30);
    }
  }

  function autoConfirmModal() {
    const confirm = [...document.querySelectorAll('button, a')].find(b => {
      const t = b.innerText.trim();
      return t === '매수 확인' || t === '매도 확인' || t === '주문 확인'
        || (t.includes('확인') && !t.includes('취소'));
    });
    if (confirm) fireClick(confirm);
  }

  // ── Cancel order ──────────────────────────────────────────────────────
  async function cancelOrder(all) {
    const histTab = document.querySelector('.tabB__history > a')
      || [...document.querySelectorAll('.tabB__button')].find(b => b.innerText.includes('거래내역'));
    if (histTab) { histTab.click(); await wait(200); }

    if (all) {
      const bulkBtn = [...document.querySelectorAll('a, button')].find(b => b.innerText.trim() === '일괄취소');
      if (!bulkBtn) return;
      bulkBtn.dispatchEvent(new PointerEvent('click', { bubbles: true, cancelable: true, detail: 1 }));
      await waitAndClickByText('주문 취소');
      await waitAndClickByText('확인', 3000);
      playSound('cancel');
    } else {
      let cancelBtns = [];
      const deadline = Date.now() + 1500;
      while (Date.now() < deadline) {
        cancelBtns = [...document.querySelectorAll('a, button')].filter(b => b.innerText.trim() === '주문취소');
        if (cancelBtns.length) break;
        await wait(30);
      }
      if (!cancelBtns.length) return;
      cancelBtns[0].dispatchEvent(new PointerEvent('click', { bubbles: true, cancelable: true, detail: 1 }));
      await waitAndClickByText('주문 취소');
      await waitAndClickByText('확인', 3000);
      playSound('cancel');
    }
  }

  async function waitAndClickByText(text, timeout = 2000) {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      const el = [...document.querySelectorAll('a, button')].find(b => b.innerText.trim() === text);
      if (el) { el.dispatchEvent(new PointerEvent('click', { bubbles: true, cancelable: true, detail: 1 })); return true; }
      await wait(30);
    }
    return false;
  }

  // ── Layout toggle ─────────────────────────────────────────────────────
  let _ty02OrigStyle = '';

  function positionTy02() {
    const ty02 = document.querySelector('.mainB > .ty02');
    const rightB = document.querySelector('.rightB');
    const firstArt = document.querySelector('.rightB > article');
    if (!ty02 || !rightB || !firstArt) return;
    const rb = rightB.getBoundingClientRect();
    const fa = firstArt.getBoundingClientRect();
    if (rb.width === 0) return;
    ty02.style.cssText = [
      'display: block !important',
      'position: fixed !important',
      `left: ${Math.round(rb.left)}px !important`,
      `top: ${Math.round(fa.bottom)}px !important`,
      `width: ${Math.round(rb.width)}px !important`,
      `height: ${Math.round(window.innerHeight - fa.bottom - 10)}px !important`,
      'overflow-y: auto !important',
      'z-index: 95 !important',
    ].join(';');
  }

  let _tkResizeHandler = null;
  let _tkApplying = false;

  function applyResponsiveHeights() {
    if (_tkApplying) return;
    _tkApplying = true;

    const chartEl  = document.getElementById('tv_chart_container');
    const mainB    = document.querySelector('.mainB');
    const ty01     = document.querySelector('.ty01');
    const rightB   = document.querySelector('.rightB');

    // ── 너비: 항상 자동 반응형 ──
    if (mainB && ty01 && chartEl) {
      const leftOffset  = mainB.getBoundingClientRect().left;
      const rightWidth  = rightB ? (rightB.getBoundingClientRect().width || 495) : 495;
      const newW        = Math.max(400, window.innerWidth - leftOffset - rightWidth);

      if (!mainB.dataset.tkOrigW) mainB.dataset.tkOrigW = mainB.style.width || '';
      if (!ty01.dataset.tkOrigW)  ty01.dataset.tkOrigW  = ty01.style.width  || '';

      mainB.style.setProperty('width', (window.innerWidth - leftOffset) + 'px', 'important');
      ty01.style.setProperty('width',  newW + 'px', 'important');

      // CSS에 925px로 고정된 chart article 직접 오버라이드
      const chartArticle = chartEl.closest('.ty01 > article');
      if (chartArticle) {
        if (!chartArticle.dataset.tkOrigW) chartArticle.dataset.tkOrigW = chartArticle.style.width || '';
        chartArticle.style.setProperty('width',     newW + 'px', 'important');
        chartArticle.style.setProperty('max-width', newW + 'px', 'important');
      }
    }

    // ── 높이: 설정에 따라 자동/수동 ──
    if (chartEl) {
      if (!chartEl.dataset.tkOrigH) {
        chartEl.dataset.tkOrigH = parseFloat(chartEl.style.height) || chartEl.getBoundingClientRect().height;
      }
      if (cfg.heightResponsive) {
        const top = chartEl.getBoundingClientRect().top + window.scrollY;
        chartEl.style.height = Math.max(300, window.innerHeight - top - 10) + 'px';
      } else {
        chartEl.style.height = Math.max(300, cfg.chartHeightPx || 451) + 'px';
      }
    }

    const orderWrap = document.querySelector('.orderContainer__wrap');
    if (orderWrap) {
      if (!orderWrap.dataset.tkOrigH) {
        orderWrap.dataset.tkOrigH = parseFloat(orderWrap.style.height) || orderWrap.getBoundingClientRect().height;
      }
      const top = orderWrap.getBoundingClientRect().top + window.scrollY;
      orderWrap.style.height = Math.max(200, window.innerHeight - top - 10) + 'px';
    }

    positionTy02();

    setTimeout(() => {
      _tkApplying = false;
      window.dispatchEvent(new Event('resize'));
    }, 50);
  }

  function adjustTKHeights() {
    applyResponsiveHeights();
    if (!_tkResizeHandler) {
      _tkResizeHandler = () => applyResponsiveHeights();
      window.addEventListener('resize', _tkResizeHandler);
    }
  }

  function restoreTKHeights() {
    if (_tkResizeHandler) {
      window.removeEventListener('resize', _tkResizeHandler);
      _tkResizeHandler = null;
    }
    const mainB  = document.querySelector('.mainB');
    const ty01   = document.querySelector('.ty01');
    if (mainB && mainB.dataset.tkOrigW !== undefined) {
      mainB.style.setProperty('width', mainB.dataset.tkOrigW);
      delete mainB.dataset.tkOrigW;
    }
    if (ty01 && ty01.dataset.tkOrigW !== undefined) {
      ty01.style.setProperty('width', ty01.dataset.tkOrigW);
      delete ty01.dataset.tkOrigW;
    }
    const chartEl2 = document.getElementById('tv_chart_container');
    const chartArticle = chartEl2?.closest('.ty01 > article');
    if (chartArticle && chartArticle.dataset.tkOrigW !== undefined) {
      chartArticle.style.setProperty('width', chartArticle.dataset.tkOrigW);
      chartArticle.style.removeProperty('max-width');
      delete chartArticle.dataset.tkOrigW;
    }
    const chartEl = document.getElementById('tv_chart_container');
    if (chartEl && chartEl.dataset.tkOrigH) {
      chartEl.style.height = chartEl.dataset.tkOrigH + 'px';
      delete chartEl.dataset.tkOrigH;
      window.dispatchEvent(new Event('resize'));
    }
    const orderWrap = document.querySelector('.orderContainer__wrap');
    if (orderWrap && orderWrap.dataset.tkOrigH) {
      orderWrap.style.height = orderWrap.dataset.tkOrigH + 'px';
      delete orderWrap.dataset.tkOrigH;
    }
  }

  function toggleLayout() {
    const layout = document.querySelector('#UpbitLayout');
    if (!layout) return;
    layout.classList.remove('TKOpenList');

    const wasActive = layout.classList.contains('TKTradingView');
    layout.classList.toggle('TKTradingView');

    for (let i = 0; i < 2000; i += 500) {
      setTimeout(() => window.dispatchEvent(new Event('resize')), i);
    }

    const ty02 = document.querySelector('.mainB > .ty02');
    if (!wasActive) {
      if (ty02) _ty02OrigStyle = ty02.getAttribute('style') || '';
      setTimeout(adjustTKHeights, 700);
    } else {
      if (ty02) ty02.setAttribute('style', _ty02OrigStyle);
      restoreTKHeights();
    }
  }

  // ── Modal ─────────────────────────────────────────────────────────────
  function closeModal() {
    document.getElementById('tk-modal-overlay')?.remove();
  }

  function showModal(type, orderType) {
    closeModal();
    const coin = getCurrentCoin();
    const isBuy = type === 'buy';
    const colorClass = isBuy ? 'buy' : 'sell';

    const overlay = document.createElement('div');
    overlay.id = 'tk-modal-overlay';
    overlay.innerHTML = `
      <div id="tk-modal-box">
        <div class="tk-modal-title">${coin ? coin + ' ' : ''}${isBuy ? '매수' : '매도'} 주문</div>
        <div class="tk-modal-type">${orderType === 'market' ? '시장가' : '지정가'}</div>
        <div class="tk-pct-row">
          <button class="tk-pct-btn ${colorClass}" data-pct="10%">10%</button>
          <button class="tk-pct-btn ${colorClass}" data-pct="25%">25%</button>
          <button class="tk-pct-btn ${colorClass}" data-pct="50%">50%</button>
          <button class="tk-pct-btn ${colorClass}" data-pct="100%">100%</button>
        </div>
        <button class="tk-cancel-btn">취소 (ESC)</button>
      </div>
    `;

    overlay.querySelector('.tk-cancel-btn').addEventListener('click', closeModal);
    overlay.addEventListener('click', e => { if (e.target === overlay) closeModal(); });

    overlay.querySelectorAll('.tk-pct-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        const pct = btn.dataset.pct;
        closeModal();
        if (orderType === 'market') await executeMarketOrder(type, pct);
        else await executeOrder(type, pct);
      });
    });

    document.body.appendChild(overlay);
  }

  // ── Tab navigation ────────────────────────────────────────────────────
  async function navigateTab(n) {
    switch (n) {
      case 1: document.querySelector('.tabB__buy .tabB__button')?.click(); break;
      case 2: document.querySelector('.tabB__sell .tabB__button')?.click(); break;
      case 3: {
        const h = document.querySelector('.tabB__history .tabB__button') || document.querySelector('.tabB__history > a');
        if (h) { h.click(); await wait(150); }
        [...document.querySelectorAll('button, a')].find(b => (b.innerText || '').trim() === '미체결')?.click();
        break;
      }
      case 4: {
        const h = document.querySelector('.tabB__history .tabB__button') || document.querySelector('.tabB__history > a');
        if (h) { h.click(); await wait(150); }
        const el = document.querySelector('[data-testid="selectedIndex-1-text"]');
        if (el) { (el.parentElement || el).click(); break; }
        const fb = [...document.querySelectorAll('span, div')].find(e =>
          !e.children.length && (e.innerText || e.textContent || '').trim() === '체결'
        );
        if (fb) (fb.parentElement || fb).click();
        break;
      }
      case 5: [...document.querySelectorAll('section.ty02 .tabB a')].find(a => (a.innerText || '').includes('원화'))?.click(); break;
      case 6: [...document.querySelectorAll('section.ty02 .tabB a')].find(a => (a.innerText || '').includes('보유'))?.click(); break;
      case 7: [...document.querySelectorAll('section.ty02 .tabB a')].find(a => (a.innerText || '').includes('관심'))?.click(); break;
    }
  }

  // ── Shortcut matching ─────────────────────────────────────────────────
  function matchShortcut(e, sc) {
    if (!sc.key || !sc.command) return false;
    const mods = sc.modifier ? sc.modifier.split('+') : [];
    return sc.key.toLowerCase() === e.key.toLowerCase()
      && mods.includes('shift') === !!e.shiftKey
      && mods.includes('ctrl')  === !!e.ctrlKey
      && mods.includes('alt')   === !!e.altKey
      && !e.metaKey;
  }

  async function executeCommand(sc) {
    switch (sc.command) {
      case 'BUY':               showModal('buy', 'limit'); break;
      case 'SELL':              showModal('sell', 'limit'); break;
      case 'MARKET_BUY':        showModal('buy', 'market'); break;
      case 'MARKET_SELL':       showModal('sell', 'market'); break;
      case 'BUY_10':            await executeOrder('buy', '10%'); break;
      case 'BUY_25':            await executeOrder('buy', '25%'); break;
      case 'BUY_50':            await executeOrder('buy', '50%'); break;
      case 'BUY_100':           await executeOrder('buy', '100%'); break;
      case 'SELL_10':           await executeOrder('sell', '10%'); break;
      case 'SELL_25':           await executeOrder('sell', '25%'); break;
      case 'SELL_50':           await executeOrder('sell', '50%'); break;
      case 'SELL_100':          await executeOrder('sell', '100%'); break;
      case 'MARKET_BUY_10':     await executeMarketOrder('buy', '10%'); break;
      case 'MARKET_BUY_25':     await executeMarketOrder('buy', '25%'); break;
      case 'MARKET_BUY_50':     await executeMarketOrder('buy', '50%'); break;
      case 'MARKET_BUY_100':    await executeMarketOrder('buy', '100%'); break;
      case 'MARKET_SELL_10':    await executeMarketOrder('sell', '10%'); break;
      case 'MARKET_SELL_25':    await executeMarketOrder('sell', '25%'); break;
      case 'MARKET_SELL_50':    await executeMarketOrder('sell', '50%'); break;
      case 'MARKET_SELL_100':   await executeMarketOrder('sell', '100%'); break;
      case 'CANCEL_1':          await cancelOrder(false); break;
      case 'CANCEL_ALL':        await cancelOrder(true); break;
      case 'TOGGLE_LAYOUT':     toggleLayout(); break;
      case 'CUSTOM_LIMIT_BUY':  await executeCustomOrder('buy', 'limit', sc); break;
      case 'CUSTOM_LIMIT_SELL': await executeCustomOrder('sell', 'limit', sc); break;
      case 'CUSTOM_MARKET_BUY': await executeCustomOrder('buy', 'market', sc); break;
      case 'CUSTOM_MARKET_SELL':await executeCustomOrder('sell', 'market', sc); break;
    }
  }

  // ── Key handler ───────────────────────────────────────────────────────
  document.addEventListener('keydown', async e => {
    if (location.pathname !== '/exchange') return;

    if (e.key === 'Escape') { closeModal(); return; }

    if (!e.metaKey && !e.ctrlKey && !e.altKey) {
      const tag = e.target?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
    }

    if (document.getElementById('tk-modal-overlay')) {
      const keyMap = { '1': '10%', '2': '25%', '3': '50%', '4': '100%' };
      if (keyMap[e.key]) {
        document.querySelector(`.tk-pct-btn[data-pct="${keyMap[e.key]}"]`)?.click();
        return;
      }
    }

    if (cfg.tabShortcuts) {
      const n = parseInt(e.key);
      if (n >= 1 && n <= 7 && !e.shiftKey && !e.altKey && !e.ctrlKey && !e.metaKey) {
        e.preventDefault(); await navigateTab(n); return;
      }
    }

    for (const sc of cfg.shortcuts) {
      if (matchShortcut(e, sc)) {
        e.preventDefault();
        await executeCommand(sc);
        return;
      }
    }
  }, true);

})();
