const CURRENT_VERSION = '3.2.0-1';
const HISTORY_KEY = 'kta_alarm_history_v1';
const SETTINGS_KEY = 'upbit_alarm_settings_v1';
const PUSH_COOLDOWN_KEY = 'kta_push_cooldown_v1';
const VERSION_CHECK_URL = 'https://regina25846-code.github.io/kris-trader-alarm/version.json';
const UPDATE_PAGE_URL   = 'https://regina25846-code.github.io/kris-trader-alarm/';

function updateBadge() {
  chrome.storage.local.get([HISTORY_KEY, 'pendingUpdate'], data => {
    const unread = (data[HISTORY_KEY] || []).filter(h => h.unread).length;
    if (unread > 0) {
      chrome.action.setBadgeText({ text: String(unread) });
      chrome.action.setBadgeBackgroundColor({ color: '#ef5350' });
    } else if (data.pendingUpdate) {
      chrome.action.setBadgeText({ text: 'UP' });
      chrome.action.setBadgeBackgroundColor({ color: '#ef5350' });
    } else {
      chrome.action.setBadgeText({ text: '' });
    }
  });
}

function checkForUpdate() {
  fetch(VERSION_CHECK_URL + '?t=' + Date.now())
    .then(r => r.json())
    .then(data => {
      const latest = data.version || '0';
      if (latest > CURRENT_VERSION) {
        chrome.storage.local.set({ pendingUpdate: { version: latest, page: data.page || UPDATE_PAGE_URL, changelog: data.changelog || '' } });
      } else {
        chrome.storage.local.remove('pendingUpdate');
      }
      updateBadge();
    })
    .catch(() => {});
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes[HISTORY_KEY] || changes['pendingUpdate']) updateBadge();
});

const UPBIT_URLS = [{ urlPrefix: 'https://upbit.com/' }, { urlPrefix: 'https://www.upbit.com/' }];
const BITHUMB_URLS = [{ urlPrefix: 'https://www.bithumb.com/' }];

function injectTab(tabId, file) {
  chrome.scripting.executeScript({
    target: { tabId },
    files: [file]
  }).catch(() => {});
}

function injectAllTabs() {
  chrome.tabs.query({ url: ['https://upbit.com/*', 'https://www.upbit.com/*'] }, (tabs) => {
    (tabs || []).forEach(tab => injectTab(tab.id, 'content.js'));
  });
  chrome.tabs.query({ url: ['https://www.bithumb.com/*'] }, (tabs) => {
    (tabs || []).forEach(tab => injectTab(tab.id, 'bithumb_content.js'));
  });
}

chrome.webNavigation.onCompleted.addListener((details) => {
  if (details.frameId === 0) injectTab(details.tabId, 'content.js');
}, { url: UPBIT_URLS });

chrome.webNavigation.onCompleted.addListener((details) => {
  if (details.frameId === 0) injectTab(details.tabId, 'bithumb_content.js');
}, { url: BITHUMB_URLS });

chrome.runtime.onStartup.addListener(() => { injectAllTabs(); checkForUpdate(); });
chrome.runtime.onInstalled.addListener(() => { injectAllTabs(); checkForUpdate(); });

chrome.tabs.onActivated.addListener(({ tabId }) => {
  chrome.tabs.get(tabId, (tab) => {
    if (!tab.url) return;
    if (tab.url.startsWith('https://upbit.com/') || tab.url.startsWith('https://www.upbit.com/')) {
      injectTab(tabId, 'content.js');
    } else if (tab.url.startsWith('https://www.bithumb.com/')) {
      injectTab(tabId, 'bithumb_content.js');
    }
  });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'fetchPrices' && msg.codes && msg.codes.length) {
    fetch(`https://api.upbit.com/v1/ticker?markets=${msg.codes.join(',')}`)
      .then(r => r.json())
      .then(data => {
        const prices = {};
        data.forEach(d => { prices[d.market] = d.trade_price; });
        sendResponse({ ok: true, prices });
      })
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.action === 'fetchMarkets') {
    fetch('https://api.upbit.com/v1/market/all?isDetails=false')
      .then(r => r.json())
      .then(data => {
        const markets = data
          .filter(m => m.market.startsWith('KRW-'))
          .map(m => ({ code: m.market, sym: m.market.replace('KRW-', ''), kor: m.korean_name, eng: m.english_name }));
        sendResponse({ ok: true, markets });
      })
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.action === 'quickAdd') {
    chrome.storage.local.set({ quickAddSym: msg.sym }, () => {
      chrome.action.openPopup().catch(() => {});
    });
    return;
  }
  if (msg.action === 'sendPush') {
    chrome.storage.local.get([SETTINGS_KEY, PUSH_COOLDOWN_KEY], data => {
      const s = data[SETTINGS_KEY] || {};
      if (!s.ntfyEnabled || !s.ntfyTopic) { sendResponse({ ok: false }); return; }
      const cooldownMin = s.ntfyCooldown ?? 30;
      const cooldowns = data[PUSH_COOLDOWN_KEY] || {};
      const alarm = msg.alarm;
      if (cooldownMin > 0 && (Date.now() - (cooldowns[alarm.id] || 0)) < cooldownMin * 60 * 1000) { sendResponse({ ok: false }); return; }
      cooldowns[alarm.id] = Date.now();
      chrome.storage.local.set({ [PUSH_COOLDOWN_KEY]: cooldowns });
      const exName = msg.exchange === 'bithumb' ? '빗썸' : '업비트';
      const dirText = alarm.dir === 'above' ? '이상' : '이하';
      const body = `${alarm.label} ${Number(alarm.price).toLocaleString()}원 ${dirText} 도달!\n현재가: ${Number(msg.currentPrice).toLocaleString()}원${alarm.memo ? '\n메모: ' + alarm.memo : ''}`;
      fetch('https://ntfy.sh/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic: s.ntfyTopic, title: `🔔 ${exName} 가격 알람`, message: body, priority: 4, tags: ['bell'] })
      }).then(() => sendResponse({ ok: true })).catch(e => sendResponse({ ok: false, error: e.message }));
    });
    return true;
  }
  if (msg.action === 'ntfyTest') {
    fetch('https://ntfy.sh/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ topic: msg.topic, title: '🔔 Kris Trader Alarm 테스트', message: 'Push 알림이 정상 수신되었어요!', priority: 4, tags: ['bell'] })
    }).then(r => sendResponse({ ok: true, status: r.status })).catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
  if (msg.action === 'fetchBithumbPrices') {
    fetch('https://api.bithumb.com/public/ticker/ALL_KRW')
      .then(r => r.json())
      .then(data => {
        const prices = {};
        if (data.status === '0000') {
          Object.entries(data.data).forEach(([sym, info]) => {
            if (sym !== 'date') prices[sym] = parseFloat(info.closing_price);
          });
        }
        sendResponse({ ok: true, prices });
      })
      .catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }
});
